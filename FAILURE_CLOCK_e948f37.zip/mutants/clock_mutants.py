"""Activated failure-clock controls (LOCAL-AUTHORITY-FAILURE-CLOCK-20261027).

usage: python clock_mutants.py <frozen_repo> <workdir> <out.json>
Each mutant copies the frozen tree (no .git), applies ONE source edit and runs
the clock tests, which must turn red; the unmutated copy must pass them.
"""
import json, os, shutil, subprocess, sys

S = "[scratch]"
LA = "src/market_data/local_authority.py"
T = "tests/test_local_authority_failure_clock.py"
TESTS = [f"{T}::test_failure_availability_is_the_source_bucket_close",
         f"{T}::test_inconsistent_or_unprovable_failure_clock_proves_nothing",
         f"{T}::test_the_legacy_edge_alone_is_never_the_availability",
         f"{T}::test_healthy_earlier_failure_still_completes_the_15m_composite",
         f"{T}::test_simultaneous_failure_and_completion_publish_no_composite"]
OLD_BODY = '''    close = source + timedelta(minutes=minutes)
    raw_edge = failure.get("settled_edge_time")
    if raw_edge not in (None, ""):
        edge = _dt(raw_edge)
        if (edge is None or not source <= edge < close
                or (edge - source) % timedelta(minutes=1)):
            return None
    return close'''
MUTANTS = [
    ("C1_legacy_terminal_open_clock", OLD_BODY,
     '''    edge = _dt(failure.get("settled_edge_time"))
    if edge is not None:
        return edge
    return source + timedelta(minutes=minutes)'''),
    ("C2_edge_consistency_unchecked", '''        if (edge is None or not source <= edge < close
                or (edge - source) % timedelta(minutes=1)):
            return None''', '''        pass'''),
    ("C3_strict_order_relaxed_to_equal", "            if not failure_at < completed:",
     "            if not failure_at <= completed:"),
]


def run(repo, log):
    cmd = [f"{S}/g5/run.sh", repo, log, "python", "-m", "pytest", "-q", "-p", "no:cacheprovider", *TESTS]
    return subprocess.run(cmd, capture_output=True, text=True).returncode


def main(frozen, work, out):
    os.makedirs(work, exist_ok=True)
    results = []
    for name, old, new in [("UNMUTATED", None, None)] + MUTANTS:
        dest = os.path.join(work, name)
        shutil.rmtree(dest, ignore_errors=True)
        shutil.copytree(frozen, dest, ignore=shutil.ignore_patterns(".git", "__pycache__"))
        if old is not None:
            path = os.path.join(dest, LA)
            text = open(path).read()
            if text.count(old) != 1:
                results.append({"mutant": name, "status": "NOT_APPLIED", "matches": text.count(old)})
                continue
            open(path, "w").write(text.replace(old, new))
        rc = run(dest, os.path.join(work, name + ".log"))
        status = ("PASS" if rc == 0 else "FAIL") if old is None else \
            ("KILLED" if rc == 1 else ("ERROR" if rc not in (0, 1) else "SURVIVED"))
        results.append({"mutant": name, "file": LA, "exit": rc, "status": status})
        shutil.rmtree(dest, ignore_errors=True)
        print(name, status, flush=True)
    json.dump(results, open(out, "w"), indent=1)


if __name__ == "__main__":
    main(*sys.argv[1:4])

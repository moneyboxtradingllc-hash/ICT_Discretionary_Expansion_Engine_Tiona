"""Source-isolated full-suite orchestration (corrects the shared-checkout race).

usage:
  isolated_suite.py collect <origin_repo> <sha> <out_dir>          one clean clone, one --collect-only
  isolated_suite.py plan    <out_dir> <n_shards>                    file-disjoint plan from that collection
  isolated_suite.py run     <origin_repo> <sha> <out_dir> <workers> concurrent workers, ONE PHYSICAL CHECKOUT PER SHARD
  isolated_suite.py run-one <origin_repo> <sha> <out_dir> <index> <file...>  one extra isolated shard

Every shard gets its own `git clone --no-hardlinks` checkout of the frozen SHA (no
shared or hardlinked source inode), its own HOME/TMPDIR/pytest basetemp/runtime
roots, sockets and DNS denied in-process, execution switches false. Before and
after the shard it records HEAD, tree, `git status --porcelain` and a digest of
every tracked file's on-disk bytes, and fails the receipt if anything differs or
any tracked file has a link count above one. No test is skipped or deselected
by the orchestrator.
"""
import hashlib, json, os, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

PY = sys.executable
WORKER = r'''import json, socket, sys
sys.path[:0] = ["src", "tests"]
def deny(*a, **k): raise RuntimeError("ISOLATED_SUITE_NETWORK_DENIED")
socket.socket.connect = deny; socket.socket.connect_ex = deny
socket.create_connection = deny; socket.getaddrinfo = deny
import pytest
raise SystemExit(pytest.main(["-q", "-rfEs", "-p", "no:cacheprovider", "--basetemp=" + sys.argv[1],
                              "--junitxml=" + sys.argv[2], *sys.argv[3:]]))
'''
COLLECT = r'''import socket, sys
sys.path[:0] = ["src", "tests"]
def deny(*a, **k): raise RuntimeError("ISOLATED_SUITE_NETWORK_DENIED")
socket.socket.connect = deny; socket.create_connection = deny; socket.getaddrinfo = deny
import pytest
raise SystemExit(pytest.main(["--collect-only", "-q", "-p", "no:cacheprovider"]))
'''


def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], check=True, capture_output=True,
                          text=True).stdout.strip()


def clone(origin, sha, dest):
    subprocess.run(["git", "clone", "-q", "--no-hardlinks", str(origin), str(dest)], check=True)
    git(dest, "checkout", "-q", "--detach", sha)


def source_state(repo):
    files = git(repo, "ls-files", "-z").split("\0")
    h, linked = hashlib.sha256(), []
    for rel in sorted(f for f in files if f):
        p = Path(repo) / rel
        if p.is_symlink() or not p.is_file():
            h.update(f"{rel}\0<missing-or-link>\n".encode()); continue
        if os.stat(p).st_nlink > 1:
            linked.append(rel)
        h.update(rel.encode() + b"\0" + hashlib.sha256(p.read_bytes()).digest())
    return {"head": git(repo, "rev-parse", "HEAD"), "tree": git(repo, "rev-parse", "HEAD^{tree}"),
            "status_porcelain": git(repo, "status", "--porcelain", "--untracked-files=all"),
            "tracked_files": len([f for f in files if f]), "tracked_bytes_digest": h.hexdigest(),
            "hardlinked_tracked_files": linked}


def isolated_env(root):
    env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "LANG": "C.UTF-8", "TZ": "UTC",
           "HOME": str(root / "home"), "TMPDIR": str(root / "tmp"), "PYTHONDONTWRITEBYTECODE": "1",
           "PYTHONIOENCODING": "utf-8", "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
           "EXECUTION_ENABLED": "false", "ALLOW_PAPER_ORDERS": "false", "AUTO_EXECUTION_ENABLED": "false",
           "TOPSTEPX_ARM_ORDERS": "false", "AI_BRAIN_LLM": "false", "TWO_BRAIN_MODE": "off",
           "HTTPS_PROXY": "http://127.0.0.1:9", "HTTP_PROXY": "http://127.0.0.1:9", "NO_PROXY": ""}
    for key in ("OCCURRENCE_LEDGER_DIR", "AI_BRAIN_DIR", "REPLAY_SESSIONS_DIR", "AI_RETRIEVAL_DIR",
                "PERFORMANCE_TABLES_DIR", "HTF_MEMORY_DIR", "GLOBAL_MEMORY_DIR"):
        env[key] = str(root / key.lower())
    for d in ("home", "tmp"):
        (root / d).mkdir(parents=True, exist_ok=True)
    return env


def collect(origin, sha, out):
    out.mkdir(parents=True, exist_ok=True)
    repo, root = out / "collect_checkout", out / "collect_runtime"
    shutil.rmtree(repo, ignore_errors=True); shutil.rmtree(root, ignore_errors=True)
    clone(origin, sha, repo)
    pre = source_state(repo)
    p = subprocess.run([PY, "-c", COLLECT], cwd=repo, env=isolated_env(root), capture_output=True, text=True)
    (out / "collect.txt").write_text(p.stdout + p.stderr)
    post = source_state(repo)
    (out / "collect_receipt.json").write_text(json.dumps({"exit": p.returncode, "pre": pre, "post": post,
                                                          "clean": pre == post and not pre["status_porcelain"]}, indent=1))
    shutil.rmtree(repo); shutil.rmtree(root, ignore_errors=True)
    print(p.stdout.strip().splitlines()[-1])


def plan(out, n):
    counts = {}
    for line in (out / "collect.txt").read_text().splitlines():
        # Every collected node id, wherever it lives (the launched plan only took
        # tests/ and so missed one collected docs/ test; see run-one).
        if "::" in line and not line.startswith(" "):
            counts[line.split("::", 1)[0]] = counts.get(line.split("::", 1)[0], 0) + 1
    shards = [{"files": [], "tests": 0} for _ in range(n)]
    for path, c in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])):
        t = min(shards, key=lambda s: s["tests"]); t["files"].append(path); t["tests"] += c
    for s in shards:
        s["files"].sort()
    (out / "shards.json").write_text(json.dumps({"collected_files": len(counts),
                                                 "collected_tests": sum(counts.values()), "shards": shards}, indent=1))
    print(len(counts), sum(counts.values()), [s["tests"] for s in shards])


def run_shard(origin, sha, out, i, files):
    tag = f"shard_{i:02d}"
    work = out / "work" / tag
    shutil.rmtree(work, ignore_errors=True)
    repo, root = work / "checkout", work / "runtime"
    started = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    clone(origin, sha, repo)
    pre = source_state(repo)
    env = isolated_env(root)
    with open(out / f"{tag}.log", "w") as log:
        p = subprocess.run([PY, "-u", "-c", WORKER, str(root / "basetemp"), str(out / f"{tag}.xml"), *files],
                           cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT)
    post = source_state(repo)
    receipt = {"shard": i, "files": files, "started": started,
               "finished": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "exit": p.returncode,
               "checkout": str(repo).replace(str(out), "[out]"), "pre": pre, "post": post,
               "source_unchanged": pre == post, "pre_clean": not pre["status_porcelain"],
               "post_clean": not post["status_porcelain"], "frozen_sha": sha,
               "head_is_frozen": pre["head"] == sha == post["head"],
               "no_hardlinked_sources": not pre["hardlinked_tracked_files"]}
    (out / f"{tag}.receipt.json").write_text(json.dumps(receipt, indent=1))
    shutil.rmtree(work, ignore_errors=True)
    print(tag, p.returncode, receipt["source_unchanged"], receipt["post_clean"], flush=True)
    return receipt


def run(origin, sha, out, workers):
    shards = json.loads((out / "shards.json").read_text())["shards"]
    with ThreadPoolExecutor(max_workers=workers) as pool:
        receipts = list(pool.map(lambda a: run_shard(origin, sha, out, *a),
                                 [(i, s["files"]) for i, s in enumerate(shards)]))
    (out / "receipts.json").write_text(json.dumps(receipts, indent=1))


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "collect":
        collect(Path(sys.argv[2]), sys.argv[3], Path(sys.argv[4]))
    elif cmd == "plan":
        plan(Path(sys.argv[2]), int(sys.argv[3]))
    elif cmd == "run-one":
        run_shard(Path(sys.argv[2]), sys.argv[3], Path(sys.argv[4]), int(sys.argv[5]), sys.argv[6:])
    else:
        run(Path(sys.argv[2]), sys.argv[3], Path(sys.argv[4]), int(sys.argv[5]))

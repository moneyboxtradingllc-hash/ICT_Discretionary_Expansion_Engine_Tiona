"""Union/skip accounting: 17 shard JUnits vs the single collection. usage: union.py <suite_dir>"""
import json, sys, collections, xml.etree.ElementTree as ET
from pathlib import Path
d = Path(sys.argv[1])
collected = [l for l in (d / "collect.txt").read_text().splitlines() if "::" in l and not l.startswith(" ")]
def nodeid(case):
    cls, name, f = case.get("classname", ""), case.get("name", ""), case.get("file")
    return cls, name
cases, outcomes, skips, files_by_shard = [], collections.Counter(), collections.Counter(), {}
merged = ET.Element("testsuite", name="pytest-source-isolated")
receipts = []
for x in sorted(d.glob("shard_*.xml")):
    root = ET.parse(x).getroot(); suite = root if root.tag == "testsuite" else root.find("testsuite")
    for c in suite.iter("testcase"):
        merged.append(c)
        kind = "failed" if c.find("failure") is not None else "error" if c.find("error") is not None \
            else "skipped" if c.find("skipped") is not None else "passed"
        outcomes[kind] += 1
        if kind == "skipped":
            skips[(c.find("skipped").get("message") or "")[:120]] += 1
        cases.append((c.get("classname"), c.get("name")))
for r in sorted(d.glob("shard_*.receipt.json")):
    receipts.append(json.loads(r.read_text()))
ET.ElementTree(merged).write(d / "merged_source_isolated.xml")
# Map collected node ids to junit (classname, name): classname = dotted path w/o .py + ::Class parts
def key(nid):
    head, bracket, param = nid.partition("[")      # a parametrize id may itself contain "::"
    path, *rest = head.split("::")
    rest[-1] = rest[-1] + bracket + param
    mod = path[:-3].replace("/", ".")
    name = rest[-1]; cls = ".".join([mod] + rest[:-1])
    return cls, name
want = collections.Counter(key(n) for n in collected)
got = collections.Counter(cases)
files = [f for r in receipts for f in r["files"]]
coll_files = {n.partition("[")[0].split("::")[0] for n in collected}
out = {"collected_node_ids": len(collected), "junit_cases": len(cases), "junit_unique": len(got),
       "collected_equals_junit": want == got, "missing_from_junit": [list(k) for k in (want - got)][:20],
       "extra_in_junit": [list(k) for k in (got - want)][:20],
       "shard_files": len(files), "shard_files_unique": len(set(files)),
       "files_disjoint": len(files) == len(set(files)),
       "collected_files": len(coll_files),
       "files_equal_collection": set(files) == coll_files,
       "outcomes": dict(outcomes), "skip_reasons": dict(skips.most_common()),
       "receipts": {"count": len(receipts), "all_exit_zero": all(r["exit"] == 0 for r in receipts),
                    "all_source_unchanged": all(r["source_unchanged"] for r in receipts),
                    "all_clean_pre_post": all(r["pre_clean"] and r["post_clean"] for r in receipts),
                    "all_head_frozen": all(r["head_is_frozen"] for r in receipts),
                    "no_hardlinks": all(r["no_hardlinked_sources"] for r in receipts),
                    "distinct_checkout_paths": len({r["checkout"] for r in receipts}),
                    "tracked_bytes_digests": sorted({r["pre"]["tracked_bytes_digest"] for r in receipts}),
                    "trees": sorted({r["pre"]["tree"] for r in receipts})}}
(d / "union_source_isolated.json").write_text(json.dumps(out, indent=1))
print(json.dumps({k: v for k, v in out.items() if k != "skip_reasons"}, indent=1)[:3000])
print("skip reason kinds:", len(skips))

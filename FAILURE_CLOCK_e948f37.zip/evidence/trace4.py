"""Repaired producer trajectories (healthy/simultaneous) at the frozen SHA; plus the parent clock on the same native failures."""
import json, sys, tempfile, pathlib
import test_local_authority_failure_clock as T
import local_authority_loop as H, test_protected_structure_continuity as P
from market_data import local_authority as LA
tape = H.stretched_tape(P.TAPE, **T.STRETCH); root = pathlib.Path(tempfile.mkdtemp())
out = {}
for tag, t in (("healthy", tape), ("simultaneous", T._simultaneous(tape))):
    walk = T._producer_walk(root, t, tag)
    pub = {hm: r["packet"] for hm, r in walk.items() if r["packet"]}
    native = walk["17:15"]["failure"]
    legacy = LA._dt(native.get("settled_edge_time")) if native.get("settled_edge_time") else None
    out[tag] = {"native_failure_at_17_15": native,
                "parent_clock_terminal_open": legacy.isoformat() if legacy else None,
                "repaired_failure_available_at": LA.failure_available_at(native).isoformat(),
                "first_packet_cutoff": min(pub) if pub else None,
                "packet": pub[min(pub)] if pub else None,
                "refusal_reasons": sorted({e.get("reason") for r in walk.values() for e in r["events"] if e.get("reason")})}
    print(tag, out[tag]["parent_clock_terminal_open"], out[tag]["repaired_failure_available_at"], out[tag]["first_packet_cutoff"], out[tag]["refusal_reasons"])
json.dump(out, open(sys.argv[1], "w"), indent=1, default=str)

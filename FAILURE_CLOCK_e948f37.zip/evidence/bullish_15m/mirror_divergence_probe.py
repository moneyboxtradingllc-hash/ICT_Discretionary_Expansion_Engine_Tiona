import json, os, sys, tempfile
from datetime import datetime, timedelta
r=tempfile.mkdtemp()
for k in ("OCCURRENCE_LEDGER_DIR","AI_BRAIN_DIR","AI_RETRIEVAL_DIR","REPLAY_SESSIONS_DIR"): os.environ[k]=os.path.join(r,k)
import local_authority_loop as H
import test_protected_structure_continuity as P
from live_scan.production_scan_cycle import ProductionScanCycle
from market_data import local_authority as LA
B=H.stretched_tape(P.TAPE,anchor="15:00",shift_hours=-2); M=H.mirrored_tape(B)
F={"bullish":"bearish","bearish":"bullish"}
def sig(ap, flip):
    o=ap.get("origin") or {}
    d=(lambda x: F.get(x,x)) if flip else (lambda x: x)
    ev=o.get("event")
    if flip and ev: ev=ev.replace("sell_side","TMP").replace("buy_side","sell_side").replace("TMP","buy_side")
    return (ap.get("status"), d(ap.get("owner")), d(o.get("direction")), ev, o.get("source_tf"), o.get("at"))
cs=[ProductionScanCycle(symbol="MNQ",contract_id=P.C,session_id=f"D{i}",local_authority_profile=LA.OFFLINE_TEST_PROFILE_V1) for i in range(2)]
for hm in ["15:00"]+H.minutes("15:01","17:16"):
    cut=P._cut(hm); out=[]
    for c,T,flip in ((cs[0],B,False),(cs[1],M,True)):
        bars=[b for b in T if b["timestamp"]<=cut][-300:]
        s=c.scan(bars,now=datetime.fromisoformat(cut)+timedelta(minutes=1),invoke_brain=False)
        out.append((sig(s["snapshot"]["active_path_state"],flip), s))
    if out[0][0]!=out[1][0]:
        print("FIRST_DIFF",hm); print(" bear",out[0][0]); print(" bull(mirrored back)",out[1][0])
        for (_,s),lab in zip(out,("bear","bull")):
            ap=s["snapshot"]["active_path_state"]
            print(lab, json.dumps({k:ap.get(k) for k in ("last_reset_reason","last_invalidated","unavailable_reason","notes","forming_direction","ownership_changed_this_scan")},default=str)[:1500])
            print(lab, "ladder", json.dumps(ap.get("load_bearing_structure"),default=str)[:500])
        break
else: print("NO_DIFF")

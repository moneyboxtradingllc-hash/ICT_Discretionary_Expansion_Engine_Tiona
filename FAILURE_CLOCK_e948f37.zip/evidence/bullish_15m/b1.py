import json, os, tempfile
from datetime import datetime, timedelta
r=tempfile.mkdtemp()
for k in ("OCCURRENCE_LEDGER_DIR","AI_BRAIN_DIR","AI_RETRIEVAL_DIR","REPLAY_SESSIONS_DIR"): os.environ[k]=os.path.join(r,k)
import local_authority_loop as H, test_protected_structure_continuity as P
from live_scan.production_scan_cycle import ProductionScanCycle
from market_data import local_authority as LA
T=H.mirrored_tape(H.stretched_tape(P.TAPE,anchor="15:00",shift_hours=-2))
CAP=29225.75
for b in T:
    if b["timestamp"] in (P._cut("16:40"),P._cut("16:41")):
        for k in ("open","high","low","close"): b[k]=min(b[k],CAP)
c=ProductionScanCycle(symbol="MNQ",contract_id=P.C,session_id="B1",local_authority_profile=LA.OFFLINE_TEST_PROFILE_V1)
seen=None
for hm in ["16:00"]+H.minutes("16:30","17:30"):
    cut=P._cut(hm); bars=[b for b in T if b["timestamp"]<=cut][-300:]
    s=c.scan(bars,now=datetime.fromisoformat(cut)+timedelta(minutes=1),invoke_brain=False)
    g=c.local_authority._generation; ap=s["snapshot"]["active_path_state"]; o=ap.get("origin") or {}
    if g and g["market_proof_id"]!=seen:
        seen=g["market_proof_id"]; print("GEN",hm,g["direction"],g["life"]["source_tf"],g["body_confirmation"]["timeframe"],g["failure"]["source_tf"],g["completed_at"],flush=True)
    if hm in ("16:41","16:45","17:00","17:10","17:15","17:20","17:30"): print(hm,ap.get("status"),ap.get("owner"),o.get("event"),o.get("source_tf"),o.get("at"),json.dumps(c.local_authority.diagnostics[-1]["events"],default=str)[:200],flush=True)

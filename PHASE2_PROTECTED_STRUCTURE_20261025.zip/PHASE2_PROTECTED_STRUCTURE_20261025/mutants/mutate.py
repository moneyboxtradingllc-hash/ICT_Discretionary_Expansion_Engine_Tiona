"""Apply one named scratch-only mutation to a worktree (never committed)."""
import subprocess, sys
from pathlib import Path
wt, name = Path(sys.argv[1]), sys.argv[2]
EDITS = {
 "lost_transport": [("src/ai_brain/brain_input.py",
     '"by_timeframe": ps.get("by_timeframe") or {},', '"by_timeframe": {},', 1)],
 "stale_identity": [("src/ai_brain/narrative_continuity.py",
     'and released.get("registered_at") == leg.get("registered_at"))', 'and True)', 1)],
 "future_identity": [("src/market_data/campaign_scope.py",
     'if stamp is None or stamp > cutoff:', 'if stamp is None:', 2)],
 "future_context": [("src/live_scan/production_scan_cycle.py",
     'return [bar for bar in deep_1m\n                    if canonical_instant(bar.get("timestamp"), strict=True) <= at]',
     'return list(deep_1m)', 1)],
 "duplicate_progression": [("src/market_state/active_path.py",
     'if key and key in self._seen:', 'if False:', 1)],
}
if name == "f6_c2_promotion":
    subprocess.run(["git", "-C", str(wt), "apply", sys.argv[3]], check=True)
else:
    for rel, old, new, count in EDITS[name]:
        p = wt / rel; s = p.read_text()
        assert s.count(old) == count, (rel, s.count(old))
        p.write_text(s.replace(old, new))
print(subprocess.run(["git", "-C", str(wt), "diff", "--stat"], capture_output=True, text=True).stdout)

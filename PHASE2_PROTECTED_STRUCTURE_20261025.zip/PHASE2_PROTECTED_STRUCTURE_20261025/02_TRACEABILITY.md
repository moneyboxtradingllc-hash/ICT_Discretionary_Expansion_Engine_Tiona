# 02 — Traceability (supplied matrix, completed)

## Conventions

- **Code references.** Line numbers are at 357668e. `src` is identical at the final SHA 736c610.
- **Trace files.** "T:" names a trace file in `traces/`. Each per-cutoff row keeps the original producer field names
  (`protected_swings.by_timeframe`, `active_path_state.*`, `narrative_continuity.*`, `campaign_lifecycle.*`).
- **Derived fields.** `first_failed_transfer_gate*` is derived. It re-evaluates the conjuncts of `_transfer_proof`
  (`probes/p2trace.py::transfer_gates`), and the probe asserts that it agrees with the real `_transfer_proof` at every
  cutoff.
- **Test references.** "N:" is a node in `tests/test_protected_structure_continuity.py` at 736c610.
- **Judgments.**
  - **CAPTURED**: Friday's recorded original responses, last call per cutoff. This covers 281 of 397 recorded calls;
    15 degraded calls were served as provider failures.
  - **CONTROLLED**: a mocked stand-down response.
  - Quotes in the Friday trace are controlled at the settled close.

## Matrix

| Claim/case | Ratified source and exact wording | Actual producer + identity | Availability chronology | Actual transport consumer | Authority consumer + gate | Parent result | Final result | Healthy/activated proof | Disposition/limitation |
|---|---|---|---|---|---|---|---|---|---|
| **Friday retained life** | Phase 2 §3.1: "A fact does not cease to exist merely because its direction was not supporting the incumbent local owner." No ratified rule makes it a bearing (01 §3) | `ProtectedSwingTracker` → `protected_swings.by_timeframe.highs.1m` = 29263.0 / `1m:swing_high:29263` / registered_at 16:48Z / `buy_side_raid_rejected`. Receipt `PROTECTED_SWING_REGISTERED:CON.F.US.MNQ.Z26:1m:2026-10-23T16:48:00+00:00:high@29263.0:1m:swing_high:29263@2026-10-23T16:48:00+00:00` | Registered, source and observed 16:48Z; settled_edge null (1m). Incumbent bullish leg active 16:46–17:07 (bearing 1m low 29195@16:56) | Registry record present unchanged at every cutoff 16:48–17:40 in the snapshot and at the provider seam (T: FRIDAY_TRACE_*; N: test_friday_retained_high…[ecu/non-ecu]) | `ActivePath._apply` step 2 (:472) ignores it at 16:48: side high ≠ supporting low. After 17:15, `_transfer_proof` first failing conjunct is `G7_load_bearing_present` | Fact transported; no bearing; developing_transfer; `campaign_lifecycle_refused` | Identical (no source change) | Healthy: N passes both lanes. Activated: lost_transport fails it (4 failures); f6 binder fails it (bearing 29263 bound) | **Fact: NO WIRING DEFECT**, already present. **Bearing/transfer: INCOMPLETE AUTHORITY CONTRACT**, not implemented (05). Captured cognition is mostly "conflicted" 17:09–17:16 (bearish at 17:13) |
| **C2 retained 5m life** | Same. The pinned C2 contract (`test_retained_leg_projection`, `test_campaign_leg_scope_labels`) is consistent with the only ratified reading | `protected_swings.by_timeframe.highs.5m` = 29500.0 / `5m:swing_high:29500` / 03:04 / `buy_side_raid_rejected` (also 3m 29500@03:02, 1m 29463@02:45) | Registered 03:04 (source bucket 03:00, settled edge 03:04). Incumbent 1m low 29457@02:56 dies 03:06; 5m `rejected_raid_reclaim` origin 03:07; bearish active 03:07 (1m break 03:07) | Present at the provider seam every scan 03:05–03:14, both lanes (T: C2_TRACE_parent_*; N: test_c2_surviving…) | First failing gate 03:07–03:14: `G7_load_bearing_present`. No D3-B witness: the only catalog life is a 5m low (supports bullish) | developing_transfer / TRANSFER_UNRESOLVED / `campaign_lifecycle_refused` | Identical | f6e4013 run (T: C2_TRACE_f6e4013_*): bearing 5m 29500 bound at 03:07, `confirmed_transfer`, then `incumbent_intact` 03:08–03:14. Mutant f6_c2_promotion fails 9 tests | **LEGITIMATE REFUSAL** |
| **Prior released failed life** | S4E retained-leg rule (`_retained_leg_projection` docstring :135–165): "marked intact: False … never a live leg, a campaign falsifier, a transfer or an entry permission" | Friday `last_invalidated` = bullish 1m low 29195 / `1m:swing_low:29195` / reg 16:56, `PROTECTED_SWING_VIOLATED…17:08…`. C2: 1m 29457@02:56 died 03:06 | Death source/observed 17:08 (C2 03:06) | `narrative_continuity.active_leg_structure_source` = `retained_prior_leg_row`, level 29195 (C2 29457), intact False, 17:08–17:16 | Local leg failure `active_leg_failure_status: occurred`; campaign premise UNKNOWN/unbound (no campaign falsifier) | Retained, failed, non-authorizing | Identical | stale_identity mutant (registered_at check removed) caught by `test_uncorroborated_by_producer_release_is_withheld[other_registration_life]` | Local-leg death ≠ campaign failure, as published. **LEGITIMATE** |
| **Genuine already-authorized positive** | D3=B/STRICT/INDEPENDENT_SUPPORTING_LIFE; D0=a | W5 tape (existing `test_campaign_scope_binding` fixture): bearing 5m high 29519.75 `5m:swing_high:29519.8` registered 14:29, i.e. **after** the incumbent death (1m 29524.25 @14:23) and the origin (1m @14:25) | D3: R 14:25 (5m raid) > D 14:23 (1m source) | Real ECU/non-ECU scans; Brain responses CONTROLLED (`logs/w5_positive.log`) | Scope ACTIVE route B → ACTIVE_DELIVERY → **real bearish CandidateProducer candidate** at T4 | Candidate produced, both lanes | Identical (full suite) | Matched removal: the same life registered **before** the death gives no bearing and no proof (N: test_same_life_bears_only_when_registered_inside_the_new_leg, both directions; FICTIONAL tape). Existing D3 negatives: test_campaign_scope::test_strict_scope_negative_predicates | Existing route proven reachable. **No change** |
| **Ladder/progression replay** | ActivePath ingest doctrine (:383–410): one factual event is one occurrence; a restart must converge with continuous | `ActivePath.ingest` dedupe by occurrence id (:428); ladder guard (:497) | — | — | `progression.favourable_ladder`, `successive_favourable` | One rung per real event; replay awards nothing | Identical | N: test_duplicate_or_replayed_registration_awards_no_progression. duplicate_progression mutant (dedupe removed) re-points the bearing to the superseded life and fails it | **NO DEFECT**. f6's binder would mint rung 1 from a pre-origin life (f6 report §5) |
| **Restart/rolling chronology** | Previously accepted N1/S4C restart evidence; not reopened | `_prepare_chronology` cold path (:661–676) and rolling path (:678–690) | 17:15 cutoff | Continuous 16:40→17:15, duplicate 17:15 and a fresh-process cold 17:15 agree on path authority and high-side lives (N: test_friday_cold_restart…). Future suffix offered via `deep_1m` changes nothing (N: test_future_session_bars…) | `_settled_context_input` (:614–626) filters bars after the cutoff | Equal | Equal | future_context mutant (filter removed) fails it: `session_context` and the premise catalog change. **Limitation:** the LOW registry differs with window start (logs/horizon.log: a 15m low 29022.5@13:29 appears only for a 300-bar window that starts after 12:14). That is the existing 300-minute horizon, has no authority effect here, and is not reopened | **NO DEFECT** for this mission |
| **Actual next Brain narrative** | Phase 1 accepted (357668e) | `authored_market_read` captured pre-hold | 17:14 read → 17:15 input | `market_narrative_history.last` = AVAILABLE, OBSERVATIONAL_ONLY, bearish (CONTROLLED), recorded_at 17:14, while `narrative_continuity.control_state` ≠ confirmed_transfer (N: test_friday_retained_high…) | Never an authority input | Preserved | Preserved | Phase 1 suite `test_market_narrative_first.py` in the full run | Narrative wording cannot promote the fact (no consumer reads it) |
| **Candidate + plan + final quote** | Existing gates (Draw newborn, Lifecycle, CandidateProducer, sealed plan, final quote) | — | — | Friday 13:18–17:58 every cutoff: candidate `campaign_lifecycle_refused`; captured actions all stand_down (CAPTURED) | `candidate_direction_authorized` (:882) refuses developing_transfer | Refused | Refused | Healthy plan/final-quote positives unchanged in the full run: test_campaign_scope_binding::test_real_bound_plan_survives_fresh_cutoff_and_refuses_lost_custody, test_conditional_plan_across_alignment_step, test_latency1_final_quote_zone | No fact-only path reaches a plan. **No change** |

## Per-cutoff first-failure traces (from T: FRIDAY_TRACE_non-ecu.json; ECU identical, 0 differing fields)

Columns: cutoff (Z) | owner/status | load-bearing | last_invalidated | origin | first failing `_transfer_proof`
conjunct against the mechanical incumbent | control_state | Lifecycle | candidate.

| Cutoff | Owner/status | Bearing | Died | Origin | First failed | Control | Lifecycle | Candidate |
|---|---|---|---|---|---|---|---|---|
| 16:48 | bullish/active | 5m low 29204@16:39 | 1m 29238@16:23 | 3m@16:24 | G0b (no opposite owner) | developing_transfer | TRANSFER_UNRESOLVED | lifecycle_refused |
| 16:56 | bullish/active | 1m low 29195@16:56 | same | same | G0b | developing_transfer | TRANSFER_UNRESOLVED | lifecycle_refused |
| 17:07 | bullish/contested | 1m 29195 | same | same | G0b | developing_transfer | TRANSFER_UNRESOLVED | lifecycle_refused |
| 17:08 | none/none | — | **1m low 29195@17:08 (bullish)** | — | G0b | developing_transfer | TRANSFER_UNRESOLVED | lifecycle_refused |
| 17:09–17:14 | none/forming bearish | — | same | **1m rejected_raid_reclaim 17:09** | G0b (owner not yet established) | developing_transfer | TRANSFER_UNRESOLVED | lifecycle_refused |
| **17:15** | **bearish/active** (1m break 17:15 @29154.25) | **— (the 16:48 high is not bound)** | same | same | **G7_load_bearing_present** | developing_transfer | TRANSFER_UNRESOLVED | lifecycle_refused |
| 17:16–17:40 | bearish/active | — | same | same | G7 | developing_transfer | TRANSFER_UNRESOLVED | lifecycle_refused |
| 17:41–17:58 | bearish/contested | — | same | same | G2 (status) | developing_transfer | TRANSFER_UNRESOLVED | lifecycle_refused |

- **The 17:15Z "first difference".** This reproduces the first difference previously observed. It is the first cutoff
  where every other conjunct holds, so the missing bearing is the first rejected authority witness. The registry
  29263@16:48 is unchanged at every row.
- **Same price, different life.** The earlier 29263 life (REPLACED→29263@16:45) was VIOLATED at 16:46. The current
  life is a new registration at 16:48 (N: test_friday_same_price_earlier_life_is_retired_not_current). The chart's
  10:50 high is not this life, and no such join was made.

## Minimal distinguishing-witness table (Friday vs C2)

| Candidate witness | Friday | C2 | Existing doctrine / mandatory consumer | Decisive? |
|---|---|---|---|---|
| Pre-death opposing-side life still current, original identity | Yes (1m 29263@16:48) | Yes (5m 29500@03:04; 3m 29500@03:02) | None makes this a bearing (01 §3) | **No — same in both** |
| Registration observed inside the new leg | No | No | `ActivePath._apply` step 2 → `_transfer_proof` bearing | Same in both (absent) |
| Rejected opposing raid origin after death | 1m 17:09 > 17:08 | 5m 03:07 > 03:06 | `_authoritative_opposing_origin`, `_transfer_proof` | Same in both (present) |
| Structural progression | 1m 17:15 | 1m 03:07 | `_transfer_proof` | Same in both |
| Post-death producer event naming the retained life (raid/replacement of that exact LifeRef) | None through 17:40 (post-death sweeps at 29186.25 / 29170.5 / 29193.75 / 29156.25; no `PROTECTED_SWING_*` row for it after 16:48) | None (post-death above_high sweeps at 29465 only) | None ratified; candidate for the narrow rule in 05 | Same in both (absent) |
| D3-B independent 5m/15m supporting life raided after death | Catalog high 5m 29294.5@15:59, raids 15:55/16:00/16:05, all **before** D 17:08 → fails STRICT | No bearish-side catalog life | `campaign_scope_proof` (STRICT R > D) | Same in both (absent) |
| Timeframe of the retained life (1m vs 5m) | 1m | 5m | No rule keys bearing admission on timeframe; D3 roles apply to campaign L only | Not a ratified authority difference |

**Result.** No ratified decisive difference exists, so the Friday-only authority route is **UNAPPROVED and not
implemented**. Any rule that admits Friday's 29263 bearing on the facts available also admits C2's 29500. That is
exactly the f6e4013 regression.

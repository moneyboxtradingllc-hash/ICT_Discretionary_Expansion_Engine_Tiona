# 01 — Source, call graph and authority

All line references are at the frozen parent `357668ea8742cb4a7916580908be6fff5a0b82d7` (tree `7dc4bb9e…`). The
review commits `a24ab45` and `736c610` change no `src/` file, so they are identical there.

## 1. Identity and measured pins

| Item | Parent 357668e | Final 736c610 |
|---|---|---|
| Brain fingerprint | `brain:62fe5ecf46d75dc4` | `brain:62fe5ecf46d75dc4` (unchanged) |
| Retrieval fingerprint | `retr:0c241bdb8234d1ba` | unchanged |
| Closure | 49 sources (48 `src` + 1 repo entrypoint) | unchanged |
| Protected pins | 32, digest `79988f0e…` | unchanged |
| Ledger | LEDGER_VERIFIED, protected_verified 32, network_requests 0 | LEDGER_VERIFIED with new entry `PROTECTED_STRUCTURE_RECONCILIATION_20261025` (see 04) |

Measured with `tools/verify_engineering_ledger.py` and `brain_contract_fingerprint()` in the isolated runner
(`logs/ledger_parent.json`, `logs/fp_parent.txt`).

### Full diff 357668e..736c610

```
 docs/recognition_validation/ENGINEERING_LEDGER.md |  39 ++   (one appended entry)
 tests/fixtures/session_20261023_settled_tape.json | 531 ++   (tape only, see below)
 tests/test_protected_structure_continuity.py      | 399 ++   (10 new cases)
 3 files changed, 969 insertions(+)
```

- **No production source, test expectation, fingerprint literal or C2 expectation changed.** Nothing was imported from
  f6e4013 except the settled 1m bars.
- **Fixture.** The `tape` list is copied unchanged from f6e4013's `tests/fixtures/session_20261023_bearing_handoff.json`
  (git blob `1a2f82de…`).
  - Its `retained_occurrences`, `frames`, binder and expectations are not used.
  - The new file records that derivation and a canonical tape digest
    (`b872b6a2…`, 521 bars, 09:19–17:59Z), which the test asserts.
  - The original provenance text is kept verbatim; its archive, scope and provenance limits still apply.

## 2. Actual producer → consumer graph (normal scan path)

```
ProductionScanCycle.scan                                   production_scan_cycle.py:710
 ├─ _rebuild_derived_state (revision change / first scan)   :314  (replays settled prefixes, :451 -> _producer_prefix)
 ├─ _prepare_chronology  (catch-up of every missing prefix) :628  (cold: fresh ActivePath :674; rolling N1 :678-690)
 │    └─ _producer_prefix(window)                           :554
 │         ├─ ProtectedSwingTracker.update -> snapshot["protected_swings"]   protected_swings.py:440
 │         └─ _update_active_path(snapshot)                 :573 / :1523
 │              extract_occurrences(snapshot, prior_protected)   active_path.py:142
 │              ActivePath.ingest  -> _apply                active_path.py:383 / :436
 ├─ current prefix: _update_active_path (cached state)       :772 / :818
 ├─ brain_input.build: "protected_swings": _protected(...)   brain_input.py:1141 (by_timeframe passed through :580)
 │                     "active_path_state", narrative_continuity = build_narrative_continuity :1019
 ├─ narrative_brain: capture authored read, output_direction_hold   narrative_brain.py:1226
 ├─ campaign Draw / campaign_lifecycle -> candidate_direction_authorized   campaign_lifecycle.py:273
 └─ CandidateProducer.produce -> candidate_direction_authorized   luna_candidate_producer.py:1455
```

**Reachability notes**

- `_recover_active_path` (`:1342`) and its `_reconcile_load_bearing` (`:1399`) run only when `_update_active_path`
  finds `self._active_path is None` (`:1551–1580`). On the normal path `_prepare_chronology` always installs an ActivePath
  first (`:674`). These helpers are not the production restart path, which confirms the earlier f6e4013 finding. Phase 2
  does not rely on them and does not change them.
- **Protected high/low fact.** It is produced by `ProtectedSwingTracker` and published in `protected_swings.by_timeframe`
  with `level, timeframe, swing_id, registered_at, basis`. It is transported to the Brain unchanged by
  `brain_input._protected` (`:550–583`).
- **Birth/observation receipts.** `extract_occurrences` turns diffs of consecutive registries into immutable
  `PROTECTED_SWING_REGISTERED/REPLACED/VIOLATED` occurrences with original `registered_at`, `source_bar_time`,
  `settled_edge_time` and `observed_at` (`active_path.py:230–289`). Occurrences are not transported to the Brain;
  `liquidity_events` carries sweeps only.
- **Load-bearing structure (authority-bearing).** `ActivePath._apply` step 2 (`:472–509`) binds a registration or
  replacement only `if self._leg_direction()` and only `if ev["side"] == self._supporting_side()`.
  - Consequence: a registration observed while the incumbent leg owns the tape is on the wrong side and is not bound.
  - It is never re-offered, because the registry diff only emits on change and ingest dedupes by occurrence id (`:428`).
  - The death branch (`:528–586`) clears `load_bearing`, `ladder` and `progression` and records `last_invalidated`.
- **Transfer proof (authority).** `narrative_continuity._transfer_proof` (`:339–384`) requires all of:
  - owner equals `to`, with status `active`;
  - `last_invalidated.owner` equals `from`;
  - an origin strictly after the death;
  - `_authoritative_opposing_origin` (`rejected_raid_reclaim` only, `:204–218`);
  - progression;
  - `_load_bearing(path)` on the expected side, `intact is True`.

  `build_narrative_continuity` (`:394`) labels `confirmed_transfer` only from that proof. `_apply_campaign_scope`
  (`:623`) keeps the D0=a legacy table while authentically UNBOUND. `candidate_direction_authorized` (`:882`) refuses
  `developing_transfer`/`unresolved`.
- **D3-B campaign scope.** `campaign_scope.campaign_scope_proof` (`:74–122`) calls `_transfer_proof` first (B1) and then
  requires a selected 5m/15m supporting life's canonical reclaimed raid with `R > D` strictly.

## 3. Dated primary authority (copies in `authority/`)

| Date | Source | Exact wording relied on |
|---|---|---|
| 2026-10-09 | `authority/MISSION.md` (Codex's M2 record, attached to Gmail 1a123091c6031eba) | "User selected the recommended initial configuration with "do your thing bro" on 2026-10-09 … Chosen values: D0=a; D1=a; D2_ROLES={5m,15m}; K=1; D3=B; D3_TIME=STRICT; BEARING=INDEPENDENT_SUPPORTING_LIFE; D4=a; D5=a; D6=a." |
| 2026-10-09 | `authority/D0_D6_table_v3.txt` (the decision packet the selection answered; sha256 `9aa1bed6…`) | D0 (a): "Transitional compatibility while UNBOUND: keep today's confirmed_transfer label." D3 B1: "local transfer verified: _transfer_proof(path, from, to) is not None … requires … an intact bearing on the to-side." BEARING INDEPENDENT_SUPPORTING_LIFE: "L need not be the current load-bearing structure (B1 already requires an intact to-side bearing)." |
| 2026-10-17 (Stage 5 contract) | `authority/02_ARCHITECTURAL_CONSTITUTION.md` | Line 9: "Retracement is not reversal. Local opposing geometry, failed local leg, delivered Draw and campaign-premise death are separate facts." Line 19: "Selected life need not be ActivePath's current load-bearing structure. The transfer itself must still prove an intact local bearing." Line 7: "Deterministic code owns physical facts, settled chronology and causal identity … current ownership". |
| 2026-10-25 | Phase 2 contract §3.2 | "The mere existence, survival, side or age of a protected high/low is not enough to establish campaign transfer … This contract does not select a universal birth-before-death ban or a universal old-life admission rule." |
| original, undated module doctrine | `active_path.py` docstring | "OWNERSHIP IS EVIDENCE, NOT AUTHORISATION." Later contracts (NARRATIVE-AUTHORITY-1, D0=a) consume the same path as transfer proof, so this sentence does not override them. |

### Reconciliation

- **Ratified.** D0=a makes the local `_transfer_proof` authority-bearing while UNBOUND. Every D3-B establishment or
  transfer also passes through it (B1). Both decisions were measured and ratified on the then-current ActivePath
  semantics, in which a supporting life binds only when observed inside its own leg.
- **Not ratified.** No dated decision addresses whether a life registered while the incumbent owned the tape may become
  the opposing owner's load-bearing structure. The bearing subchoice (INDEPENDENT_SUPPORTING_LIFE vs SAME_BEARING) is
  explicitly about the campaign life L, and presupposes ("B1 already requires") the local bearing rule.
- **Policy-by-test.** The pinned C2 expectations (`test_campaign_leg_scope_labels`, `test_retained_leg_projection`) are
  current-source expectations. They are not themselves ratification. They are, however, consistent with the only
  ratified reading available, and no dated decision contradicts them.
- **Real conflict.** None between ratified records. The open item is a gap, not a conflict.

## 4. Expectation updates

None. No existing expectation, literal or C2 pin was touched. The 10 new cases assert current measured behaviour and
are labelled with their mock/captured status in their docstrings.

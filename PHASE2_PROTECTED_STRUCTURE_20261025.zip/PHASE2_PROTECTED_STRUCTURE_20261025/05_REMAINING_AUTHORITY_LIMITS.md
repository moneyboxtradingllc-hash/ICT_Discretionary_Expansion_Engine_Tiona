# 05 — Remaining authority limits

## 1. The one substantive doctrine gap (reserved; DISABLED; not implemented)

**Original source.** Two places define the local bearing:

- `ActivePath._apply` step 2 (`active_path.py:472–509`): a supporting life binds only when its registration or
  replacement is observed while that leg's direction exists.
- `_transfer_proof` (`narrative_continuity.py:339–384`): an intact expected-side bearing is required.

D0=a (local proof = authority while UNBOUND) and D3=B B1 consume that bearing. They were ratified on 2026-10-09 against
exactly these semantics (`authority/D0_D6_table_v3.txt`, `authority/MISSION.md`).

**Why existing authority cannot decide it.** No dated decision says whether a life registered while the incumbent
owned the tape may later become the opposing owner's bearing. `BEARING=INDEPENDENT_SUPPORTING_LIFE` concerns the
campaign life L and presupposes B1 ("B1 already requires an intact to-side bearing"). The Phase 2 contract forbids
both a blanket admission and a blanket birth-time ban.

### Smallest precise rule that would answer it (proposal only)

> **Q-BEARING-R (proposed).** A retained supporting-side life whose registration was observed before the incumbent's
> proved death may become the new opposing owner's local load-bearing structure **only** if the producer publishes, at
> or before the evaluated cutoff and **strictly after** D, a new event that names that exact LifeRef.
>
> - D is the incumbent death time, defined exactly as in D3 STRICT: `settled_edge_time`, else the 1m `source_bar_time`.
> - LifeRef means contract, session, side, timeframe, swing_id, registered_at, level and basis.
> - The qualifying event is either a canonical reclaimed raid whose `protected_swing_lifetime` association names that
>   life, or a REPLACED/REGISTERED receipt into it.
>
> Survival, age, side, price equality, Brain wording or the life merely being current never qualify. The binding
> creates no new registration and no ladder rung. It does not set `last_move_favourable` or `successive_favourable`.

### Consequences, measured on the available evidence

| Case | Qualifying post-death event? | Result under Q-BEARING-R | Under the parent | Under f6e4013 |
|---|---|---|---|---|
| Friday 1m 29263@16:48 (death 17:08) | None through 17:40. No sweep at 29263; no receipt after 16:48 | No bearing; refusal unchanged | No bearing | Bearing bound → `confirmed_transfer` (f6's own test asserts it at 17:15) |
| C2 5m 29500@03:04 (death 03:06) | None | No bearing; C2 pins hold | No bearing | `confirmed_transfer` 03:07, then `incumbent_intact`; 4 pinned C2 cases fail |
| W5 healthy positive | Not applicable: the bearing is registered 14:29, inside the new leg | Unchanged candidate | Candidate | Candidate |

So Q-BEARING-R changes nothing on any measured tape. It would matter only where a pre-death life is demonstrably
re-defended after the death. No such tape exists in the repository, so its live frequency and its effect on
participation are **UNKNOWN**.

**Missing ratification.** Q-BEARING-R needs Codex/Maurice ratification as an amendment to the ActivePath bearing law.
It would rotate the Brain fingerprint, because `market_state/active_path.py` is itself a bound closure source, and so
require fresh session authorization. It is **not implemented, not enabled and not needed** for any
case in this mission.

**Not proposed.** "Admit any still-current pre-death life" (f6e4013) is rejected by the Phase 2 contract itself ("mere
survival cannot convert C2 into confirmed campaign transfer"). "Never admit a pre-death life" is the current effective
behaviour; making it an explicit rule would also be a blanket birth-time ban, which the contract withholds. Neither is
put forward.

## 2. Separate limitations (not doctrine)

- **Current-Brain quality is UNPROVEN.**
  - The Friday replay serves recorded original responses: 281 last-per-cutoff of 397 calls, with fields recovered from
    `llm_raw_response` and truncated fields defaulted.
  - It proves only the stated transport and authority states. It does not show what a newly prompted model would say.
  - Captured reads at 17:09–17:16 were mostly "conflicted", not bearish.
- **No missed trade is claimed.** Every captured primary action was stand_down. No mock entry was substituted for a
  historical stand-down.
- **Bounded horizon.** The cold-restart LOW registry depends on where the 300-minute window starts (02/04). This is
  pre-existing, has no authority effect on this question, and is not reopened.
- **Surviving defensive mutant.** Removing `campaign_scope_proof`'s "died/origin after cutoff" guard (`future_identity`)
  is caught by no existing test: `test_campaign_scope.py` 49 passed. A real scan cannot produce a death or origin
  stamped after its own cutoff. The reachable future-data control is `future_context`, and it is caught. Recorded,
  not repaired (out of scope).
- **Catalog row order (observed, not investigated further).** Two identical 17:15 scans in one process published the
  same two `campaign_premise_catalog` rows in different orders, depending on which scans ran earlier in that process
  (`logs/catalog_state.log`). The catalog is Brain-visible descriptive input; its contents, ids and authority were
  equal. This is outside Phase 2 and recorded for Codex. The permanent case compares rows as a set (04 §5).
- **Tape provenance.** The tape carries the fixture's own provenance text: operator-bundle scope, not provider or
  archive certification. Controlled quotes are used. Fills and venue behaviour are not exercised.
- **Runtime and authorization.** Linux and Python 3.12.3 runtime only; no Mac certification of this SHA. No previous
  session authorization is reusable. No trading readiness is claimed.
- **Still open, unchanged.** CISD O1 (outside Phase 2).

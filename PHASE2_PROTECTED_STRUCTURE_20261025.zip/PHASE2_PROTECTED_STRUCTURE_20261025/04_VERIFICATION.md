# 04 — Verification

## 1. Runtime and isolation

- **Platform.** Linux; Python 3.12.3 venv with 47/47 pinned requirements. This is the same runner used for the
  accepted Phase 1 evidence.
- **Clean environment.** Every command ran through `run.sh <clone> <log> <cmd>`, which sets:
  - `env -i` with an allowlisted PATH, HOME and TZ=UTC;
  - `PYTHONPATH=src:tests`;
  - `EXECUTION_ENABLED=false`, `ALLOW_PAPER_ORDERS=false`, `AI_BRAIN_LLM=false`, `TWO_BRAIN_MODE=off`;
  - every runtime root (occurrence ledger, brain, replay, retrieval, performance, HTF and global memory) in a fresh
    temporary directory per run;
  - `HTTPS_PROXY`/`HTTP_PROXY=http://127.0.0.1:9` (sinkholed).
- **What was absent.** No `.env`, no credentials, no network, no model, provider or venue call. Production is disarmed.
- **Worktrees.** Each full-suite shard ran in its own detached worktree of the frozen SHA (`sh0..sh3`). Mutants each
  had their own worktree of 357668e plus the final test file and fixture.

## 2. Identity checks

| Check | Result |
|---|---|
| Parent checkout | `357668ea…` / tree `7dc4bb9e…`, clean, before any edit |
| Final | `736c610d86e6618e979efd388521deeb9bf669e6` / tree `55d162a8…`, clean; remote branch verified at this SHA (`git ls-remote`) |
| Fingerprints at final | `brain:62fe5ecf46d75dc4`, `retr:0c241bdb8234d1ba`, closure 49 (unchanged; no `src` diff) |
| Ledger at final | `tools/verify_engineering_ledger.py`: **LEDGER_VERIFIED**, protected_verified 32, network_requests 0 (`logs/ledger_final.json`) |
| Ledger entry | `PROTECTED_STRUCTURE_RECONCILIATION_20261025`, parent 357668e, receipt `678b94c8…`, predecessor `ab00c1e1…`. `scoped_files` = the new test, the fixture, `docs/recognition_validation/*` |

## 3. Focused results (from the final full-suite JUnit, 736c610)

| File | Passed | Skipped | Failed |
|---|---|---|---|
| test_protected_structure_continuity (new) | 10 | 0 | 0 |
| test_campaign_leg_scope_labels (C2 pins) | 22 | 0 | 0 |
| test_retained_leg_projection (C2 pins) | 50 | 0 | 0 |
| test_campaign_draw_temporal_authority | 27 | 0 | 0 |
| test_campaign_scope | 49 | 0 | 0 |
| test_campaign_scope_binding (real W5 candidate, plan) | 29 | 0 | 0 |
| test_campaign_scope_void_consumers | 9 | 0 | 0 |
| test_market_narrative_first (Phase 1) | 23 | 0 | 0 |
| test_conditional_plan_authority | 39 | 0 | 0 |
| test_pre_authorized_conditional_plan | 12 | 0 | 0 |
| test_conditional_plan_across_alignment_step | 6 | 0 | 0 |
| test_latency1_final_quote_zone | 16 | 0 | 0 |
| test_reversal_foundation_proof_closure | 31 | 0 | 0 |
| test_stance_history_hygiene | 69 | 0 | 0 |
| test_active_path_state | 75 | 11 (archive absent) | 0 |
| test_authorization_source_closure | 129 | 0 | 0 |
| test_brain_fingerprint_portability | 88 | 0 | 0 |

The new file was also run on its own on the final tree: 10 passed (`logs/new_tests.log`).

## 4. Complete isolated canonical suite at the final SHA

| Item | Value |
|---|---|
| Command | `python3 -m pytest --collect-only -q -p no:cacheprovider tests/` (in sh0), then `shard_suite.py plan collect.txt <dir> 4`, then per shard `python3 -m pytest -q -rfE -p no:cacheprovider --junitxml=shard_NN.xml <files>` |
| Collection | **9,734** unique `tests/` cases in **358** files (9,724 at 357668e + 10 new) |
| Union | `merge_shards.py`: planned files = collected files, shards file-disjoint, 9,734 JUnit testcases, 9,734 unique, equal to collection (`full_suite/union.json`) |
| Run | 05:58:19Z–06:55:07Z |
| Outcome | **9,151 passed, 583 skipped, 0 failed, 0 errors** (+34 subtests passed). Shards: 2327/107, 2293/141, 2244/189, 2287/146 |
| Skips | 583, the same count and classes as the accepted 357668e run: archive, operator-evidence and credential dependent. Grouped in `full_suite/skip_reasons.txt` (largest: 149 archived production snapshot absent; 70 canonical store not present; 68 EXTERNAL_EVIDENCE_REQUIRED). Skipped tests are unexecuted and are not counted green |
| Evidence | `full_suite/full_736c610.junit.xml`, `shard_0*.log`, `collect.txt`, `shards.json`, `union.json` |

### Earlier failing run (preserved, superseded)

- **What failed.** The first full run at `a24ab45` (05:09:41Z–05:55:31Z): 9,734 collected, 9,150 passed, 583 skipped,
  **1 failed**: `test_protected_structure_continuity::test_future_session_bars_offered_as_deep_context_are_never_used`.
- **Cause.** My own test, not production. Both scans published the same two `campaign_premise_catalog` rows, but in an
  order that follows earlier scans in the same process. The test compared that order; it passed in isolation and
  failed only in its shard.
- **Reproduction.** `probes/test_p2_catalog_state.py` / `logs/catalog_state.log`: five sequential scans show the order
  flip after a scan without `deep_1m`.
- **Fix.** Commit `736c610` compares the rows as a set. That is the only change; no assertion was dropped.
- **Re-verification.** The future_context mutant still fails against the fixed test.
- **Kept as evidence.** `full_suite/superseded_a24ab45/` (union, JUnit, failing shard log).

## 5. Diagnostic probes (not part of the suite; scratch scripts in `probes/`)

| Probe | Lanes | Result |
|---|---|---|
| `test_p2_friday_trace.py` (CAPTURED responses, 281 cutoffs) | both | 2 passed; traces identical across lanes (0 differing fields); `logs/friday_trace.log` |
| `test_p2_c2_trace.py` at 357668e and at f6e4013 | both | 2 + 2 passed; `traces/C2_TRACE_*` |
| `test_p2_w5_positive.py` | both | real bearish candidate; bearing registered after the death |
| `test_p2_restart_diff.py`, `test_p2_horizon.py` | — | the low-side registry depends on window start (11:41 and 13:17 starts: no 15m low; a 12:16 start: 15m 29022.5@13:29) |
| `test_p2_future_deep.py` | — | with the filter removed, `session_context` and the catalog change, but path and registry do not |
| `test_p2_catalog_state.py` | — | catalog row order depends on scans earlier in the process (see §4) |

## 6. Activated controls

See 03 §5. All ran against the final test file.

| Mutant | Result |
|---|---|
| lost_transport | 4 failed |
| stale_identity | 1 failed |
| future_context | 1 failed |
| duplicate_progression | 1 failed |
| f6_c2_promotion | 9 failed |
| future_identity (recorded, unreachable) | survived |

Healthy twins pass.

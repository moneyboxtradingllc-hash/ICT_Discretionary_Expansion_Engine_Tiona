M2 implementation and self-audit

User selected the recommended initial configuration with "do your thing bro"
on 2026-10-09. Parent: 9d9ea13b683c20d8df7c9688f5547f69af98fc74.
Parent Brain brain:8113f384766ab842, retrieval retr:0c241bdb8234d1ba,
closure47 and all32 protected normalized source pins verified on takeover child.
Remote exact parent verified before implementation; operator checkout preserved.

Chosen values: D0=a; D1=a; D2_ROLES={5m,15m}; K=1;
D3=B; D3_TIME=STRICT; BEARING=INDEPENDENT_SUPPORTING_LIFE;
D4=a; D5=a; D6=a. M2 consumes D1/D2/K/D3/time/bearing/D5/D6 only.
No D6=b suspension or D5=b amendment implementation needed for this release.

Implement the selected branch of complete conditional M2 v3. Exact source paths:
src/market_data/campaign_scope.py (new)
src/ai_brain/production_model.py (one closure entry)
src/ai_brain/brain_input.py (catalog only)
src/ai_brain/brain_prompt.py (optional proposal only)
src/live_scan/production_scan_cycle.py (custody/reset/pre-/post-cognition hooks)
tests/test_campaign_scope.py (new)
tests/test_authorization_source_closure.py (one membership entry)
tests/test_brain_fingerprint_portability.py (literal+comment only)
tests/test_combined_safety_readiness.py (literal+comment only)

Two source-traced draft corrections: real Brain result has no fingerprint;
capture current closure fingerprint before cognition and verify after it,
using existing sovereign model and repair metadata. Catalog additionally
publishes selection_context (known UNBOUND/ACTIVE and direction), sealed in
its digest, so the model can select coherent establish versus transfer kind.
This descriptive shadow input carries no authority. No standalone custody
block is added to Brain input, and no execution consumer reads shadow custody.

Validate actual real-producer facts/chronology, both cognition lanes/brainless,
model/venue transport mocked, no injected detector results. Review source;
exercise activated scratch-only negative controls; preserve parent executable
outcomes under identical mocked responses; all protected pins unchanged;
fresh isolated full suite, collection boundary disclosed. Single normal commit
and review-branch push after audit. Stop at the audited M2 checkpoint; M3 is
the next separately bounded implementation checkpoint. No live deployment.

Exact scope correction from the first focused self-audit (413pass/6fail/1skip):
tests/test_brain_fingerprint_portability.py:37 must update closure47->48;
the draft authorized the new module but omitted this hard-coded count.
tests/test_campaign_premise_shadow.py::test_one_advance_per_scan_and_no_brain_input
must permit ONLY campaign_premise_catalog, asserting its schema, while preserving
the exact one-M1-advance per scan, one-cognition count, raw-shadow/custody ban,
AVAILABLE facts and actual retained candidate. This is the explicit M2 model-
input contract delta, not permission to relax unrelated tests. No other edit
in that file. The first implementation duplicated M1 inventory measurement;
corrected source consumes the existing M1 inventory and observes only <=2
selected retained lives through unchanged M1 reference/certificate helpers.

Full-suite failure exposed a second fault in my new shadow exception path:
an existing real scan integration fixture uses ProductionScanCycle.__new__
without initializing campaign_scope_custody. advance raises as expected, but
the except handler also dereferenced the absent owner and escaped into the
main scan. Guard reset with getattr; retain technical UNAVAILABLE and remove
stale catalog. Preserve the existing wake test unchanged, add a permanent
scope regression. Final full suite must run on the repaired exact patch;
the first fresh full clone remains unchanged as evidence of the initial fault.

Further source self-audit found that conflicting same-cutoff producer facts
revoked the registry, but a later duplicate could rebind the old publication
once that registry entry was absent. Permanent pending and active regressions
both failed before repair. Make revocation sticky for the entire cutoff,
retire ACTIVE as UNKNOWN without failure, void pending, drop retained chains;
only a strictly later cutoff can publish fresh UNBOUND facts. The second full
attempt was stopped as superseded, not counted as a completed full result.

The complete third fresh full run produced8496pass/584skip/1fail/34subtests
passed. The unchanged continuity audit replaces each candle-derived object
with a sentinel: the new rebuild reset blindly called reset on that sentinel.
Fix initializer/rebuild/error reset to call reset ONLY on a real custody
instance, then replace with a new owner as before. Preserve that test, expand
the unavailable-error regression to missing and damaged owner cases. Final
full suite must run on this repaired tree; third full result is failing evidence.

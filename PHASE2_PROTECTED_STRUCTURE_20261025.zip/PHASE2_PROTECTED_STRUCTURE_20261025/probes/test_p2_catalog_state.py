import json, copy
from datetime import datetime, timedelta
import test_protected_structure_continuity as P
def _at(tmp_path, monkeypatch, tag, deep):
    monkeypatch.setenv("OCCURRENCE_LEDGER_DIR", str(tmp_path / tag))
    cut = P._cut("17:15"); rows = [b for b in P.TAPE if b["timestamp"] <= cut][-300:]
    return P._friday_cycle(tag).scan(rows, now=datetime.fromisoformat(cut) + timedelta(minutes=1), invoke_brain=False, deep_1m=deep)
def test_repeat(tmp_path, monkeypatch):
    pre = [b for b in P.TAPE if b["timestamp"] <= P._cut("17:15")]
    out = []
    for i, deep in enumerate([pre, pre, None, copy.deepcopy(P.TAPE), pre]):
        s = _at(tmp_path, monkeypatch, f"r{i}", deep)
        out.append(P._context_view(s)["catalog_rows"])
    print("\nREPEAT", json.dumps([[ (r["supports"], [x["event_time"][11:16] for x in r["raids"]]) for r in rows] for rows in out]))

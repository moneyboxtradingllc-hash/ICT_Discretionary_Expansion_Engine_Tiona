import json
import test_protected_structure_continuity as P
def test_diff(tmp_path, monkeypatch):
    cont = P._friday_cycle("A")
    for h in P._minutes("16:40", "17:15"): c = P._scan(cont, h, False)
    r = P._scan(cont, "17:15", False)
    monkeypatch.setenv("OCCURRENCE_LEDGER_DIR", str(tmp_path / "fresh"))
    k = P._scan(P._friday_cycle("B"), "17:15", False)
    for name, s in (("cont", c), ("repeat", r), ("cold", k)):
        f = P._facts(s)
        print("\n", name, json.dumps(f[1]), json.dumps(f[0]["load_bearing_structure"]), f[0]["owner"], f[0]["status"])

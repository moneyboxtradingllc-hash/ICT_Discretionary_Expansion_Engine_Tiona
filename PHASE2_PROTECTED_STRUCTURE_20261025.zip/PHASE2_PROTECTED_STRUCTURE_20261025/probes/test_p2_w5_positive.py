"""Diagnostic: the existing real D3-B positive (W5, test_campaign_scope_binding) -- which
life bears its local transfer, and when was that life registered vs the incumbent death?"""
import json, pytest
import test_campaign_scope_binding as B
import market_data.campaign_scope as CS
@pytest.mark.parametrize("ecu",[False,True],ids=["non-ecu","ecu"])
def test_w5(tmp_path, monkeypatch, ecu):
    cycle, scan, calls = B._w5_producer(tmp_path, monkeypatch, ecu)
    scan(97); scan(98); t4 = scan(99)
    p = t4["snapshot"]["active_path_state"]
    cand = B._candidate(t4, cycle)
    proof = CS.read_current_campaign_scope(t4["snapshot"])["campaign"]["scope_proof"]
    print("\nW5", "ecu" if ecu else "non-ecu", json.dumps({
        "candidate": cand.direction, "owner": p["owner"], "status": p["status"],
        "bearing": {k: p["load_bearing_structure"].get(k) for k in ("timeframe","level","swing_id","registered_at","at","occurrence_id")},
        "death": {k: p["last_invalidated"].get(k) for k in ("owner","source_tf","level","at","settled_edge_time")},
        "origin": {k: p["origin"].get(k) for k in ("source_tf","at","occurrence_id")},
        "scope": {k: proof.get(k) for k in ("route","R","D","D_source","cited_raid_id")}}))

"""Phase 2 step A: Friday settled-prefix trace at the frozen parent (diagnostic).

Tape: archived PROD-20261023-C1 1m tape from the f6e4013 repository fixture
(tests/fixtures/session_20261023_bearing_handoff.json; provenance in its own
`provenance` field). Cognition: each cutoff's RECORDED original response
(captured judgment, narrative extract sha256 86cd5fc9...; last call per cutoff;
15 degraded calls replayed as provider failures). No model is called and no
judgment is authored. Every scan is a real ProductionScanCycle.scan over the
settled prefix (bars <= cutoff), one minute at a time.
"""
import copy
import gzip
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

EXTRACT = Path(os.environ["NARR_EXTRACT"])
FIXTURE = Path(os.environ["FRIDAY_TAPE_FIXTURE"])
OUT = Path(os.environ["P2_OUT"])
sys.path.insert(0, os.environ["REVIEW_TOOLS"])
sys.path.insert(0, os.environ["P2_PROBES"])
from fields import recover  # noqa: E402
import p2trace as T  # noqa: E402

CONTRACT = "CON.F.US.MNQ.Z26"
DETAIL_FROM, DETAIL_TO = "2026-10-23T16:40:00+00:00", "2026-10-23T17:59:00+00:00"


def _recorded():
    x = json.loads(gzip.decompress(EXTRACT.read_bytes()))
    by_cutoff, all_calls = {}, 0
    for c in x["calls"]:
        rec = c.get("record") or {}
        cut = rec.get("timestamp")
        fields, how = recover(c.get("original_response"))
        all_calls += 1
        by_cutoff[cut] = {"file": c["file"], "source": rec.get("source"), "fields": fields,
                          "recovery": how}
    return x["archive_sha256"], by_cutoff, all_calls


def _find(obj, key):
    if isinstance(obj, dict):
        if key in obj:
            return obj[key]
        for v in obj.values():
            r = _find(v, key)
            if r is not None:
                return r
    elif isinstance(obj, list):
        for v in obj:
            r = _find(v, key)
            if r is not None:
                return r
    return None


@pytest.mark.parametrize("ecu", [False, True], ids=["non-ecu", "ecu"])
def test_friday_trace(tmp_path, monkeypatch, ecu):
    import ai_brain.ecu as ECU
    import ai_brain.narrative_brain as NB
    from ai_brain import production_model as PM
    from ai_brain.brain_schema import empty_brain_output
    from ai_brain.narrative_continuity import _transfer_proof
    from ai_brain.stance_memory import StanceMemory
    from broker.topstepx_slippage import QuoteCapture
    from live_scan.production_scan_cycle import ProductionScanCycle
    import test_reversal_foundation_proof_closure as RF
    from broker.luna_candidate_producer import NoCandidate

    archive_sha, recorded, all_calls = _recorded()
    fx = json.loads(FIXTURE.read_text())
    tape = sorted(fx["tape"], key=lambda b: b["timestamp"])
    for b in tape:
        b["contract"] = CONTRACT
    for key in ("OCCURRENCE_LEDGER_DIR", "AI_BRAIN_DIR", "AI_RETRIEVAL_DIR", "REPLAY_SESSIONS_DIR"):
        monkeypatch.setenv(key, str(tmp_path / key))
    monkeypatch.setenv("BRAIN_ECU_MODE", "true" if ecu else "false")
    monkeypatch.setenv("AI_BRAIN_ENABLED", "false")
    monkeypatch.setenv("AI_BRAIN_LLM", "false")
    state = {"close": tape[0]["close"]}

    def quote():   # CONTROLLED quote at the settled close (not a recorded quote)
        return QuoteCapture(captured_at=datetime.now(timezone.utc), best_bid=state["close"],
                            best_ask=state["close"] + 0.25, last_trade=state["close"],
                            contract_id=CONTRACT, market_data_age_seconds=0.25)
    cycle = ProductionScanCycle(symbol="MNQ", contract_id=CONTRACT,
                                session_id="P2-FRIDAY-TRACE", quote_provider=quote)
    sent, current = [], {}

    def transport(payload, repair=None):
        sent.append({"cutoff": current.get("cut"), "payload": copy.deepcopy(payload)})
        call = current.get("call")
        if call is None or call["source"] != "llm" or not call["fields"].get("market_story"):
            return {"ok": False, "error": "recorded_call_degraded", "parsed": None,
                    "model": None, "provider_request_attempted": False}
        out = empty_brain_output()
        out.update({k: v for k, v in call["fields"].items() if v not in (None, "")})
        out.update(current_action="stand_down", allowed_direction="none",
                   objective_id=None, invalidation_id=None, invalidation_level=None)
        return {"ok": True, "parsed": out, "model": PM.PRODUCTION_MODEL,
                "prompt": "recorded replay", "user_content": "recorded replay",
                "raw_response": copy.deepcopy(out), "usage": {}}

    def scan(cut, brain):
        rows = [b for b in tape if b["timestamp"] <= cut][-300:]
        state["close"] = rows[-1]["close"]
        now = datetime.fromisoformat(cut) + timedelta(minutes=1)
        return cycle.scan(rows, now=now, invoke_brain=brain)

    cutoffs = sorted(c for c in recorded if c)
    warm = (datetime.fromisoformat(cutoffs[0]) - timedelta(minutes=1)).isoformat()
    scan(warm, False)
    memory = StanceMemory(persist=False)
    monkeypatch.setattr(ECU, "_stance", lambda: memory)
    monkeypatch.setattr(NB, "persist_brain_call", lambda *a, **k: None)
    monkeypatch.setattr(NB, "_call_llm", transport)
    monkeypatch.setenv("AI_BRAIN_ENABLED", "true")
    monkeypatch.setenv("AI_BRAIN_LLM", "true")

    trace = []
    minute = datetime.fromisoformat(cutoffs[0])
    end = datetime.fromisoformat(cutoffs[-1])
    while minute <= end:
        cut = minute.isoformat()
        call = recorded.get(cut)
        current.update(cut=cut, call=call)
        before = len(sent)
        result = scan(cut, call is not None)
        snap = result.get("snapshot") or {}
        path = snap.get("active_path_state") or {}
        block = result.get("brain_block") or {}
        if ecu and isinstance(block.get("brain_block"), dict):
            block = block["brain_block"]
        nc = (block or {}).get("narrative_continuity") or {}
        prior = ((nc.get("prior_thesis") or {}).get("direction"))
        frm = prior or ("bullish" if path.get("owner") == "bearish" else "bearish")
        gates, first = T.transfer_gates(path, frm, path.get("owner"))
        real = _transfer_proof(path, frm, path.get("owner"))
        assert (real is not None) == (first is None)
        mech = (path.get("last_invalidated") or {}).get("owner")
        mgates, mfirst = T.transfer_gates(path, mech, path.get("owner"))
        assert (_transfer_proof(path, mech, path.get("owner")) is not None) == (mfirst is None)
        row = {"cutoff": cut, "brain_called": call is not None,
               "first_failed_transfer_gate_vs_mechanical_incumbent": mfirst,
               "provider_calls": len(sent) - before,
               "registry": T.registry(snap), "active_path_state": T.path_view(path),
               "transfer_gates_from": frm, "first_failed_transfer_gate": first,
               "transfer_gates": gates}
        if call is not None:
            payload = sent[-1]["payload"] if len(sent) > before else None
            ps = _find(payload, "protected_swings") if payload else None
            read = (block or {}).get("authored_market_read") or {}
            try:
                RF._produce_candidate(result)
                cand = "PRODUCED"
            except NoCandidate as exc:
                cand = exc.reason
            except Exception as exc:  # noqa: BLE001
                cand = f"error:{type(exc).__name__}"
            row.update({
                "recorded_source": call["source"], "recorded_file": call["file"],
                "provider_seam_protected_swings_by_timeframe":
                    (copy.deepcopy((ps or {}).get("by_timeframe")) if isinstance(ps, dict) else None),
                "provider_seam_has_active_path_state": bool(_find(payload, "active_path_state"))
                    if payload else None,
                "narrative_continuity": T.continuity_view(nc),
                "campaign_lifecycle": T._pick(result.get("campaign_lifecycle"),
                                              ("state", "reason")),
                "scope": T.scope_view(snap),
                "authored": {k: read.get(k) for k in ("status", "narrative_direction",
                                                      "authored_action", "market_story",
                                                      "protected_high_interpretation")},
                "guarded": T._pick((block or {}).get("output"),
                                   ("narrative_direction", "current_action",
                                    "allowed_direction", "invalidation_level")),
                "candidate": cand})
        trace.append(row)
        minute += timedelta(minutes=1)

    ledger = cycle.occurrence_ledger.occurrences()
    OUT.mkdir(parents=True, exist_ok=True)
    lane = "ecu" if ecu else "non-ecu"
    (OUT / f"FRIDAY_TRACE_{lane}.json").write_text(json.dumps(
        {"archive_sha256": archive_sha, "recorded_calls_total": all_calls,
         "replayed_cutoffs": len([r for r in trace if r["brain_called"]]),
         "scanned_minutes": len(trace),
         "ledger_high_lives": T.ledger_lives(ledger, "high"),
         "ledger_low_lives": T.ledger_lives(ledger, "low"),
         "ledger_sweeps": T.sweeps(ledger),
         "trace": [r for r in trace if DETAIL_FROM <= r["cutoff"] <= DETAIL_TO],
         "summary": [{k: r.get(k) for k in ("cutoff", "first_failed_transfer_gate",
                                        "first_failed_transfer_gate_vs_mechanical_incumbent")}
                     | {"owner": r["active_path_state"]["owner"],
                        "status": r["active_path_state"]["status"],
                        "control_state": (r.get("narrative_continuity") or {}).get("control_state"),
                        "candidate": r.get("candidate")} for r in trace]},
        indent=1, default=str))

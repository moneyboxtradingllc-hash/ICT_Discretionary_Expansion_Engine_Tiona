"""Phase 2 step A: C2 per-scan trace through the real ProductionScanCycle.

Same harness as tests/test_campaign_leg_scope_labels.py (CONTROLLED mocked
Brain response from test_campaign_draw_temporal_authority; synthetic settled
bars). Run unchanged against the parent (357668e) and the rejected f6e4013
revision to show where the f6 binder changes the proof.
"""
import copy
import json
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, os.environ["P2_PROBES"])
import p2trace as T  # noqa: E402
import test_campaign_draw_temporal_authority as TA  # noqa: E402
import test_reversal_foundation_proof_closure as RF  # noqa: E402
import test_stance_history_hygiene as H  # noqa: E402
import test_campaign_leg_scope_labels as L  # noqa: E402

OUT = Path(os.environ["P2_OUT"])


@TA.ECU_MODES
def test_c2_trace(tmp_path, monkeypatch, ecu):
    from ai_brain.narrative_continuity import _transfer_proof
    cycle, calls = H._lane(tmp_path, monkeypatch, ecu)
    sent = H._capture_transport(monkeypatch)
    H._brain_scan(cycle, calls, RF.TAPE_1M)
    H._brain_scan(cycle, calls, TA.LATER)
    rows = list(TA.LATER)
    trace = []
    for b in L.SCENARIOS["C2"]:
        rows = rows + [b]
        scan, _ = H._brain_scan(cycle, calls, rows)
        snap = scan["snapshot"]
        path = snap["active_path_state"]
        nc = scan["brain_block"]["narrative_continuity"]
        transported = sent[-1][1]
        frm = (nc.get("prior_thesis") or {}).get("direction") or "bullish"
        gates, first = T.transfer_gates(path, frm, path.get("owner"))
        assert (_transfer_proof(path, frm, path.get("owner")) is not None) == (first is None)
        trace.append({
            "cutoff": b["timestamp"], "registry": T.registry(snap),
            "active_path_state": T.path_view(path),
            "transfer_gates_from": frm, "first_failed_transfer_gate": first,
            "transfer_gates": gates,
            "provider_seam_protected_swings_by_timeframe":
                copy.deepcopy((transported.get("protected_swings") or {}).get("by_timeframe")),
            "narrative_continuity": T.continuity_view(nc),
            "campaign_lifecycle": T._pick(scan["campaign_lifecycle"], ("state", "reason")),
            "scope": T.scope_view(snap),
            "guarded": T._pick(scan["brain_block"]["output"],
                               ("narrative_direction", "current_action",
                                "allowed_direction", "invalidation_level")),
            "candidate": L._candidate(scan)})
    ledger = cycle.occurrence_ledger.occurrences()
    OUT.mkdir(parents=True, exist_ok=True)
    lane = "ecu" if ecu else "non-ecu"
    tag = os.environ.get("P2_TAG", "parent")
    (OUT / f"C2_TRACE_{tag}_{lane}.json").write_text(json.dumps(
        {"source": tag, "ledger_high_lives": T.ledger_lives(ledger, "high"),
         "ledger_low_lives": T.ledger_lives(ledger, "low"),
         "ledger_sweeps": T.sweeps(ledger), "trace": trace}, indent=1, default=str))

import json, copy
from datetime import datetime, timedelta
import test_protected_structure_continuity as P
from live_scan.production_scan_cycle import ProductionScanCycle as PSC
def _run(tmp_path, monkeypatch, tag, deep):
    monkeypatch.setenv("OCCURRENCE_LEDGER_DIR", str(tmp_path / tag))
    cyc = P._friday_cycle(tag)
    cut = P._cut("17:15")
    rows = [b for b in P.TAPE if b["timestamp"] <= cut][-300:]
    return cyc.scan(rows, now=datetime.fromisoformat(cut) + timedelta(minutes=1), invoke_brain=False, deep_1m=deep)
def test_future(tmp_path, monkeypatch):
    prefix = [b for b in P.TAPE if b["timestamp"] <= P._cut("17:15")]
    a = _run(tmp_path, monkeypatch, "pre", prefix)
    monkeypatch.setattr(PSC, "_settled_context_input", staticmethod(lambda deep, cutoff: deep))
    b = _run(tmp_path, monkeypatch, "fut", list(P.TAPE))
    sa, sb = a["snapshot"], b["snapshot"]
    diff = sorted(k for k in set(sa) | set(sb) if json.dumps(sa.get(k), sort_keys=True, default=str) != json.dumps(sb.get(k), sort_keys=True, default=str))
    print("\nDIFFKEYS", diff)
    print("FACTS_EQUAL", P._facts(a) == P._facts(b))

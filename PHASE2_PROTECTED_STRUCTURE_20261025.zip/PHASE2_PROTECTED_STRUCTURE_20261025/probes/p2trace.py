"""Phase 2 diagnostic trace helpers (read-only; never imported by src).

Every value is copied from the actual scan result with its ORIGINAL field
name. `transfer_gates` re-evaluates, conjunct by conjunct, the exact
predicate of `ai_brain.narrative_continuity._transfer_proof` at 357668e
(lines 339-384) on the actual published path, so the FIRST failing conjunct
can be named. It is diagnostic only: the authoritative result is the real
`_transfer_proof` value, recorded beside it, and the two are asserted equal.
"""
import copy


def _pick(d, keys):
    d = d if isinstance(d, dict) else {}
    return {k: copy.deepcopy(d.get(k)) for k in keys}


LIFE_KEYS = ("level", "timeframe", "swing_id", "registered_at", "basis")


def registry(snapshot):
    bt = ((snapshot or {}).get("protected_swings") or {}).get("by_timeframe") or {}
    return {side: {tf: _pick(rec, LIFE_KEYS) for tf, rec in (bt.get(side) or {}).items()}
            for side in ("highs", "lows")}


def transfer_gates(path, frm, to):
    """Ordered conjuncts of _transfer_proof; returns (list, first_failed)."""
    from ai_brain.narrative_continuity import (_authoritative_opposing_origin,
                                               _load_bearing, _timestamp_after)
    path = path if isinstance(path, dict) else {}
    died = path.get("last_invalidated") or {}
    origin = path.get("origin") or {}
    prog = path.get("progression") or {}
    bearing = _load_bearing(path)
    side = "low" if to == "bullish" else "high"
    died_at, origin_at = str(died.get("at") or ""), str(origin.get("at") or "")
    gates = [
        ("G0_state_available", path.get("state_available") is True),
        ("G0b_directions_valid_and_differ",
         frm in ("bullish", "bearish") and to in ("bullish", "bearish") and frm != to),
        ("G1_owner_is_to_direction", path.get("owner") == to),
        ("G2_status_active", path.get("status") == "active"),
        ("G3_incumbent_invalidation_owner_is_from", died.get("owner") == frm),
        ("G4_origin_after_invalidation",
         bool(died_at and origin_at and _timestamp_after(origin_at, died_at))),
        ("G5_authoritative_opposing_origin", _authoritative_opposing_origin(origin, to)),
        ("G6_structural_progression",
         bool(prog.get("supporting_timeframes") or prog.get("highest_confirmed"))),
        ("G7_load_bearing_present", bearing is not None),
        ("G8_load_bearing_expected_side", bool(bearing and bearing.get("side") == side)),
        ("G9_load_bearing_intact", bool(bearing and bearing.get("intact") is True)),
    ]
    first = next((name for name, ok in gates if not ok), None)
    return [{"gate": n, "pass": bool(ok)} for n, ok in gates], first


def path_view(path):
    path = path if isinstance(path, dict) else {}
    return {
        **_pick(path, ("state_available", "unavailable_reason", "contract_id", "session",
                       "owner", "forming_direction", "status", "ownership_changed_this_scan")),
        "origin": _pick(path.get("origin"), ("proof_family", "event", "direction", "at",
                                              "source_tf", "source_bar_time",
                                              "settled_edge_time", "observed_at",
                                              "occurrence_id")),
        "load_bearing_structure": copy.deepcopy(path.get("load_bearing_structure")),
        "last_invalidated": copy.deepcopy(path.get("last_invalidated")),
        "progression": copy.deepcopy(path.get("progression")),
        "transfer_evidence": copy.deepcopy(path.get("transfer_evidence")),
    }


def continuity_view(nc):
    nc = nc if isinstance(nc, dict) else {}
    return _pick(nc, ("control_state", "dominant_direction", "prior_direction",
                      "transfer_proof", "active_leg_failure_status",
                      "prior_active_leg_failure_status", "active_leg_structure",
                      "active_leg_structure_source", "campaign_premise",
                      "campaign_scope", "entry_refusal_reason", "hold_reason"))


def scope_view(snapshot):
    s = snapshot or {}
    custody = s.get("campaign_scope_custody") or {}
    catalog = s.get("campaign_premise_catalog") or {}
    shadow = s.get("campaign_premise_shadow") or {}
    lives = [{**_pick(l, ("source_tf", "side", "level", "swing_id", "registered_at",
                          "contract_id")),
              "sweep_occurrence_ids": list(l.get("sweep_occurrence_ids") or [])}
             for l in (shadow.get("lives") or []) if isinstance(l, dict)]
    rows = [_pick(r, ("supports", "life_ref", "eligible", "reason", "raids",
                      "selection_reason"))
            for r in (catalog.get("rows") or []) if isinstance(r, dict)]
    return {"custody": _pick(custody, ("status", "reason", "authority", "campaign")),
            "catalog_status": catalog.get("status"), "catalog_rows": rows,
            "shadow_status": shadow.get("status"), "shadow_reason": shadow.get("reason"),
            "shadow_lives": lives}


def ledger_lives(rows, side, cutoff=None):
    """PROTECTED_SWING_* receipts for one side, original fields."""
    keep = ("event_type", "occurrence_id", "source_tf", "side", "level", "old_level",
            "swing_id", "registered_at", "old_swing_id", "old_registered_at", "basis",
            "event_time", "source_bar_time", "settled_edge_time", "observed_at")
    out = []
    for r in rows or []:
        if (isinstance(r, dict) and str(r.get("event_type", "")).startswith("PROTECTED_SWING")
                and r.get("side") == side):
            if cutoff is None or str(r.get("event_time") or "") <= cutoff:
                out.append(_pick(r, keep))
    return sorted(out, key=lambda x: (str(x["event_time"]), str(x["occurrence_id"])))


def sweeps(rows, cutoff=None):
    keep = ("occurrence_id", "source_tf", "sweep_direction", "swept_level", "event_time",
            "source_bar_time", "settled_edge_time", "observed_at",
            "protected_swing_lifetime")
    return [_pick(r, keep) for r in rows or []
            if isinstance(r, dict) and r.get("event_type") == "LIQUIDITY_SWEEP"
            and (cutoff is None or str(r.get("event_time") or "") <= cutoff)]

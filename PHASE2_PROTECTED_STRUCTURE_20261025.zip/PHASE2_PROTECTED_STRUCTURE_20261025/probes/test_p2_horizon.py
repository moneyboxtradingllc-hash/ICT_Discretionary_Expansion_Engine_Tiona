import json
from datetime import datetime, timedelta
import test_protected_structure_continuity as P
def test_horizon(tmp_path, monkeypatch):
    out = {}
    for start in ("11:41", "12:16", "13:17"):
        monkeypatch.setenv("OCCURRENCE_LEDGER_DIR", str(tmp_path / start))
        cyc = P._friday_cycle("H" + start)
        rows = [b for b in P.TAPE if P._cut(start) <= b["timestamp"] <= P._cut("17:15")]
        s = cyc.scan(rows, now=datetime.fromisoformat(P._cut("17:15")) + timedelta(minutes=1), invoke_brain=False)
        f = P._facts(s)
        out[start] = (len(rows), f[1]["lows"], f[0]["owner"], f[0]["load_bearing_structure"])
    print("\nHORIZON", json.dumps(out))

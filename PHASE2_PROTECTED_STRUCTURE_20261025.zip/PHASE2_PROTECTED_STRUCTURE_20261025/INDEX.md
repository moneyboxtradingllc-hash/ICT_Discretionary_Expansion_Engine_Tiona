# PHASE 2 return package: index

| File | Contents |
|---|---|
| 00_COMPLETION_REPORT.md | Disposition, identity, the six §8 answers, classifications |
| 01_SOURCE_AND_AUTHORITY.md | Call graph with lines, dated primary authority, pins, full diff, expectation updates (none) |
| 02_TRACEABILITY.md | The supplied matrix, completed; per-cutoff first-failure traces; Friday-vs-C2 witness table |
| 03_BEFORE_AFTER_AND_CONTROLS.md | Judgment provenance, Friday/C2/W5 results, activated mutations, §6 families |
| 04_VERIFICATION.md | Runtime/isolation, ledger, focused results, full suite (final and superseded), probes |
| 05_REMAINING_AUTHORITY_LIMITS.md | Q-BEARING-R (proposed, disabled) and separate limitations |
| FULL_DIFF_357668e..736c610.patch | `git diff 357668e 736c610` |
| PHASE2_review_357668e..736c610.bundle | Git bundle of the two review commits (prerequisite 357668e) |
| authority/ | MISSION.md (2026-10-09 selection), D0_D6_table_v3.txt, 02_ARCHITECTURAL_CONSTITUTION.md |
| traces/ | FRIDAY_TRACE_{ecu,non-ecu}.json; C2_TRACE_{parent,f6e4013}_{ecu,non-ecu}.json |
| probes/ | Scratch diagnostic scripts (not in the repository) |
| mutants/ | mutate.py, f6_binder.diff, final run logs and JUnit; superseded_first_runs/ |
| full_suite/ | Final JUnit, shard logs, collection, shard plan, union, skip reasons, focused table; superseded_a24ab45/ |
| logs/ | Probe logs, ledger verification at parent and final, parent fingerprints |
| MANIFEST_SHA256.txt | sha256 of every file above |

To reproduce: `git fetch <bundle> review/protected-structure-reconciliation-20261025` onto a clone containing 357668e.

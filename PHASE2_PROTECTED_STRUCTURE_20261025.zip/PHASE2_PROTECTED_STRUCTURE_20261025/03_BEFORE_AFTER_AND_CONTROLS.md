# 03 — Before/after, controls and judgment labels

**No production source changed.** "Before" (357668e) and "after" (736c610) are the same code, so every behavioural
result below holds at both. The after-SHA adds only the permanent tests that pin it.

## 1. Judgment and quote provenance

| Evidence | Judgment source | Quotes |
|---|---|---|
| `traces/FRIDAY_TRACE_{ecu,non-ecu}.json` (`probes/test_p2_friday_trace.py`) | **CAPTURED**: the recorded original response per cutoff (narrative extract sha256 `86cd5fc9…`), last call per cutoff = 281 of 397 recorded calls. 15 degraded calls served as provider failures. Fields recovered from `llm_raw_response`; truncated fields at stand-down defaults; every action forced to its recorded stand_down | CONTROLLED (settled close ± 0.25) |
| `traces/C2_TRACE_{parent,f6e4013}_{lane}.json` (`probes/test_p2_c2_trace.py`) | **CONTROLLED** mock from `test_campaign_draw_temporal_authority` (the same harness as the pinned C2 tests) | Fixed test quote |
| `tests/test_protected_structure_continuity.py` (Friday cases) | **CONTROLLED** stand-down mock; direction labels chosen by the test | None (no quote provider) |
| `logs/w5_positive.log` (`probes/test_p2_w5_positive.py`) | **CONTROLLED** mock of the existing W5 D3-B test | Existing test quote |

No mocked entry was substituted for any historical stand-down. No current model was called.

## 2. Friday: settled-prefix replay, every minute 13:18–17:58Z (281 cutoffs, after one brainless 13:17 warm scan), both lanes

- **Lanes identical.** Summary and detail comparison: 0 differing fields across 281 minutes. Ledger high lives and
  sweeps are equal.
- **Fact.** `protected_swings.by_timeframe.highs.1m` is the 16:48 life at every cutoff 16:48–17:58, and the identical
  record is in the transported provider payload at every cognition.
- **Authority.** At 17:15 the bearish owner is active with no bearing. The first failed conjunct is
  `G7_load_bearing_present`; the guarded state is developing_transfer / TRANSFER_UNRESOLVED;
  the candidate is `campaign_lifecycle_refused`.
- **Captured cognition** at 17:05–17:16: `conflicted` at every cutoff except 17:13 (`bearish`). All AVAILABLE; all
  stand_down.

## 3. C2 parent vs rejected f6e4013, both lanes (CONTROLLED)

| Scan | 357668e | f6e4013 |
|---|---|---|
| 03:05 | bullish active, bearing 1m 29457@02:56, incumbent_intact, propose_entry | same (ladder already `[29428.75, 29457.0]` vs parent `[29457.0]`: f6 binds a pre-origin life earlier in the session too) |
| 03:06 | none; death 1m 29457@03:06; developing_transfer; refused | same |
| 03:07 | bearish active, **no bearing**, first fail G7; developing_transfer; `campaign_lifecycle_refused` | **bearing 5m 29500@03:04 bound**; `confirmed_transfer`; Lifecycle AUTHORITY_UNKNOWN; refused |
| 03:08–03:14 | developing_transfer; refused | **incumbent_intact (bearish)**; refused only by Lifecycle |

In both, the 5m 29500 registry record reaches the provider seam unchanged. Only the authority differs.

## 4. Genuine authorized positive (existing route, real graph)

W5 (CONTROLLED), both lanes: bearish candidate produced at T4.

- **Bearing.** 5m 29519.75 `5m:swing_high:29519.8`, registered 14:29, after the death (1m 29524.25 @14:23) and the
  origin (1m @14:25).
- **Scope.** Route B; R 14:25 > D 14:23 (`1m_source`).

The full suite runs the permanent forms at 736c610, both lanes:

- `test_campaign_scope_binding::test_real_t2_pending_t3_newborn_refusal_t4_candidate`;
- `…::test_real_bound_plan_survives_fresh_cutoff_and_refuses_lost_custody` (sealed plan / fresh cutoff / custody loss);
- `test_conditional_plan_across_alignment_step::test_sealed_plan_triggers_through_the_final_quote_across_the_step`;
- `test_latency1_final_quote_zone::*`.

**Matched witness removal** (FICTIONAL symmetric tape, both directions; `test_same_life_bears_only_when_registered_inside_the_new_leg`):

| Same life registered… | Bearing | `_transfer_proof` |
|---|---|---|
| inside the new leg (healthy) | bound | verified |
| before the incumbent's death (witness removed) | none | None |

## 5. Activated mutations (scratch only, never committed; `mutants/`)

Each mutation was applied to a fresh detached worktree of 357668e carrying the final test file and fixture
(`mutants/mutate.py`). The healthy twin is the unmutated tree.

| # | Family (§6) | Mutation (exact edit) | Tests run | Result on mutant | First causal failure | Healthy twin |
|---|---|---|---|---|---|---|
| i | Lost retained-fact transport | `brain_input._protected`: `"by_timeframe": ps.get("by_timeframe") or {}` → `{}` | new file | **4 failed** / 6 passed | Friday ×2 lanes and C2 ×2 lanes: the provider-seam `protected_swings.by_timeframe.highs` record is missing | Unmutated 10/10 pass; full suite at 736c610 |
| ii-a | Stale identity acceptance | `_retained_leg_projection`: drop the `registered_at` equality with the producer release | `test_retained_leg_projection.py` + new file | **1 failed** / 59 passed | `test_uncorroborated_by_producer_release_is_withheld[other_registration_life]` (same price, other life) | Passes unmutated |
| ii-b | Future availability | `_settled_context_input`: return `deep_1m` unfiltered | new file | **1 failed** / 9 passed | `test_future_session_bars_offered_as_deep_context_are_never_used`: `session_context` and catalog differ when bars after 17:15 are visible | Passes unmutated |
| ii-c | (recorded only) | `campaign_scope_proof`: drop the "died/origin after cutoff" guards | `test_campaign_scope.py` | **survived** (49 passed) | Not reachable from a real scan; reported in 05, not used as a control | — |
| iii | Duplicate progression | `ActivePath.ingest`: `if key and key in self._seen:` → `if False:` | new file | **1 failed** / 9 passed | `test_duplicate_or_replayed_registration_awards_no_progression`: the history replay re-points the bearing at the superseded 100.0 life (adverse replacement) | Passes unmutated |
| iv | f6-style C2 promotion | `git apply mutants/f6_binder.diff` (exact `src` diff ffe00ae..f6e4013: `reconcile_current_structure` + the scan-cycle call) | new file + `test_campaign_leg_scope_labels.py` + `test_retained_leg_projection.py` | **9 failed** / 73 passed | Friday ×2 (bearing 1m 29263 bound), restart (cold binds), C2 ×2 (bearing 5m 29500 bound), the four pinned C2 cases (`incumbent_intact` ≠ `developing_transfer`) | All pass unmutated |

Logs and JUnit for each are in `mutants/run_<name>.log` and `junit_<name>.xml`, and every rerun used the final test file.
`mutants/superseded_first_runs/` keeps the first runs, which used an earlier draft of the test file. Two results
differ there:

- the first duplicate_progression draft survived (its replay ran before the newer life existed), which is why case N7
  was strengthened;
- future_identity was the original future control and survived (ii-c).


## 6. Proof-matrix families (Phase 2 §6)

| Family | Healthy | Matched refusal | Where |
|---|---|---|---|
| Retained fact | Current intact life, original identity, at provider seam, both lanes | Same-price retired life (29263@16:45 VIOLATED 16:46) is not the current life; retired/replaced lives absent from the registry | N1, N2 |
| Time/scope | Settled cutoff only | Future suffix via deep context unused (mutant caught); wrong contract/session/revision/forming-bar refusals: existing `test_stance_history_hygiene`, `test_campaign_scope` (producer-ownership/forgery), `test_market_narrative_first` | N4 + full suite |
| Ownership transition | Fact survives the bullish→bearish change | Survival does not make C2 (or Friday) a transfer or candidate | N1, N5 |
| Genuine authorized path | W5 real candidate | Witness removal → no bearing/proof; D3 negatives | §4 |
| Progression | New favourable replacement advances exactly once | Duplicate/replay awards nothing and cannot re-point the bearing | N7 |
| Rebuild/chronology | Continuous = duplicate cutoff = fresh-process restart (path + highs) | Future suffix unused; low-side horizon limitation recorded | N3, N4 |
| Narrative | Authored read in the next input, labelled OBSERVATIONAL_ONLY, beside unconfirmed continuity | Refusal does not overwrite the authored read; no consumer reads narrative for authority (Phase 1 reader-scope test) | N1 + Phase 1 suite |
| Execution composition | Existing plan/final-quote positives | Fact-only state reaches no candidate or plan (Friday every cutoff refused) | §4 + full suite |

N1–N7 are the cases of `tests/test_protected_structure_continuity.py`, in file order, at 736c610.

"""Activated failure-clock controls (LOCAL-AUTHORITY-FAILURE-CLOCK-20261027).

usage: python clock_mutants.py <frozen_repo> <workdir> <out.json>
Each mutant copies the frozen tree (no .git), applies ONE source edit and runs
the clock tests, which must turn red; the unmutated copy must pass them.
"""
import json, os, shutil, subprocess, sys

S = "[scratch]"
LA = "src/market_data/local_authority.py"
PLP = "src/broker/topstepx_production_loop.py"
T = "tests/test_local_authority_existing_policy_release.py"
TESTS = [f"{T}::test_the_compiled_selection_is_the_existing_policy_repair_only",
         f"{T}::test_normal_launch_resolves_the_compiled_repair_with_real_bindings"]
MUTANTS = [
    ("P1_loop_omits_constructor_forwarding", PLP,
     "            local_authority_profile=local_authority_profile)\n        if (local_authority_profile is not None\n                and self.cycle.local_authority.profile is not local_authority_profile):\n            # Refused (e.g. offline beside execution switches): fail, never run\n            # as legacy DISABLED while the caller believes the profile is on.\n            raise LA.ProfileSelectionRefused(\n                self.cycle.local_authority.profile_reason or \"requested_profile_refused\")",
     "            )"),
    ("P2_all_three_selected", LA, "RELEASE_SELECTION = PRODUCTION_EXISTING_POLICY_REPAIR_V1",
     "RELEASE_SELECTION = PRODUCTION_PROFILE_V1"),
    ("P3_retained_support_enabled", LA, '"local_authority_existing_policy_repair/v1", True, False, False)',
     '"local_authority_existing_policy_repair/v1", True, True, False)'),
    ("P4_delivery_change_enabled", LA, '"local_authority_existing_policy_repair/v1", True, False, False)',
     '"local_authority_existing_policy_repair/v1", True, False, True)'),
]


def run(repo, log):
    cmd = [f"{S}/g5/run.sh", repo, log, "python", "-m", "pytest", "-q", "-p", "no:cacheprovider", *TESTS]
    return subprocess.run(cmd, capture_output=True, text=True).returncode


def main(frozen, work, out):
    os.makedirs(work, exist_ok=True)
    results = []
    for name, rel, old, new in [("UNMUTATED", LA, None, None)] + MUTANTS:
        dest = os.path.join(work, name)
        shutil.rmtree(dest, ignore_errors=True)
        shutil.copytree(frozen, dest, ignore=shutil.ignore_patterns(".git", "__pycache__"))
        if old is not None:
            path = os.path.join(dest, rel)
            text = open(path).read()
            if text.count(old) != 1:
                results.append({"mutant": name, "status": "NOT_APPLIED", "matches": text.count(old)})
                continue
            open(path, "w").write(text.replace(old, new))
        rc = run(dest, os.path.join(work, name + ".log"))
        status = ("PASS" if rc == 0 else "FAIL") if old is None else \
            ("KILLED" if rc == 1 else ("ERROR" if rc not in (0, 1) else "SURVIVED"))
        results.append({"mutant": name, "file": rel, "exit": rc, "status": status})
        shutil.rmtree(dest, ignore_errors=True)
        print(name, status, flush=True)
    json.dump(results, open(out, "w"), indent=1)


if __name__ == "__main__":
    main(*sys.argv[1:4])

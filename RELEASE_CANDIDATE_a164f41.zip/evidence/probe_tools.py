import tempfile, pathlib, json, pytest
import local_authority_loop as H
with pytest.MonkeyPatch.context() as m:
    r=H.run(m, pathlib.Path(tempfile.mkdtemp()), ecu=True, profile=None, warmup="15:36", schedule=H.minutes("15:56","15:57"), act_from="15:56", direction="bullish", session="M1-T", launcher=True)
    s=r["scans"][-1]; cat=s["brain_input"].get("authorized_tool_catalog",[])
    print("catalog", [(c.get("tool_family"),c.get("direction"),c.get("execution_eligible"),c.get("source_tf"),c.get("zone_low"),c.get("zone_high")) for c in cat])
    br=s["brain_result"] or {}; out=br.get("output") if isinstance(br,dict) else None
    print("reply_tools", json.dumps({k:(out or br).get(k) for k in ("current_action","recommended_tool_family","recommended_tool_occurrence_id")},default=str))
    print("outcome", r["outputs"]["15:57"].get("outcome"))

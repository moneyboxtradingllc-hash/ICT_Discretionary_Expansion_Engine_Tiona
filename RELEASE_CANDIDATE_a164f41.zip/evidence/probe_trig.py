import json, pytest
import test_local_authority_existing_policy_release as T
class F:
    def mktemp(self, n):
        import tempfile, pathlib; return pathlib.Path(tempfile.mkdtemp())
w = T._plan_world(F(), True)
z = w["plan"]["candidate"].extras["activation_zone"]
print("zone", z, "binding", json.dumps(w["binding"], default=str)[:300])
t = w["trigger"]; print("trigger", t.get("outcome"), t.get("reason"), json.dumps(t, default=str)[:900])
print("bar1558", [b for b in __import__("test_protected_structure_continuity").TAPE if b["timestamp"].endswith("15:58:00+00:00")])

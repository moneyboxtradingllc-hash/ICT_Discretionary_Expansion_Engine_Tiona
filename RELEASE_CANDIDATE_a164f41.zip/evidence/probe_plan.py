import tempfile, pathlib, json, pytest
import local_authority_loop as H
with pytest.MonkeyPatch.context() as m:
    for k in ("EXECUTION_ENABLED","ALLOW_PAPER_ORDERS","AUTO_EXECUTION_ENABLED","TOPSTEPX_ARM_ORDERS"): m.setenv(k,"true")
    for watch in (True,):
        r=H.run(m, pathlib.Path(tempfile.mkdtemp()), ecu=True, profile=None, warmup="15:36", schedule=H.minutes("15:48","15:57"), act_from="15:49", direction="bullish", session="M1-PLAN", watch="nearest", launcher=True)
        print("watch",watch,{hm:(o.get("outcome"),o.get("reason")) for hm,o in r["outputs"].items()})
        print("plan", r["loop"].active_conditional_plan is not None)

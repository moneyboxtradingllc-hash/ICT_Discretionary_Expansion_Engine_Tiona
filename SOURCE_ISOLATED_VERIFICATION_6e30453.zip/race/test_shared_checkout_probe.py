"""Controlled source-probe interference on a disposable source copy, no live calls."""
import contextlib,hashlib,subprocess,sys,time,json
from pathlib import Path
import pytest
from ai_brain import production_model as PM
from broker import conditional_plan_authority as CPA
from broker.luna_candidate_producer import NoCandidate
import test_conditional_plan_authority as C
import test_latency1_final_quote_zone as L

@contextlib.contextmanager
def held_probe(tmp_path):
    source=Path(PM.__file__).resolve().parents[1]/'market_data/local_authority.py'
    before=source.read_bytes();ready=tmp_path/'ready';release=tmp_path/'release'
    worker="""from pathlib import Path
import sys,time
p,ready,release=map(Path,sys.argv[1:]);original=p.read_bytes()
try:
 p.write_bytes(original+b'\\n# closure probe\\n');ready.write_text('ready')
 end=time.monotonic()+15
 while not release.exists() and time.monotonic()<end:time.sleep(.01)
finally:p.write_bytes(original)
"""
    child=subprocess.Popen([sys.executable,'-c',worker,str(source),str(ready),str(release)])
    try:
        end=time.monotonic()+10
        while not ready.exists() and time.monotonic()<end:time.sleep(.01)
        assert ready.exists()
        yield
    finally:
        release.write_text('release');assert child.wait(timeout=20)==0
        assert source.read_bytes()==before

def test_real_capture_refuses_only_while_other_process_holds_closure_probe(monkeypatch,tmp_path):
    healthy=C.context(monkeypatch)
    assert healthy[-1] is not None
    original=CPA._verify_authorization;record={}
    def during_probe(authorization,**kwargs):
        with held_probe(tmp_path):
            try:authorization.verify(account_fingerprint=kwargs['account_fingerprint'],contract_id=kwargs['contract_id'],session_date=authorization.session_date,now=kwargs['now'])
            except Exception as exc:record['exact_guard']=str(exc)
            result=original(authorization,**kwargs)
            record['result']=result
            return result
    with monkeypatch.context() as m:
        m.setattr(CPA,'_verify_authorization',during_probe)
        with pytest.raises(ValueError,match='session_authorization_invalid:AuthorizationRefused'):
            C.context(m)
    assert 'AUTHORIZATION_BRAIN_CONTRACT_CHANGED' in record['exact_guard']
    assert C.context(monkeypatch)[-1] is not None
    (tmp_path/'capture_control.json').write_text(json.dumps(record,indent=2))

def test_real_trigger_refuses_only_while_other_process_holds_closure_probe(monkeypatch,tmp_path):
    assert L._verified_trigger(monkeypatch)[2] is not None
    original=L.context;holder={}
    def capture_then_probe(*args,**kwargs):
        result=original(*args,**kwargs)
        holder['cm']=held_probe(tmp_path);holder['cm'].__enter__()
        return result
    try:
        with monkeypatch.context() as m:
            m.setattr(L,'context',capture_then_probe)
            with pytest.raises(NoCandidate,match='conditional_plan_environment_lineage_changed'):
                L._verified_trigger(m)
    finally:
        if holder.get('cm'):holder['cm'].__exit__(None,None,None)
    assert L._verified_trigger(monkeypatch)[2] is not None

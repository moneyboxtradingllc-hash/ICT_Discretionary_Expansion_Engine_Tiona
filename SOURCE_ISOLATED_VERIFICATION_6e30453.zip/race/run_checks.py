from pathlib import Path
import os, sys, subprocess, json
r=Path(__file__).resolve().parent
tag=sys.argv[1]
repo=r/('race_repo' if tag.startswith('race') else 'repo')
runtime=r/('runtime_'+tag)
runtime.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items() if k.upper() in {'PATH','SYSTEMROOT','WINDIR','COMSPEC','PATHEXT','SYSTEMDRIVE','NUMBER_OF_PROCESSORS'}}
env['PYTHONPATH']=os.pathsep.join(p for p in sys.path if p)
env.update(TEMP=str(runtime),TMP=str(runtime),PYTHONIOENCODING='utf-8',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',AI_BRAIN_ENABLED='false',AI_BRAIN_LLM='false',EXECUTION_ENABLED='false',ALLOW_PAPER_ORDERS='false',AUTO_EXECUTION_ENABLED='false',TWO_BRAIN_MODE='off',TOPSTEPX_ARM_ORDERS='false',TZ='UTC',HTTPS_PROXY='http://127.0.0.1:9',HTTP_PROXY='http://127.0.0.1:9',NO_PROXY='')
for key in ('AI_BRAIN_DIR','AI_RETRIEVAL_DIR','OCCURRENCE_LEDGER_DIR','REPLAY_SESSIONS_DIR','PERFORMANCE_TABLES_DIR','HTF_MEMORY_DIR','GLOBAL_MEMORY_DIR'):
    env[key]=str(runtime/key.lower())
worker='''import socket,sys,json
sys.path[:0]=['src','tests']
def deny(*a,**k):raise RuntimeError('OWNER_AUDIT_NETWORK_DENIED')
socket.socket.connect=deny;socket.socket.connect_ex=deny;socket.create_connection=deny;socket.getaddrinfo=deny
import pytest
class Record:
 def pytest_runtest_logreport(self,report):
  if report.when=='call' or report.failed or report.skipped:
   with open(sys.argv[1]+'.progress.jsonl','a',encoding='utf-8') as f:f.write(json.dumps(dict(nodeid=report.nodeid,outcome=report.outcome,when=report.when,seconds=report.duration,detail=str(report.longrepr) if report.failed else None))+'\\n')
raise SystemExit(pytest.main(['-q','-p','no:cacheprovider','--basetemp='+sys.argv[2],'--junitxml='+sys.argv[1]+'.junit.xml',*sys.argv[3:]],plugins=[Record()]))
'''
with (r/(tag+'.log')).open('x',encoding='utf-8') as f:
    p=subprocess.run([sys.executable,'-u','-c',worker,str(r/tag),str(runtime/'tmp'),*sys.argv[2:]],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
(r/(tag+'.exit.json')).write_text(json.dumps(dict(exit_code=p.returncode,source='6e30453b70022ee66240716b72683b798ad4f523',repo=str(repo))))
print(tag,p.returncode)
raise SystemExit(p.returncode)




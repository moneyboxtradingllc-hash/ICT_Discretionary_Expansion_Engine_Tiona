# f6e4013 completion package

**Verdict: NOT CERTIFIABLE AS FROZEN.** The complete offline suite on the final review SHA finished with **11 failures**.
All 11 pass at the parent ffe00ae. The causes:

- **7** are the unrepinned certified Brain fingerprint: a mechanical consequence of the closure change.
- **4** are a **real authority change**. f6e4013 lets a supporting life registered *before* the incumbent's proved
  death complete the opposing local transfer proof. That contradicts the existing pinned C2 contract. This is a
  **SEMANTIC DECISION REQUIRED** item; it is not a mechanical defect. A prototype of the opposite rule restores C2 and
  breaks the captured 2026-10-23 repair, so no rule satisfies both. Neither side was chosen.

The restart concern is **NOT A PRODUCTION DEFECT**, with the exact defense proven by activated controls.

The CISD contract is delivered as a proposal. Its authority is DISABLED; the owner choice and recognition
certification are UNPROVEN.

Prepared offline by Tiona's session under Maurice's 2026-10-24 delegation:

- no model, provider or venue call; no credentials; no merge, deploy, arm or order;
- production stays disarmed;
- f6e4013 is unchanged.

## 1. Identity

| Item | Value |
|---|---|
| Parent (ratified RC) | `ffe00aef3db7fb2339780ed0fa9016149923c96e`, tree `57cc69c0…` |
| Audited repair | `f6e4013646e9d139a9fe71586ea4e60391e06c61`, tree `2eacaaddf65cb8288129f62be4896ee24233e089` (3 commits f3fd5f2, 13c2b53, f6e4013, from Codex's bundle, verified) |
| Final review SHA | `0df06ea0ba43c16975b7ea5aa9a490160cec8670`, branch `review/f6e4013-completion-20261024` (pushed, not merged). One docs/tests-only commit on f6e4013: `docs/recognition_validation/cisd/{CISD_CONTRACT_PROPOSAL.md,cisd_shadow.py}`, `tests/test_cisd_shadow_contract.py`, ledger entry `F6_COMPLETION_REVIEW_20261024`. `git diff f6e4013 0df06ea -- src` is empty |
| Fingerprints | f6e4013 = 0df06ea: `brain:75ef47f7ffc27bab`, `retr:0c241bdb8234d1ba`; closure 48 (digest 9b8f310c…); 32 protected pins (digest 79988f0e…) unchanged. The parent was `brain:3d9878ad3ff57f1f` |
| Ledger | `tools/verify_engineering_ledger.py` at 0df06ea: LEDGER_VERIFIED, clean, protected_verified 32, fingerprints_checked, closure_changed_since_latest_parent false, network_requests 0 |
| Runtime | Linux, Python 3.12.3 venv with 47/47 pins, env -i allowlist, isolated runtime roots, EXECUTION_ENABLED=false, AI_BRAIN_LLM=false, proxy sinkholed to 127.0.0.1:9. This is supported-pin Linux, **not Mac certification** |

## 2. Complete offline suite on 0df06ea

| Item | Value |
|---|---|
| Collection | 9,737 unique `tests/` cases in 358 files (= Codex's 9,722 + 15 new CISD cases), no duplicates. Shard union equals collection, and the shards are file-disjoint |
| Run | 4 shards, 05:43:29–06:30:21 UTC, none interrupted |
| Outcome | **9,143 passed / 583 skipped / 11 failed / 0 errors** (plus 34 subtests passed) |
| Extra collected id | `docs/recognition_validation/release_candidate/mac_evidence/test_mac_env_parent_repro.py`: 1 passed (separate run) |
| Skips | 583, all missing archives, git-ignored or operator-local evidence, or live-credential tests. Grouped reasons are in `full_suite/skip_reasons.txt` (largest: 149 archived production snapshot absent, 70 canonical store not present, 68 EXTERNAL_EVIDENCE_REQUIRED). The skip count equals the ffe00ae baseline (583) |
| Parent check | The same 5 files at ffe00ae: 207 passed, 1 skipped, 0 failed |

Failures:

| # | Tests | Cause | Disposition |
|---|---|---|---|
| 7 | `test_brain_fingerprint_portability` ×4 (lf/crlf/mixed_files/mixed_lines); `test_combined_safety_readiness::test_the_brain_contract_fingerprint_is_the_certified_one`; `test_recognition_owner_audit` ×2 (CLI refuses `RUN_SOURCE_MISMATCH /brain_fingerprint declared brain:3d9878ad3ff57f1f; observed brain:75ef47f7ffc27bab`) | f6e4013 changed the Brain closure but did not repin the certified fingerprint | **CONFIRMED (mechanical omission in f6e4013). NOT repinned**: repinning certifies the changed Brain source, and that source carries the unresolved item below. A one-value repin, once the decision is made |
| 4 | `test_campaign_leg_scope_labels::…[C2-ecu/C2-non-ecu]`; `test_retained_leg_projection::test_c2_first_post_death_and_sticky_scans_retain_the_released_life[ecu/non-ecu]` | See §3 | **SEMANTIC DECISION REQUIRED (blocking)** |

## 3. The authority conflict (new finding; Codex's interrupted suite never reached it)

These are per-scan traces from the real ProductionScanCycle (`probes/c2_trace`), identical in ECU and non-ECU:

| C2 scan | ffe00ae | f6e4013 |
|---|---|---|
| 03:05 | bullish active, bearing 1m 29457; incumbent_intact | same |
| 03:06 (1m 29457 dies) | none; developing_transfer, leg failure occurred | same |
| 03:07 | bearish active, **no bearing**; developing_transfer; stand_down; candidate refused | bearish active, **bearing 5m high 29500 registered 03:04**; **confirmed_transfer** |
| 03:08–03:14 | developing_transfer | **incumbent_intact** (bearish) |

The pinned contract (`test_retained_leg_projection.py`) says: "an opposing bearish owner holds the path WITHOUT a
structure of its own: nothing live supersedes the incumbent's released life, and the opposing owner gains no authority
from it."

At f6e4013, `reconcile_current_structure` binds the still-current 5m high, which was born **before** the incumbent's
death. `_transfer_proof` then sees an intact expected-side bearing, so the local transfer is verified and entries are no
longer refused by the local table.

**The captured case uses the same pattern** (`probes/captured_timing`):

- incumbent bullish death 17:08Z (1m 29195);
- bearish origin 17:09Z (rejected_raid_reclaim);
- reconciled bearing 1m 29263, **registered 16:48Z, before the death**.

**Prototype of the opposite rule** (`probes/opt_post_death.diff`: skip lives registered at or before the proved
incumbent death; NOT committed):

- all C2 cases pass;
- `test_captured_current_protected_life_reaches_new_active_owner` and both `test_archived_bars_reach_current_narrative_consumer` fail (3 failed / 92 passed).

So the captured repair and the pinned C2 contract cannot both hold. Owner question **Q-BEARING**, stated exactly:

> May a protected supporting life that was registered **before** the incumbent leg's proved death, and is still the
> producer's exact current life, become the new opposing owner's load-bearing structure, and thereby complete the
> local transfer proof?

| Answer | Consequence |
|---|---|
| **Yes** | The f6e4013 behaviour stands. The C2/retained-leg pinned expectations must be re-ratified and updated. The 7 fingerprint pins are repinned to `brain:75ef47f7ffc27bab`. A fresh session authorization is needed. The ladder finding in §5 applies |
| **No** | The prototype guard (or an equivalent) becomes the repair. The captured 13:15–13:58 ET bearing difference disappears, so the captured "missing bearing" stays as the parent behaviour. The fingerprint changes again; repin then |
| Other (e.g. a born-after-death rule for transfer only, while still publishing the life as context) | Needs its own contract; not prototyped |

## 4. Restart (actual scan): NOT A PRODUCTION DEFECT

**Reachability.**

- `_recover_active_path` runs only when `_update_active_path` sees `self._active_path is None`.
- Every `scan()` first calls `_rebuild_derived_state` (which sets a fresh ActivePath, line 447) and/or `_prepare_chronology`.
- `_prepare_chronology` sets `_chronology_owned=True` (line 635). On a fresh process it also installs a fresh
  ActivePath before the prefix replay (line 674); otherwise it marks coverage incomplete, and `_update_active_path`
  returns unavailable at line 1540, before `first_use`.
- No other production caller exists (grep of src/tools).

**Runtime.** Codex's `test_actual_restart_handoff.py` at f6e4013: **healthy PASSED, controlled-violation PASSED**. The
seven path fields match continuous execution, and the legacy helper is not invoked.

**Activated control.** Mutant `restart_reset.diff` replaces line 674 with `None`:

- Codex's probe fails both variants (legacy recovery invoked).
- A fields-first variant shows **all 7 fields diverge** and the owner is resurrected (`none -> bullish`).

**Helper-only counterexample.** `test_restart_after_handoff.py` reproduces the failure (`bearish` vs `none`), but it
calls the helper directly, which production never does. Per the instruction, no helper refactor was made.

Earlier probe findings, rechecked under this reachability result:

| Finding | Disposition |
|---|---|
| Restart (ledger sort order) vs continuous selection when two lives are current | Arises only through the unreachable helper. **NOT A PRODUCTION DEFECT**. Which simultaneously current life bears remains a semantic note (continuous binds the last-ingested) |
| Forming owner, prior-session reset, v2 refusal, replaced-away life with stale registry, future newer receipt (fail-closed), confirmation anchor | All hold. **NOT A DEFECT** |

## 5. Codex's repair evidence, preserved

- 23/23 handoff cases pass at f6e4013.
- At the parent, 21 fail: 18 AttributeError plus 3 behavioural.
- Codex's four activated mutants (retired, identity, future, no_handoff) are all caught; healthy controls pass.

Semantic note: a reconciled pre-origin life becomes ladder rung 1 with `last_move_favourable=True`, so the next
favourable replacement publishes `successive_favourable=True`. A cold start without the receipt publishes False. This
is part of Q-BEARING: **SEMANTIC DECISION REQUIRED**.

## 6. CISD (docs/recognition_validation/cisd/CISD_CONTRACT_PROPOSAL.md)

**Fact contract.** A run of contiguous opposite-delivery buckets ends at or before a caller-selected settled extreme.
The CISD is the first later settled close strictly through the run's first open.

- Identity: `cisd_body_open_break:<contract>:<tf>:<dir>:<run start>:<anchor>:<break bucket>`.
- Available at the break bucket's close edge.
- Supersession, gaps and unreadable tape fail closed.

**Archived tape.**

- 5m run 11:45–11:55 ET with anchor 29231.75 (consistent with the blue line about 29232).
- Extreme 29306 at 12:00.
- The first close below the anchor is the 12:20 bucket (29215.25), **available 12:25 ET**, PENDING at 12:24.

**Mechanical boundary.** The bearish displacement swept and reclaimed 1m/3m lows between 12:17 and 12:21. Under the
current family these are bullish raids, so ActivePath's forming hypothesis becomes bullish. This is why no bearish
origin exists.

**Tests and controls.**

- 15 policy-independent cases pass. They include every-cutoff prefix/restart/order equivalence and a production check
  that `_authoritative_opposing_origin` rejects the family, with a non-vacuous `rejected_raid_reclaim` control.
- D3 policy (5m/15m, K=1, B, STRICT, INDEPENDENT_SUPPORTING_LIFE) is asserted unchanged.
- No `src` file references the shadow.
- 4/4 activated mutants caught: partial buckets, inclusive default, unsettled buckets, gap guard.

**Owner appendix O1–O9.**

- **O1 (evidence under existing gates vs independent transfer route) is UNANSWERED.**
- O5 (CISD before or after incumbent death) and O8 (contrary raids inside the displacement) would change transfer law.
- D3 STRICT is not reinterpreted.
- The 12:20 candle does not justify the noon entry.

## 7. Remaining limits

- Current-Brain recognition is UNPROVEN: no ratified-session evidence, and no model call at either source.
- Entry geometry and fills are UNPROVEN, as is the Mac runtime certification of this SHA.
- About 583 archive and credential-dependent cases are skipped and never counted green.
- The previous session authorization cannot be reused, since the fingerprint changed.
- Unrelated tooling note: `release_candidate/combine_session/session_evidence_bundle.py` uses wrong Brain record keys
  (the real keys are `llm_raw_response`, `llm_model`, `provider_latency_seconds`, `narrative_direction`). Not fixed here.

## 8. What needs Maurice

1. **Q-BEARING (§3).** Blocking; it decides whether f6e4013's behaviour or the pinned C2 contract is right.
2. **CISD O1** (and O2–O9 if O1=b).

Everything else in the delegation is complete. Once Q-BEARING is answered, the follow-up is mechanical:

- repin (and apply the guard, if the answer is No);
- one more full suite;
- ledger update.

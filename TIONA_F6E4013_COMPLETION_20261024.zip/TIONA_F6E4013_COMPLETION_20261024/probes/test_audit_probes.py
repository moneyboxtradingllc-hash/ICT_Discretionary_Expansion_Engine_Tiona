"""Independent adversarial probes of f6e4013 ActivePath.reconcile_current_structure (audit only, fictional rows)."""
import copy

import pytest

from market_state.active_path import (ActivePath, PROTECTED_SWING_REGISTERED, PROTECTED_SWING_REPLACED,
                                      PROTECTED_SWING_VIOLATED, STRUCTURE_BREAK, LIQUIDITY_SWEEP)

C = "CONTROL"
HAS_RECONCILE = hasattr(ActivePath, "reconcile_current_structure")


def reg(tf, level, born, *, swing=None, seen=None, kind=PROTECTED_SWING_REGISTERED, side="high", **extra):
    seen = seen or born
    swing = swing or f"{tf}:swing_{side}:{level}"
    return {"event_type": kind, "occurrence_id": f"{kind}:{C}:{tf}:{born}:{side}@{level}:{swing}@{born}",
            "contract": C, "source_tf": tf, "side": side, "level": float(level), "swing_id": swing,
            "registered_at": born, "basis": "buy_side_raid_rejected", "source_bar_time": born,
            "event_time": seen, "observed_at": seen, **extra}


def bearish_owner_events(t_raid="2026-10-23T17:01:00+00:00", t_bos="2026-10-23T17:02:00+00:00"):
    return [{"event_type": LIQUIDITY_SWEEP, "occurrence_id": f"RAID:{t_raid}", "contract": C, "source_tf": "1m",
             "event_time": t_raid, "source_bar_time": t_raid, "sweep_direction": "above_high", "reclaimed": True},
            {"event_type": STRUCTURE_BREAK, "occurrence_id": f"BOS:{t_bos}", "contract": C, "source_tf": "1m",
             "event_time": t_bos, "source_bar_time": t_bos, "direction": "bearish"}]


def registry(*events):
    out = {"highs": {}}
    for e in events:
        out["highs"][e["source_tf"]] = {"level": e["level"], "timeframe": e["source_tf"], "swing_id": e["swing_id"],
                                       "registered_at": e["registered_at"], "basis": e["basis"]}
    return out


def build(pre, post=(), *, order=None, cutoff="2026-10-23T17:05:00+00:00", version=None):
    ap = ActivePath(causal_identity_version=version) if version else ActivePath()
    ap.enforce_lifecycle(cutoff, C)
    rows = list(pre) + bearish_owner_events() + list(post)
    if order == "restart":   # _recover_active_path: sort by (event_time, occurrence_id)
        rows = sorted(rows, key=lambda r: (str(r.get("event_time") or ""), str(r.get("occurrence_id") or "")))
    ap.ingest(copy.deepcopy(rows))
    return ap


def summary(ap):
    lb = ap.load_bearing or {}
    st = ap.state()
    return {"tf": lb.get("timeframe"), "level": lb.get("level"), "ladder": list(ap.ladder),
            "successive": st["progression"]["successive_favourable"], "fav": lb.get("last_move_favourable")}


# ---- 3. continuous vs restart selection when two current lives exist ----------------------------------
def two_current_lives():
    born = "2026-10-23T16:48:00+00:00"
    return [reg("1m", 29263, born), reg("15m", 29270, born)]   # same scan, producer dict order 1m then 15m


@pytest.mark.skipif(not HAS_RECONCILE, reason="parent has no reconcile")
def test_restart_vs_continuous_choose_same_life_when_two_current_lives():
    lives = two_current_lives()
    cont = build(lives)
    rest = build(lives, order="restart")
    cutoff = "2026-10-23T17:05:00+00:00"
    cont.reconcile_current_structure(registry(*lives), cutoff)
    rest.reconcile_current_structure(registry(*lives), cutoff)
    assert summary(cont) == summary(rest), (summary(cont), summary(rest))


def test_parent_baseline_post_origin_registrations_restart_vs_continuous():
    """Same question for ordinary post-origin registrations (exists in the parent, no reconcile involved)."""
    born = "2026-10-23T17:03:00+00:00"
    lives = [reg("1m", 29263, born), reg("15m", 29270, born)]
    cont, rest = build([], lives), build([], lives, order="restart")
    assert summary(cont) == summary(rest), (summary(cont), summary(rest))


# ---- 4. ladder/progression baseline from a pre-origin life ---------------------------------------------
@pytest.mark.skipif(not HAS_RECONCILE, reason="parent has no reconcile")
def test_pre_origin_life_first_rung_makes_next_replacement_successive():
    born = "2026-10-23T16:48:00+00:00"
    life = reg("1m", 29263, born)
    ap = build([life])
    ap.reconcile_current_structure(registry(life), "2026-10-23T17:05:00+00:00")
    bound = summary(ap)
    lower = reg("1m", 29250, "2026-10-23T17:06:00+00:00", kind=PROTECTED_SWING_REPLACED,
                old_swing_id=life["swing_id"], old_registered_at=born)
    ap.ingest([lower])
    after = summary(ap)
    # Counterfactual: same market, receipt not retained (e.g. cold start) -> no rung 1.
    cold = build([])
    cold.ingest([copy.deepcopy(lower)])
    print("bound", bound, "after", after, "cold", summary(cold))
    assert bound["fav"] is True and bound["ladder"] == [29263.0]
    assert after["ladder"] == [29263.0, 29250.0] and after["successive"] is True
    assert summary(cold)["successive"] is False


# ---- 2/5. boundaries -------------------------------------------------------------------------------------
@pytest.mark.skipif(not HAS_RECONCILE, reason="parent has no reconcile")
def test_forming_owner_is_never_given_a_bearing():
    life = reg("1m", 29263, "2026-10-23T16:48:00+00:00")
    ap = ActivePath()
    ap.enforce_lifecycle("2026-10-23T17:05:00+00:00", C)
    ap.ingest([copy.deepcopy(life), bearish_owner_events()[0]])          # raid only -> forming, no owner
    assert ap.owner == "none" and ap.forming_direction == "bearish" and ap.load_bearing is None
    ap.reconcile_current_structure(registry(life), "2026-10-23T17:05:00+00:00")
    assert ap.load_bearing is None


@pytest.mark.skipif(not HAS_RECONCILE, reason="parent has no reconcile")
def test_prior_session_receipt_is_cleared_by_session_reset():
    life = reg("1m", 29263, "2026-10-22T16:48:00+00:00")
    ap = ActivePath()
    ap.enforce_lifecycle("2026-10-22T16:50:00+00:00", C)
    ap.ingest([copy.deepcopy(life)])
    ap.enforce_lifecycle("2026-10-23T17:00:00+00:00", C)                 # new production session -> reset
    ap.ingest(bearish_owner_events())
    ap.reconcile_current_structure(registry(life), "2026-10-23T17:05:00+00:00")
    assert ap.owner == "bearish" and ap.load_bearing is None


@pytest.mark.skipif(not HAS_RECONCILE, reason="parent has no reconcile")
def test_v2_identity_refuses_category_b_so_nothing_is_bound():
    from market_state.active_path import CAUSAL_IDENTITY_V2
    life = reg("1m", 29263, "2026-10-23T16:48:00+00:00")
    ap = build([life], version=CAUSAL_IDENTITY_V2)
    ap.reconcile_current_structure(registry(life), "2026-10-23T17:05:00+00:00")
    assert ap.load_bearing is None


@pytest.mark.skipif(not HAS_RECONCILE, reason="parent has no reconcile")
def test_replaced_away_life_is_not_revived_even_if_registry_regresses():
    born = "2026-10-23T16:48:00+00:00"
    life = reg("1m", 29263, born)
    nxt = reg("1m", 29270, "2026-10-23T16:55:00+00:00", kind=PROTECTED_SWING_REPLACED,
              old_swing_id=life["swing_id"], old_registered_at=born)
    ap = build([life, nxt])
    ap.reconcile_current_structure(registry(life), "2026-10-23T17:05:00+00:00")   # stale registry names old life
    assert ap.load_bearing is None


@pytest.mark.skipif(not HAS_RECONCILE, reason="parent has no reconcile")
def test_newer_future_receipt_blocks_older_valid_receipt_on_other_timeframe():
    """Documents the early `return`: a future-stamped newer match ends the search (fail-closed)."""
    born = "2026-10-23T16:48:00+00:00"
    ok = reg("15m", 29270, born)
    fut = reg("1m", 29263, born, seen="2026-10-23T17:09:00+00:00")
    ap = build([ok, fut])
    ap.reconcile_current_structure(registry(ok, fut), "2026-10-23T17:05:00+00:00")
    assert ap.load_bearing is None


@pytest.mark.skipif(not HAS_RECONCILE, reason="parent has no reconcile")
def test_reconciled_bearing_does_not_move_confirmation_anchor():
    life = reg("1m", 29263, "2026-10-23T16:48:00+00:00")
    ap = build([life])
    before = ap.last_confirmation_time()
    ap.reconcile_current_structure(registry(life), "2026-10-23T17:05:00+00:00")
    assert ap.last_confirmation_time() == before and ap.resolve_status() == "active"

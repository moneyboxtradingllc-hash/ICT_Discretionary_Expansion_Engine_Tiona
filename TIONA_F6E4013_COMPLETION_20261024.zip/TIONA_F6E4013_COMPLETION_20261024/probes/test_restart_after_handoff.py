"""Controlled post-capture mutation: not claimed as an observed session event."""
import copy,json
from pathlib import Path
import os
from live_scan.production_scan_cycle import ProductionScanCycle

FIXTURE=Path(os.environ['OWNER_AUDIT_REPO_ROOT'])/'tests/fixtures/session_20261023_bearing_handoff.json'
def test_restart_retains_release_of_reconciled_bearing(tmp_path,monkeypatch):
 for key in ['OCCURRENCE_LEDGER_DIR','AI_BRAIN_DIR','AI_RETRIEVAL_DIR','REPLAY_SESSIONS_DIR']:
  monkeypatch.setenv(key,str(tmp_path/key))
 fixture=json.loads(FIXTURE.read_text())
 frames=copy.deepcopy([x['snapshot'] for x in fixture['frames']])
 def cycle():return ProductionScanCycle(symbol='MNQ',contract_id='CON.F.US.MNQ.Z26',session_id='HANDOFF-RESTART')
 live=cycle()
 for event in fixture['retained_occurrences']:live.occurrence_ledger.record(event)
 for snapshot in frames:before=live._update_active_path(snapshot)
 assert before['owner']=='bearish' and before['load_bearing_structure']['level']==29263.0
 after=copy.deepcopy(frames[-1]);after['timestamp']='2026-10-23T17:16:00+00:00'
 after['liquidity']={};after['structure']={}
 after['settled_source']={'1m':{'source_bar_time':after['timestamp']}}
 after['protected_swings']['by_timeframe']['highs']={}
 released=live._update_active_path(after)
 assert released['owner']=='none' and released['last_invalidated']['level']==29263.0
 restarted=cycle();recovered=restarted._update_active_path(after)
 assert recovered['state_available'] is True
 assert recovered['owner']==released['owner'],('Restart resurrected a released repaired leg',released,recovered)
 assert recovered['last_invalidated']==released['last_invalidated']

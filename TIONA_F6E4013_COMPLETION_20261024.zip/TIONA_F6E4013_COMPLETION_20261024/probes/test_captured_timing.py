import test_active_path_bearing_handoff as T, json
from pathlib import Path
def test_timing(tmp_path, monkeypatch):
    c = T._cycle(tmp_path, monkeypatch)
    fx = json.loads((Path(T.__file__).parent/'fixtures/session_20261023_bearing_handoff.json').read_text())
    for e in fx['retained_occurrences']: c.occurrence_ledger.record(e)
    for s in T._frames(): p = c._update_active_path(s)
    li, o, lb = p['last_invalidated'] or {}, p['origin'] or {}, p['load_bearing_structure'] or {}
    print("\nDEATH", li.get('owner'), li.get('at'), li.get('settled_edge_time'), li.get('source_tf'), li.get('level'))
    print("ORIGIN", o.get('at'), o.get('source_tf'), o.get('proof_family'))
    print("BEARING", lb.get('timeframe'), lb.get('level'), lb.get('registered_at'), lb.get('at'))
    print("TRANSFER", p['transfer_evidence'])

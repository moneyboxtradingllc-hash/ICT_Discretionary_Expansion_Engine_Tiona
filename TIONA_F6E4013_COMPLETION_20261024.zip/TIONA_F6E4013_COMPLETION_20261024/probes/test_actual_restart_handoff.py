"""Actual scan startup defense, not direct helper recovery. Offline Mode B facts."""
import copy,json
from pathlib import Path
import os
from datetime import datetime,timedelta
import pytest
from live_scan.production_scan_cycle import ProductionScanCycle

@pytest.mark.parametrize('violate',[False,True],ids=['healthy','controlled-violation'])
def test_actual_scan_restart_matches_continuous_path(tmp_path,monkeypatch,violate):
 for key in ['OCCURRENCE_LEDGER_DIR','AI_BRAIN_DIR','AI_RETRIEVAL_DIR','REPLAY_SESSIONS_DIR']:
  monkeypatch.setenv(key,str(tmp_path/key))
 fixture=json.loads((Path(os.environ['OWNER_AUDIT_REPO_ROOT'])/'tests/fixtures/session_20261023_bearing_handoff.json').read_text())
 bars=copy.deepcopy(fixture['tape'])
 for b in bars:b['contract']='CON.F.US.MNQ.Z26'
 bars=[b for b in bars if b['timestamp']<='2026-10-23T17:15:00+00:00']
 def cycle():return ProductionScanCycle(symbol='MNQ',contract_id='CON.F.US.MNQ.Z26',session_id='ACTUAL-RESTART')
 def scan(c,bs):return c.scan(bs[-300:],now=datetime.fromisoformat(bs[-1]['timestamp'])+timedelta(minutes=1),invoke_brain=False)['snapshot']['active_path_state']
 live=cycle()
 for moment in ['17:07','17:08','17:09','17:15']:
  before=scan(live,[b for b in bars if b['timestamp']<='2026-10-23T'+moment+':00+00:00'])
 assert before['owner']=='bearish' and before['load_bearing_structure']['level']==29263.0
 if violate:
  # Explicit counterfactual after the actual target; not historical market data.
  last=copy.deepcopy(bars[-1]);last.update(timestamp='2026-10-23T17:16:00+00:00',open=bars[-1]['close'],high=29275.0,low=min(bars[-1]['close'],29260.0),close=29270.0)
  bars.append(last)
  continuous=scan(live,bars)
  assert continuous['last_invalidated']['level']==29263.0
 else:continuous=before
 fresh=cycle();calls=[]
 original=fresh._recover_active_path
 def recover(snapshot):calls.append('legacy_recovery');return original(snapshot)
 monkeypatch.setattr(fresh,'_recover_active_path',recover)
 recovered=scan(fresh,bars)
 assert fresh.derived_state_is_current() is True
 assert fresh._chronology_coverage['complete'] is True
 assert calls==[], 'Mandatory canonical startup should bypass legacy helper'
 for key in ['owner','status','origin','load_bearing_structure','last_invalidated','progression','transfer_evidence']:
  assert recovered[key]==continuous[key],(key,continuous,recovered)

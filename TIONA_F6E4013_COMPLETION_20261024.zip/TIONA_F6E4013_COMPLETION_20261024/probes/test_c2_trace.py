"""Audit trace: ActivePath state per scan through the C2 scenario (ecu and non-ecu)."""
import json
import pytest
import test_campaign_draw_temporal_authority as TA
import test_reversal_foundation_proof_closure as RF
import test_stance_history_hygiene as H
import test_campaign_leg_scope_labels as L


def brief(p):
    lb = p.get("load_bearing_structure") or {}
    li = p.get("last_invalidated") or {}
    return (p.get("owner"), p.get("status"), lb.get("timeframe"), lb.get("level"), lb.get("registered_at"),
            (li.get("source_tf"), li.get("level"), li.get("at")))


@pytest.mark.parametrize("ecu", [True, False], ids=["ecu", "non-ecu"])
def test_trace(tmp_path, monkeypatch, ecu):
    cycle, calls = H._lane(tmp_path, monkeypatch, ecu)
    s1, _ = H._brain_scan(cycle, calls, RF.TAPE_1M)
    s2, _ = H._brain_scan(cycle, calls, TA.LATER)
    print("\nPRE", brief(s1["snapshot"]["active_path_state"]), brief(s2["snapshot"]["active_path_state"]))
    rows = list(TA.LATER)
    for b in L.SCENARIOS["C2"]:
        rows = rows + [b]
        scan, payload = H._brain_scan(cycle, calls, rows)
        nc = scan["brain_block"]["narrative_continuity"]
        print("TRACE", "ecu" if ecu else "non", b["timestamp"][11:16], brief(scan["snapshot"]["active_path_state"]),
              nc["control_state"], nc.get("active_leg_failure_status"))

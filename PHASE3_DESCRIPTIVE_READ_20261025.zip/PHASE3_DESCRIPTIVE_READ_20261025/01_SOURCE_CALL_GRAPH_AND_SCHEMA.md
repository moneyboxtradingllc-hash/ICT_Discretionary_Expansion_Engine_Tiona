# 01: Source, call graph, schema and authority map

## Identity

| | |
|---|---|
| Parent | `736c610d86e6618e979efd388521deeb9bf669e6` (tree `55d162a8b78ae91028fb76c5d574fb8352d24658`), brain:62fe5ecf46d75dc4, retr:0c241bdb8234d1ba, closure 49, 32 protected pins |
| Final (frozen) | `7b5218ac2fe9bdc1f348c1c433fa4060ae8ba3a2` (tree `d1ef036f1b2dbb5d91f53243673580f85767ad5e`), one commit on the parent |
| Branch | `review/descriptive-read-integration-20261025` |
| Measured child | brain:**d17223b71ac698ff**, retr:0c241bdb8234d1ba (unchanged), closure 49 (no source added or removed), 32/32 protected pins byte-identical, `verify_engineering_ledger.py` → LEDGER_VERIFIED |
| Ledger entry | `DESCRIPTIVE_READ_INTEGRATION_20261025`; receipt `b29c1cbbc242241d23adfb77f163ed75aedc2e5af9f973954e6e119e2af69512` (predecessor `678b94c8…`) |

The full diff is in `FULL_DIFF_736c610..7b5218a.patch`: 16 files changed, 930 insertions(+), 44 deletions(−).

| File | Kind | Change |
|---|---|---|
| `src/ai_brain/market_narrative.py` | bound | validator, pre-hold capture, checked transport, scope note |
| `src/ai_brain/narrative_brain.py` | bound | pop the raw object after capture (4 lines) |
| `src/ai_brain/brain_prompt.py` | bound | 4 narrow edits (below) |
| `src/broker/topstepx_production_loop.py` | bound | decision-trace ownership (telemetry) |
| `tools/narrative_read_report.py` | tool | four columns |
| `src/recognition_validation/examples/*.json` ×3, 4 tests | repin | measured fingerprint literal only |
| `tests/test_descriptive_market_read.py` | new | 46 cases |
| `tests/test_decision_trace_ownership.py` | new | 6 cases |
| `tests/test_protected_structure_continuity.py` | test | Phase 2 future-context diagnostic corrected (see 02 §5) |
| `docs/recognition_validation/ENGINEERING_LEDGER.md` | ledger | append-only entry |

**No protected source changed.** That includes `luna_candidate_producer.py`, `narrative_continuity.py`,
`campaign_scope.py`, `active_path.py` and `stance_memory.py`. No D3, transfer family, economics, risk or execution
code changed, and no expected C2 result was rewritten.

## Call graph (line numbers at 7b5218a)

```
provider JSON
  └ brain_validation.normalize_output (brain_validation.py:132)   copies the parsed dict; unknown keys survive
  └ narrative_brain.run_narrative_brain: output.update(parsed) (narrative_brain.py:1177)
  └ market_narrative.capture(output, ...) (narrative_brain.py:1214 → market_narrative.py:160)
        read["descriptive_market_read"] = descriptive_view(authored.get("descriptive_market_read"))   PRE-HOLD
  └ output.pop("descriptive_market_read") (narrative_brain.py:1223)   root/guarded output identical to parent
  └ output_direction_hold(output, continuity) (narrative_brain.py:1230 → narrative_continuity.py:761)
  └ stance_memory.record(..., authored_market_read=authored_market_read) (narrative_brain.py:1277/1282 →
        stance_memory.py:205; row["authored_market_read"] = MN.for_record(...) at :281)   SAME ROW, SAME ENVELOPE
  └ brain call record: "authored_market_read" (narrative_brain.py:1335/1413) → tools/narrative_read_report.py
next scan
  └ stance_memory.history_summary → eligible rows only (existing hygiene: custody, lineage, revision,
        scope, future_dated, superseded, malformed) → market_narrative.history (market_narrative.py:299)
        → _item (market_narrative.py:249): provenance/custody checks first, then
          item["descriptive_market_read"] = _transported_descriptive(...)   re-validated or UNKNOWN
  └ brain_input "market_narrative_history" (brain_input.py:923–927, :1209) → provider payload
```

**Authority readers.** No participation module reads the field. `git grep descriptive_market_read -- src` matches only
`market_narrative.py`, `brain_prompt.py` and `narrative_brain.py` (the pop). This is asserted by
`test_no_participation_module_reads_the_descriptive_view` and activated by mutant 4a. These modules carry none of it:
the guarded `stance_history`, `narrative_continuity`, Draw/Lifecycle, CampaignScope, `CandidateProducer` and the
plan/final-quote code.

**Decision trace.**
- `ProductionLoop` sets `self._decision_trace_owner = (scan_count, snapshot_id)` immediately before each of its two
  visible `self.producer.produce(..., require_campaign_lifecycle=True)` calls (`topstepx_production_loop.py:1207`,
  `:1533`). `produce()` replaces `last_decision_trace` on entry (`luna_candidate_producer.py:1280–1281`).
- `_record_decision` (`:157`) copies `self.producer.last_decision_trace` only when the owner equals the scan being
  recorded, and writes `decision_trace_source = loop_producer_current_scan`. Otherwise it records an empty trace and
  `UNKNOWN:no_producer_call_this_scan`.
- `getattr(self.cycle, "producer")` is gone; the scan cycle owns no producer. The whole recorder stays inside the
  existing `except Exception: pass`, so a failing journal changes no outcome.

## Schema: `descriptive_market_read/v1` (model-authored keys only)

`{"direction": bullish|bearish|conflicted|neutral, "market_story", "dominant_reasoning", "delivery_interpretation",
"liquidity_interpretation", "protected_high_interpretation", "protected_low_interpretation", "thesis_health":
string, "uncertainties": [≤8 strings]}`

- `market_story` and `dominant_reasoning` must be nonblank.
- Prose is bounded at 1200 characters and each uncertainty at 300. Each cut is declared in `truncations` with its
  original length and digest.
- The server adds `schema`, `status`, `authority = OBSERVATIONAL_ONLY` and `basis =
  validated_model_descriptive_field`. It never accepts them from the model.

UNKNOWN reasons are typed and nested; the root packet is never rewritten:

| Stage | Reasons |
|---|---|
| Capture | `descriptive_read_absent`, `descriptive_read_not_object`, `descriptive_read_unexpected_field:<k>` (any action/permission/objective/entry/metadata key), `descriptive_read_invalid:<field|direction|uncertainties>`, `descriptive_read_blank:<field>` |
| Envelope UNKNOWN | the envelope's own reason (degraded, fallback or circuit-open cognition gets a nested UNKNOWN as well) |
| Transport | `legacy_read_without_descriptive_field`, `descriptive_authority_label_invalid`, `descriptive_basis_invalid`, and every envelope-level provenance/custody reason |

Transported items add `root_fields_basis = pre_hold_campaign_response`, so the root fields are never presented as the
descriptive read. History is never backfilled.

## Prompt (four narrow edits; `brain_prompt.py`)

1. The `market_narrative_history` rule now separates each item's root fields (the pre-hold CAMPAIGN response) from
   its `descriptive_market_read` (the prior INDEPENDENT read, used to explain continuity or change against present
   facts). UNKNOWN means none was recorded.
2. After "Then, and only then, `narrative_direction` may change to that new owner", it adds: "(This governs the root
   campaign field only. It does not limit how you DESCRIBE delivery in `descriptive_market_read`.)"
3. One schema line after `"campaign_scope_proposal": null,`.
4. A short "DESCRIPTIVE READ (optional, OBSERVATIONAL_ONLY)" paragraph before "DIRECTION AND ACTION ARE SEPARATE
   QUESTIONS".

No other rule, tool, objective, plan or action text changed. A prompt-string assertion is a contract check only.

## Report (`tools/narrative_read_report.py`)

Four columns, each from its own source:

| Column | Source | When missing |
|---|---|---|
| `DESCRIPTIVE_READ` | `authored_market_read.descriptive_market_read` | UNKNOWN (always, for legacy records) |
| `AUTHORED PRE_HOLD_CAMPAIGN_RESPONSE` | `authored_market_read`, else `LEGACY_RAW_RESPONSE` | as before |
| `PERMITTED_RESPONSE` | `parsed_output` | as before |
| `REFUSAL` | `narrative_authority_guard` | as before |

Rows also show `source` and the read's `settled_cutoff`. No column is reconstructed from another. The JSON keys
`authored`/`permitted`/`refusal` are kept for compatibility, and `descriptive` is new.

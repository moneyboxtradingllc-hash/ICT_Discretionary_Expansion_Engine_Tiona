"""Render SESSION_REVIEW.json + CLAIM_GRADES.csv as compact markdown tables."""
import collections, csv, json, sys
rev = json.load(open(sys.argv[1])); claims = list(csv.DictReader(open(sys.argv[2])))
def hm(x): return (x or "")[11:16]
out = ["| CP | cutoff | settled 1m bar (O/H/L/C) | session range since 13:00Z | ActivePath owner / forming / status | origin (family, event, at, tf) | last death (owner, at, level, tf) | lifecycle | first failed transfer gate | candidate |",
       "|---|---|---|---|---|---|---|---|---|---|"]
for c in rev["checkpoints"]:
    if c["status"] != "SELECTED":
        out.append(f"| {c['checkpoint_utc']} | MISSING |"); continue
    f = c["facts"]; b = f["settled_bar"]; r = f["session_range_since_1300Z"]; ap = f["active_path"]; o = f["origin"]; d = f["last_invalidated"]
    lc = f["campaign_lifecycle"] or {}
    cand = c["records"][-1]["e_first_actual_blocker"]
    cand = cand.get("candidate") if isinstance(cand, dict) else cand
    out.append(f"| {c['checkpoint_utc']} | {hm(f['settled_cutoff'])} | {b['open']}/{b['high']}/{b['low']}/{b['close']} | {r['low']}–{r['high']} | {ap['owner']} / {ap['forming_direction']} / {ap['status']} | {o['proof_family']}, {o['event']}, {hm(o['at'])}, {o['source_tf']} | {d['owner']}, {hm(d['at'])}, {d['level']}, {d['source_tf']} | {lc.get('state')} ({lc.get('reason')}) | {f['first_failed_transfer_gate']} | {cand} |")
out += ["", "| CP | ordinal | record | (a) raw phase | (b) raw direction / action | (c) recorded guarded direction / action | (c) child playback | (d) tool/objective/plan | (e) first actual blocker | transfer-gate diagnostic (from prior recorded direction) |", "|---|---|---|---|---|---|---|---|---|---|"]
for c in rev["checkpoints"]:
    for e in c.get("records", []):
        a = e["a_raw_authored_observation"]; bi = e["b_root_campaign_action_intent"]; cg = e["c_mechanical_permission"]
        g = cg["recorded_guarded"]; pb = cg["child_playback"]
        pbs = (f"{pb['guarded'].get('narrative_direction')} / {pb['guarded'].get('current_action')}; {pb['candidate']}" if isinstance(pb, dict) else pb)
        ee = e["e_first_actual_blocker"]
        ees = (f"{ee['candidate']} ({ee['campaign_lifecycle'].get('state')}: {ee['campaign_lifecycle'].get('reason')})" if isinstance(ee, dict) else ee)
        gate = ee['first_failed_transfer_gate'] if isinstance(ee, dict) else "NOT_REPLAYED"
        out.append(f"| {c['checkpoint_utc']} | {e['ordinal']} | {e['source_record_name']} | {a.get('narrative_phase') if isinstance(a, dict) else a} | {bi.get('narrative_direction')} / {bi.get('current_action')} | {g['narrative_direction']} / {g['current_action']} | {pbs} | MISSING (not recorded) | {ees} | {gate} |")
cnt = collections.Counter((x["checkpoint_utc"], x["grade"]) for x in claims)
grades = ["EVIDENCE_SUPPORTED", "AMBIGUOUS", "CONTRADICTED", "MISSING"]
out += ["", "| CP | " + " | ".join(grades) + " |", "|---|" + "---|" * len(grades)]
for cp in sorted({x["checkpoint_utc"] for x in claims}):
    out.append(f"| {cp} | " + " | ".join(str(cnt[(cp, g)]) for g in grades) + " |")
print("\n".join(out))

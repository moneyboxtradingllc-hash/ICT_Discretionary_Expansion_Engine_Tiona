"""All-record inventory (02 fixed audit step 1): one row per recorded ordinal,
duplicate cutoffs kept, sorted by ordinal. Separates (a) raw authored labels,
(b) raw root campaign/action intent and (c) the guarded (permitted) response
as recorded. Raw fields are RAW_RESPONSE_AS_RECORDED_NOT_REVALIDATED."""
import collections, csv, json, sys
from pathlib import Path
src, out = Path(sys.argv[1]), Path(sys.argv[2])
d = json.loads(src.read_text())
rows = []
for r in sorted(d["records"], key=lambda r: r["ordinal"]):
    raw = r.get("raw_response_fields") or {}
    g = r.get("guarded_response_fields") or {}
    rows.append({"ordinal": r["ordinal"], "settled_cutoff": r["settled_cutoff"],
                 "source_record_name": r["source_record_name"],
                 "cognition_source": r["cognition_source"], "status": r["status"],
                 "unknown_reason": r["unknown_reason"], "historical_model": r.get("historical_model"),
                 "raw_direction": raw.get("narrative_direction"), "raw_phase": raw.get("narrative_phase"),
                 "raw_action": raw.get("current_action"),
                 "guarded_direction": g.get("narrative_direction"), "guarded_action": g.get("current_action"),
                 "guarded_story_differs": (raw.get("market_story") is not None
                                           and g.get("market_story") is not None
                                           and raw.get("market_story") != g.get("market_story")),
                 "withheld": ";".join(f"{w['view']}.{w['field']}" for w in r.get("withheld_fields") or []),
                 "descriptive_market_read": "UNKNOWN:field_did_not_exist_historically"})
with open(out, "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0]))
    w.writeheader(); w.writerows(rows)
c = collections.Counter
summary = {"records": len(rows), "cutoffs": len({x["settled_cutoff"] for x in rows}),
           "duplicate_cutoff_records": len(rows) - len({x["settled_cutoff"] for x in rows}),
           "status": dict(c(x["status"] for x in rows)),
           "cognition_source": dict(c(x["cognition_source"] for x in rows)),
           "raw_direction": dict(c(x["raw_direction"] for x in rows)),
           "raw_action": dict(c(x["raw_action"] for x in rows)),
           "guarded_direction": dict(c(x["guarded_direction"] for x in rows)),
           "guarded_action": dict(c(x["guarded_action"] for x in rows)),
           "raw_vs_guarded_direction": dict(c(f"{x['raw_direction']}->{x['guarded_direction']}" for x in rows)),
           "guarded_story_differs": sum(bool(x["guarded_story_differs"]) for x in rows),
           "records_with_withheld_cells": sum(bool(x["withheld"]) for x in rows),
           "models": dict(c(x["historical_model"] for x in rows))}
print(json.dumps(summary, indent=1))

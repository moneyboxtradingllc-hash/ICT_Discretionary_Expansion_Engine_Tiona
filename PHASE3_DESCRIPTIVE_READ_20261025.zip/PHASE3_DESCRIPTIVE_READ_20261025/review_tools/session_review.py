"""PHASE 3 whole-session review (02 fixed audit steps 3-5), DIAGNOSTIC ONLY.

    python3 -I session_review.py <derivative.json> <manifest.json> <trace.json> <tape.json> <out_dir>

Inputs (all held, offline, no model/provider calls):
  derivative  FRIDAY_NARRATIVE_FIELDS_397.json (raw fields AS RECORDED, not revalidated)
  manifest    CHECKPOINT_MANIFEST.json (sealed BEFORE this script was written/run)
  trace       FRIDAY_TRACE_non-ecu.json: child-commit settled-prefix playback of the
              281 last-per-cutoff recorded responses (producer facts per cutoff)
  tape        tests/fixtures/session_20261023_settled_tape.json (limited archival
              provenance; bar stamped <= cutoff is settled, the playback convention)

Per checkpoint record it separates (a) raw authored observation, (b) raw root
campaign/action intent, (c) mechanical permission, (d) selected tool/objective/
plan if recorded, (e) first actual blocker; then grades claims:

  direction claim   raw narrative_direction vs the producer ActivePath owner
  level claims      every quoted price, matched by IDENTITY only:
     producer life / sweep / registry level available at the cutoff -> the
       level is a producer fact (EVIDENCE_SUPPORTED as identity, nothing more)
     only an OHLC print <= cutoff -> AMBIGUOUS (number presence only)
     first printed only AFTER the cutoff -> CONTRADICTED (unavailable at cutoff)
     never printed and no producer fact -> MISSING (quote/derived/unknown)
  intact claims     a level the text calls intact/holding that the producer
                    ledger shows VIOLATED at or before the cutoff, with no life
                    re-registered at that level and alive at the cutoff -> CONTRADICTED
  quote values      a number introduced as a quote/bid/ask -> MISSING (the
                    recorded quote is not in the derivative)

None of these is an owner-ratified recognition score or threshold. A matched
number establishes neither the claimed raid, its causal role, timing, campaign
read nor any opportunity.
"""
import collections
import csv
import json
import re
import sys
from pathlib import Path

PRICE = re.compile(r"(?<![\d.])(2[89]\d{3}(?:\.(?:0|00|25|5|50|75))?)(?![\d])")
INTACT = re.compile(r"intact|holds|holding|still protect|remains? (?:valid|alive|protected)", re.I)
QUOTE = re.compile(r"quote|bid|ask|last trade", re.I)
TEXT_FIELDS = ("market_story", "dominant_reasoning", "liquidity_interpretation",
               "delivery_interpretation", "protected_low_interpretation",
               "protected_high_interpretation", "thesis_health")


def _p(x):
    return round(float(x) * 4) / 4


def main(deriv, manifest, trace, tape, out):
    d = json.loads(Path(deriv).read_text())
    m = json.loads(Path(manifest).read_text())
    t = json.loads(Path(trace).read_text())
    bars = json.loads(Path(tape).read_text())["tape"]
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    recs = {r["ordinal"]: r for r in d["records"]}
    rows = {r["cutoff"]: r for r in t["trace"]}
    lives = t["ledger_high_lives"] + t["ledger_low_lives"]
    sweeps = t["ledger_sweeps"]

    first_print = {}
    for b in bars:
        for k in ("open", "high", "low", "close"):
            first_print.setdefault(_p(b[k]), b["timestamp"])

    review, claims = [], []
    for cp in m["checkpoints"]:
        cut = cp.get("selected_cutoff")
        if cp["status"] != "SELECTED":
            review.append({"checkpoint_utc": cp["checkpoint_utc"], "status": cp["status"]})
            continue
        row = rows.get(cut) or {}
        aps = row.get("active_path_state") or {}
        settled = [b for b in bars if b["timestamp"] <= cut]
        sess = [b for b in settled if b["timestamp"] >= "2026-10-23T13:00:00+00:00"]
        last = settled[-1]
        avail_lives = [e for e in lives if (e.get("registered_at") or e["event_time"]) <= cut]
        alive = {}
        for e in sorted(avail_lives, key=lambda e: e["event_time"]):
            if e["event_type"] == "PROTECTED_SWING_VIOLATED":
                alive.pop(e["swing_id"], None)
            elif e["event_type"] == "PROTECTED_SWING_REPLACED":
                alive.pop(e.get("old_swing_id"), None)
                alive[e["swing_id"]] = e
            else:
                alive[e["swing_id"]] = e
        violated = {_p(e["level"]): e for e in avail_lives
                    if e["event_type"] == "PROTECTED_SWING_VIOLATED" and e["event_time"] <= cut}
        avail_sweeps = [s for s in sweeps if (s.get("observed_at") or s["event_time"]) <= cut]
        producer_levels = ({_p(e["level"]) for e in avail_lives}
                           | {_p(s["swept_level"]) for s in avail_sweeps}
                           | {_p(v["level"]) for side in ("highs", "lows")
                              for v in ((row.get("registry") or {}).get(side) or {}).values()})
        facts = {
            "settled_cutoff": cut,
            "settled_bar": {k: last[k] for k in ("timestamp", "open", "high", "low", "close")},
            "session_range_since_1300Z": {"high": max(b["high"] for b in sess),
                                          "low": min(b["low"] for b in sess)} if sess else None,
            "active_path": {k: aps.get(k) for k in ("owner", "forming_direction", "status")},
            "origin": {k: (aps.get("origin") or {}).get(k) for k in
                       ("proof_family", "event", "direction", "at", "source_tf", "occurrence_id")},
            "load_bearing_structure": aps.get("load_bearing_structure"),
            "last_invalidated": {k: (aps.get("last_invalidated") or {}).get(k) for k in
                                 ("owner", "at", "level", "side", "source_tf", "occurrence_id")},
            "protected_lives_alive_at_cutoff": sorted(
                [{"side": e["side"], "tf": e["source_tf"], "level": e["level"],
                  "registered_at": e["registered_at"], "basis": e.get("basis"),
                  "occurrence_id": e["occurrence_id"]} for e in alive.values()],
                key=lambda x: (x["side"], x["tf"], x["level"])),
            "sweeps_last_30m": [{"tf": s["source_tf"], "dir": s["sweep_direction"],
                                 "level": s["swept_level"], "event_time": s["event_time"],
                                 "observed_at": s.get("observed_at") or "MISSING",
                                 "occurrence_id": s["occurrence_id"]}
                                for s in avail_sweeps if s["event_time"] >= _minus30(cut)],
            "campaign_lifecycle": row.get("campaign_lifecycle"),
            "first_failed_transfer_gate": row.get("first_failed_transfer_gate"),
            "transfer_gates_from": row.get("transfer_gates_from"),
            "narrative_continuity_control_state": (row.get("narrative_continuity") or {}).get("control_state"),
            "scope_catalog_rows": len(((row.get("scope") or {}).get("catalog_rows")) or []),
            "playback_recorded_file": row.get("recorded_file"),
            "historical_input_provenance": "MISSING (no input payloads in the derivative; "
                                           "facts above are child-commit producer playback)",
        }
        entries = []
        for ref in cp["records"]:
            r = recs[ref["ordinal"]]
            raw = r.get("raw_response_fields") or {}
            g = r.get("guarded_response_fields") or {}
            is_playback = r["source_record_name"] == row.get("recorded_file")
            entry = {
                "ordinal": r["ordinal"], "source_record_name": r["source_record_name"],
                "source_record_sha256": r["source_record_sha256"], "status": r["status"],
                "a_raw_authored_observation": {k: raw.get(k) for k in
                                               ("narrative_phase", "delivery_interpretation",
                                                "liquidity_interpretation", "market_story")}
                if raw else "UNKNOWN:" + str(r.get("unknown_reason")),
                "b_root_campaign_action_intent": {"narrative_direction": raw.get("narrative_direction"),
                                                  "current_action": raw.get("current_action")}
                if raw else "UNKNOWN",
                "c_mechanical_permission": {
                    "recorded_guarded": {"narrative_direction": g.get("narrative_direction"),
                                         "current_action": g.get("current_action")},
                    "child_playback": ({"guarded": row.get("guarded"),
                                        "candidate": row.get("candidate")}
                                       if is_playback else
                                       "NOT_REPLAYED (playback scope is last-per-cutoff)")},
                "d_selected_tool_objective_plan": "MISSING (not recorded in the derivative; "
                                                  "historical action stand_down)"
                if raw.get("current_action") in ("stand_down", None) else
                "MISSING (no objective/tool/plan fields in the derivative)",
                "e_first_actual_blocker": (
                    {"candidate": row.get("candidate"),
                     "campaign_lifecycle": row.get("campaign_lifecycle"),
                     "first_failed_transfer_gate": row.get("first_failed_transfer_gate")}
                    if is_playback else
                    ("recorded action " + str(raw.get("current_action"))
                     + "; downstream blocker NOT_REPLAYED")),
                "descriptive_market_read": "UNKNOWN:field_did_not_exist_historically",
            }
            entries.append(entry)
            if not raw:
                claims.append(_claim(cp, r, "record", None, "MISSING",
                                     "no primary raw response recorded", None))
                continue
            owner, forming = aps.get("owner"), aps.get("forming_direction")
            direction = raw.get("narrative_direction")
            if direction is None:
                gd, why = "MISSING", "no direction recorded"
            elif owner in ("bullish", "bearish") and direction == owner:
                gd, why = "EVIDENCE_SUPPORTED", f"producer ActivePath owner {owner}"
            elif owner in ("bullish", "bearish") and direction in ("bullish", "bearish"):
                gd, why = "CONTRADICTED", f"producer ActivePath owner {owner}"
            else:
                gd, why = "AMBIGUOUS", (f"owner {owner}, forming {forming}, "
                                        f"lifecycle {(row.get('campaign_lifecycle') or {}).get('state')}")
            claims.append(_claim(cp, r, "direction", direction, gd, why,
                                 aps.get("origin", {}) and (aps.get("origin") or {}).get("occurrence_id")))
            text = " ".join(str(raw.get(k) or "") for k in TEXT_FIELDS)
            seen = set()
            for mt in PRICE.finditer(text):
                lvl = _p(mt.group(1))
                if lvl in seen:
                    continue
                seen.add(lvl)
                ctx = text[max(0, mt.start() - 80): mt.end() + 80]
                fp = first_print.get(lvl)
                alive_levels = ({_p(e["level"]) for e in alive.values()}
                                | {_p(v["level"]) for side in ("highs", "lows")
                                   for v in ((row.get("registry") or {}).get(side) or {}).values()})
                if QUOTE.search(text[max(0, mt.start() - 40): mt.start()]):
                    gd, why, src = ("MISSING", "live quote value; recorded quote provenance is not "
                                    "in the derivative (playback quote is CONTROLLED)", None)
                elif (lvl in violated and lvl not in alive_levels
                      and INTACT.search(text[mt.end(): mt.end() + 60])):
                    gd, why, src = ("CONTRADICTED", "text calls it intact; producer VIOLATED at "
                                    + violated[lvl]["event_time"], violated[lvl]["occurrence_id"])
                elif lvl in producer_levels:
                    gd, why, src = ("EVIDENCE_SUPPORTED",
                                    "level identity is a producer life/sweep available at cutoff "
                                    "(identity only; not causal role/timing)", "ledger")
                elif fp and fp <= cut:
                    gd, why, src = "AMBIGUOUS", "number presence only (OHLC print " + fp + ")", "tape"
                elif fp:
                    gd, why, src = "CONTRADICTED", "first printed after cutoff at " + fp, "tape"
                else:
                    gd, why, src = ("MISSING", "no print and no producer fact (quote, derived, "
                                    "or unknown provenance)", None)
                claims.append(_claim(cp, r, "level", lvl, gd, why, src, ctx))
        review.append({"checkpoint_utc": cp["checkpoint_utc"], "status": "SELECTED",
                       "facts": facts, "records": entries})

    grade = collections.Counter((c["kind"], c["grade"]) for c in claims)
    summary = {"schema": "phase3_session_review/v1", "authority": "DIAGNOSTIC_ONLY",
               "checkpoints": len(review), "checkpoint_records": sum(len(x.get("records", []))
                                                                    for x in review),
               "claims": len(claims),
               "grades": {f"{k}:{g}": n for (k, g), n in sorted(grade.items())},
               "limit": "Identity/number matching is not recognition scoring; no owner "
                        "annotations; recorded raw responses are not revalidated outputs."}
    (out / "SESSION_REVIEW.json").write_text(json.dumps({"summary": summary, "checkpoints": review},
                                                       indent=1, default=str))
    with open(out / "CLAIM_GRADES.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(claims[0]))
        w.writeheader()
        w.writerows(claims)
    print(json.dumps(summary, indent=1))


def _minus30(cut):
    from datetime import datetime, timedelta
    return (datetime.fromisoformat(cut) - timedelta(minutes=30)).isoformat()


def _claim(cp, r, kind, value, grade, why, src, ctx=None):
    return {"checkpoint_utc": cp["checkpoint_utc"], "ordinal": r["ordinal"],
            "source_record_name": r["source_record_name"], "kind": kind, "value": value,
            "grade": grade, "rationale": why, "source_evidence": src,
            "context": (ctx or "").replace("\n", " ")}


if __name__ == "__main__":
    main(*sys.argv[1:6])

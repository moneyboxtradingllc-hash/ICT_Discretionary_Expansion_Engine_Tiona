"""Seal the Phase 3 checkpoint selection BEFORE any scoring (02 fixed audit step 2).

Rule (verbatim from the contract): use all available records at each listed UTC
cutoff, or the latest earlier cutoff within two minutes; if absent mark MISSING.
Writes the selected record identities and a manifest; reads only ordinals,
cutoffs, record names/digests and status -- no prose, no price data.
"""
import hashlib, json, sys
from datetime import datetime, timedelta
from pathlib import Path

src, out = Path(sys.argv[1]), Path(sys.argv[2])
data = json.loads(src.read_text())
CHECKPOINTS = ["13:18", "13:30", "14:00", "14:45", "15:06", "15:30", "16:05", "16:22",
               "16:29", "16:45", "17:15", "17:40", "17:58"]
by_cutoff = {}
for r in data["records"]:
    by_cutoff.setdefault(r["settled_cutoff"], []).append(r)
rows = []
for hm in CHECKPOINTS:
    target = datetime.fromisoformat(f"2026-10-23T{hm}:00+00:00")
    chosen = None
    for back in (0, 1, 2):
        cut = (target - timedelta(minutes=back)).isoformat()
        if cut in by_cutoff:
            chosen = cut
            break
    recs = sorted(by_cutoff.get(chosen, []), key=lambda r: r["ordinal"]) if chosen else []
    rows.append({"checkpoint_utc": hm, "selected_cutoff": chosen,
                 "status": "SELECTED" if chosen else "MISSING",
                 "records": [{"ordinal": r["ordinal"], "source_record_name": r["source_record_name"],
                              "source_record_sha256": r["source_record_sha256"],
                              "record_status": r["status"]} for r in recs]})
manifest = {"schema": "phase3_checkpoint_selection/v1",
            "derivative_sha256": hashlib.sha256(src.read_bytes()).hexdigest(),
            "rule": "all records at the cutoff, else the latest earlier cutoff within two minutes; else MISSING",
            "checkpoints": rows}
out.write_text(json.dumps(manifest, indent=1))
print(hashlib.sha256(out.read_bytes()).hexdigest())
for r in rows:
    print(r["checkpoint_utc"], r["status"], r["selected_cutoff"], [x["ordinal"] for x in r["records"]],
          [x["record_status"] for x in r["records"]])

"""PHASE 3 CISD rebase probe. UNAPPROVED REFERENCE ONLY; DIAGNOSTIC.

    python3 -I cisd_rebase.py <child repo> <cisd_shadow.py copy> <trace.json> <out.json>

The shadow helper (0df06ea, not an ancestor of 736c610) is loaded from a
scratch copy, never from the repository and never into a production input.
It is run on the CHILD's committed tests/fixtures/session_20261023_settled_tape.json.
The source mapping of CISD_CONTRACT_PROPOSAL.md section 3 is rebased by
locating each cited symbol in the child tree. The gate table then reads the
child-commit producer playback (FRIDAY_TRACE) at the cutoffs where the event
is knowable, and asks which EXISTING gates would still fail even if a CISD
event were present. Nothing here registers a family or changes a gate.
"""
import importlib.util
import json
import re
import subprocess
import sys
from pathlib import Path

CONTRACT = "CON.F.US.MNQ.Z26"
EXTREME = "2026-10-23T16:00:00+00:00"   # the proposal's selected extreme (O2 UNRATIFIED)
SYMBOLS = {
    "_producer_prefix": "src/live_scan/production_scan_cycle.py",
    "build_timeframes": None, "_apply": "src/market_state/active_path.py",
    "extract_occurrences": None, "_authoritative_opposing_origin": None,
    "_transfer_proof": None, "campaign_scope_proof": None,
    "build_narrative_continuity": None, "output_direction_hold": None,
    "candidate_direction_authorized": None, "_prepare_chronology": None,
    "_rebuild_derived_state": None, "po3_reversal_order_block": None,
}


def z(hhmm):
    return f"2026-10-23T{hhmm}:00+00:00"


def locate(repo, name):
    out = subprocess.run(["git", "-C", str(repo), "grep", "-n", "-E",
                          rf"^\s*def {re.escape(name)}\(", "--", "src"],
                         capture_output=True, text=True).stdout.strip().splitlines()
    return out or ["NOT_FOUND"]


def main(repo, helper, trace, out):
    repo = Path(repo)
    spec = importlib.util.spec_from_file_location("cisd_shadow_ref", helper)
    cisd = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cisd)
    tape = json.loads((repo / "tests/fixtures/session_20261023_settled_tape.json").read_text())
    bars = tape["tape"]

    def detect(through, **policy):
        return cisd.detect_cisd(bars, minutes=5, direction="bearish", extreme_at=EXTREME,
                                settled_through=z(through), contract=CONTRACT,
                                policy=policy or None)

    buckets = {b["open_time"]: b for b in cisd.settled_buckets(bars, 5, z("16:25"))}
    fact = {"settled_through_16:24 (cutoff 16:23)": detect("16:24"),
            "settled_through_16:25 (cutoff 16:24)": detect("16:25"),
            "settled_through_16:25_inclusive": detect("16:25", boundary="INCLUSIVE")}
    reference = {"run": {"first_open_time": z("15:45"), "last_open_time": z("15:55"),
                         "buckets": 3, "anchor_open": 29231.75, "extreme": 29306.0,
                         "extreme_open_time": EXTREME},
                 "event": {"break_open_time": z("16:20"), "break_close": 29215.25,
                           "available_at": z("16:25")}}
    same = (fact["settled_through_16:25 (cutoff 16:24)"].get("status") == "CONFIRMED"
            and fact["settled_through_16:25 (cutoff 16:24)"].get("run") == reference["run"]
            and fact["settled_through_16:25 (cutoff 16:24)"].get("event") == reference["event"])
    b1620 = buckets.get(z("16:20"))

    src_refs = {name: locate(repo, name) for name in SYMBOLS}
    nc = subprocess.run(["git", "-C", str(repo), "grep", "-n", "rejected_raid_reclaim", "--",
                         "src/ai_brain/narrative_continuity.py"],
                        capture_output=True, text=True).stdout.strip().splitlines()
    imports = subprocess.run(["git", "-C", str(repo), "grep", "-n", "-i", "cisd", "--", "src"],
                             capture_output=True, text=True).stdout.strip().splitlines()

    rows = {r["cutoff"]: r for r in json.loads(Path(trace).read_text())["trace"]}
    # Production scan cutoff is the last 1m bar's open; settled_through = cutoff + 1m,
    # so the 16:20 5m bucket (available 16:25) is first knowable at cutoff 16:24.
    gates = []
    for hhmm in ("16:24", "16:25", "16:29", "16:45"):
        r = rows[z(hhmm)]
        aps = r["active_path_state"]
        death = (aps.get("last_invalidated") or {})
        lives = (r.get("scope") or {}).get("catalog_rows") or []
        bearish_raids = [x for row in lives if row.get("supports") == "bearish"
                         for x in row.get("raids") or []]
        after_death = [x for x in bearish_raids if death.get("at") and x["event_time"] > death["at"]]
        gates.append({
            "cutoff": z(hhmm),
            "actual": {"owner": aps.get("owner"), "forming": aps.get("forming_direction"),
                       "status": aps.get("status"),
                       "origin_family": (aps.get("origin") or {}).get("proof_family"),
                       "origin_direction": (aps.get("origin") or {}).get("direction"),
                       "origin_occurrence_id": (aps.get("origin") or {}).get("occurrence_id"),
                       "last_death": {k: death.get(k) for k in
                                      ("owner", "at", "level", "side", "source_tf", "occurrence_id")},
                       "lifecycle": r.get("campaign_lifecycle"), "candidate": r.get("candidate"),
                       "first_failed_transfer_gate": r.get("first_failed_transfer_gate"),
                       "transfer_gates": r.get("transfer_gates")},
            "if_cisd_event_were_present_as_descriptive_evidence": {
                "changes_any_gate": False,
                "why": "O1=a adds Brain evidence only; no producer, gate or consumer reads it"},
            "if_cisd_event_were_an_origin_HYPOTHETICAL_UNIMPLEMENTED": {
                "G1_owner_is_bearish": aps.get("owner") == "bearish",
                "G2_status_active": aps.get("status") == "active",
                "G5_family_authoritative_today": False,
                "G6_structural_progression_present": bool(
                    (aps.get("progression") or {}).get("supporting_timeframes")),
                "G7_G9_bearish_load_bearing_present_and_intact": bool(
                    aps.get("load_bearing_structure")),
                "D3B_STRICT_supporting_reclaimed_raid_after_death": bool(after_death),
                "bearish_catalog_raids_all_before_death": [x["event_time"] for x in bearish_raids],
                "bearish_catalog_rows_real_fields": [
                    {"life": {k: (row.get("life") or {}).get(k) for k in
                              ("source_tf", "side", "level", "swing_id", "registered_at")},
                     "certificate": (row.get("certificate") or {}).get("status"),
                     "d3": row.get("d3")}
                    for row in lives if row.get("supports") == "bearish"],
                "note": "D3 is read from the catalog row's own d3 field. A CISD label would "
                        "not supply a strictly-later supporting raid or an independent life."},
        })

    result = {
        "schema": "phase3_cisd_rebase/v1", "authority": "UNAPPROVED_REFERENCE_DIAGNOSTIC_ONLY",
        "helper_source": "0df06ea0ba43c16975b7ea5aa9a490160cec8670:docs/recognition_validation/"
                         "cisd/cisd_shadow.py (scratch copy; not in child tree)",
        "reference_fixture_at_0df06ea": "tests/fixtures/session_20261023_bearing_handoff.json "
                                        "(absent at child)",
        "child_fixture": "tests/fixtures/session_20261023_settled_tape.json",
        "child_fixture_sha256": tape.get("tape_canonical_sha256"),
        "bucket_1620_child": b1620, "fact": fact,
        "reference_run_event_reproduced_on_child_tape": same,
        "src_reference_to_cisd_at_child": imports or "NONE",
        "authoritative_family_lines_at_child": nc,
        "source_mapping_rebased": src_refs,
        "gates": gates,
        "conclusion": [
            "The shadow fact reproduces on the child's committed tape (if the flag above is true); "
            "it is first knowable at cutoff 16:24 (bucket available 16:25).",
            "As descriptive evidence it changes no gate. As a hypothetical origin it would still "
            "fail owner/status/family/progression/load-bearing and D3-B STRICT (no bearish "
            "supporting raid after the 16:23 bullish death).",
            "The 16:20 bucket close available at 16:25 cannot justify the earlier noon entry.",
        ],
    }
    Path(out).write_text(json.dumps(result, indent=1, default=str))
    print(json.dumps({k: result[k] for k in ("reference_run_event_reproduced_on_child_tape",
                                             "src_reference_to_cisd_at_child")}, indent=1))
    for g in gates:
        print(g["cutoff"], json.dumps(g["if_cisd_event_were_an_origin_HYPOTHETICAL_UNIMPLEMENTED"]))


if __name__ == "__main__":
    main(*sys.argv[1:5])

# 05: Verification

## Runtime and isolation

| | |
|---|---|
| Interpreter | Linux, Python 3.12.3, pytest 9.1.1 (pinned venv). This does not certify Mac/live |
| Runner | `logs/runner_run.sh`: `env -i` allowlisted environment, no `.env`, credentials absent |
| Execution | `EXECUTION_ENABLED=false`, `ALLOW_PAPER_ORDERS=false`, `AI_BRAIN_LLM=false` |
| Network | HTTP(S) proxies pointed at a sinkhole `127.0.0.1:9` |
| Runtime roots | fresh per run (ledger, brain, retrieval, replay, memory dirs) |
| Worktrees | one detached git worktree per shard at the exact frozen SHA, each verified clean before the run |

## Identity and ledger (at 7b5218a)

| Check | Result |
|---|---|
| Fingerprints (`logs/fingerprints_7b5218a.txt`) | brain:d17223b71ac698ff, retr:0c241bdb8234d1ba, 48 contract sources (closure 49 with the repository entry) |
| Ledger (`logs/ledger_verify_7b5218a.json`) | LEDGER_VERIFIED, head 7b5218a, protected_verified 32, fingerprints_checked, network_requests 0 |
| Literal expectations | 7 repinned (3 examples, 4 tests) to the measured value. No other expected value changed, and no C2 expectation was rewritten |

## Full suite: final, at 7b5218ac2fe9bdc1f348c1c433fa4060ae8ba3a2

Run from 2026-10-25T18:32:03Z to 19:30:00Z in four file-disjoint shards (`full_suite/`).

| Shard | Result |
|---|---|
| 0 | 2341 passed, 106 skipped |
| 1 | 2283 passed, 163 skipped |
| 2 | 2278 passed, 168 skipped |
| 3 | 2301 passed, 146 skipped |

| Union check (`union.json`) | Value |
|---|---|
| Collected | 9786 tests in 360 files |
| Planned files equal collection; disjoint | true; true |
| JUnit testcases | 9786, all unique |
| **Failures / errors** | **0 / 0** |
| Skipped | 583 |

- The parent 736c610 collected 9734 tests in 358 files. The 52 new cases (46 + 6) are all passed in the final JUnit.
- Skip reasons are in `skip_reasons.txt`: 583 skips across 40 reasons, the same counts and reasons as the parent's
  Phase 2 run. All are absent archives, credentials or external evidence.
- The focused-file table is `focused_from_final_junit.md`.

## Superseded and preliminary runs (reported, not used as final)

- **Preliminary focused run, 137 files, uncommitted tree.** Stopped at about 38%. Its six failures were mapped by
  collection order:
  - five fingerprint pins, which failed because they ran before the repin;
  - `test_campaign_lifecycle::test_both_production_candidate_paths_remain_visible_to_structural_guard`, a real defect
    in my first trace fix. It was repaired (02 §4).
- **Affected-file checks after the repair.** `test_campaign_lifecycle`, fingerprint, safety-readiness and
  recognition files: 211 passed, 1 skipped. Trace-ownership and full-graph loop files: 14 passed.
- **Mutant stream at 84ad106.** Superseded by 9be032e and not used.
- **9be032e healthy twin.** Stopped as redundant: the final full suite runs every twin case at the exact SHA.

## Probes (scratch only; not in the repository)

| Probe | Purpose |
|---|---|
| `probes/test_p3_recorder_repro.py`, `test_p3_recorder_child.py` | Recorder before/after |
| `probes/test_p3_friday_session.py`, `p2trace.py` | Friday playback; `scope_view` corrected |
| `probes/test_p3_future_context_dump.py` | Catalog comparison |
| `review_tools/*.py` | Inventory, seal, review, CISD rebase, render |

Every probe and tool is offline.

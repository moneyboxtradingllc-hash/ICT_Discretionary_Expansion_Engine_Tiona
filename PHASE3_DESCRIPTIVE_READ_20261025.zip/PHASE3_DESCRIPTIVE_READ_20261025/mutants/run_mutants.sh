#!/bin/bash
# <names...>: one detached worktree at the frozen child per mutant; targeted tests; JUnit.
S=/tmp/claude-0/-home-user-ICT-Discretionary-Expansion-Engine-Tiona/4c1b4a67-6e49-58ef-be1e-a80c4037fc0a/scratchpad
SHA=9be032ea99ca556dcda6349f6b39b7f0a4bfbc17
D=tests/test_descriptive_market_read.py
T=tests/test_decision_trace_ownership.py
NF=tests/test_market_narrative_first.py
P2=tests/test_protected_structure_continuity.py
sel() { case $1 in
  capture_after_hold) echo "$D -k survives_hold or strong_descriptive or report_separates";;
  drop_nested|substitute_root) echo "$D -k survives_hold or follow_up or restart";;
  foreign_custody) echo "$D -k follow_up";;
  consume_descriptive) echo "$D -k survives_hold or existing or friday";;
  f6_c2_promotion) echo "$P2 $D -k c2 or friday";;
  cycle_producer|stale_trace) echo "$T";;
  future_row) echo "$D -k future_dated";;
  future_context) echo "$P2 -k future_session";;
  healthy) echo "$D $T $P2";;
esac; }
for n in "$@"; do
  W=$S/p3/mut/w9_$n
  git -C $S/g6/repo worktree add -q --detach $W $SHA
  if [ $n != healthy ]; then python3 -I $S/p3/mut/mutate3.py $W $n $S/p2/mut/f6_binder.diff > $S/p3/mut/diffstat_$n.txt; git -C $W diff > $S/p3/mut/mutant_$n.diff; fi
  read -r files k <<<"$(sel $n | sed 's/ -k /|/' | tr '|' '\n' | head -1)"; files=$(sel $n | sed 's/ -k .*//'); kexpr=$(sel $n | grep -o ' -k .*' | sed 's/^ -k //')
  if [ -n "$kexpr" ]; then
    $S/g5/run.sh $W $S/p3/mut/run_$n.log python -m pytest -q -rf -p no:cacheprovider --junitxml=$S/p3/mut/junit_$n.xml $files -k "$kexpr"
  else
    $S/g5/run.sh $W $S/p3/mut/run_$n.log python -m pytest -q -rf -p no:cacheprovider --junitxml=$S/p3/mut/junit_$n.xml $files
  fi
done

"""One row per mutant: diffstat, totals, first failing test and its first E-line."""
import re, sys
from pathlib import Path
d = Path(sys.argv[1])
for name in sys.argv[2:]:
    log = (d / f"run_{name}.log").read_text() if (d / f"run_{name}.log").exists() else ""
    total = log.strip().splitlines()[-1] if log.strip() else "NOT RUN"
    failed = re.findall(r"^FAILED (\S+)", log, re.M)
    es = [l.strip() for l in log.splitlines() if l.startswith("E ")]
    first_e = es[0][:200] if es else ""
    stat = (d / f"diffstat_{name}.txt").read_text().strip().splitlines()
    print(f"| {name} | {stat[-1].strip() if stat else ''} | {total} | {failed[0] if failed else '-'} | {first_e} |")

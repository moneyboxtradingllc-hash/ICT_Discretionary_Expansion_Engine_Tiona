"""Apply one named PHASE 3 scratch-only mutation to a worktree (never committed)."""
import subprocess
import sys
from pathlib import Path

wt, name = Path(sys.argv[1]), sys.argv[2]
NB = "src/ai_brain/narrative_brain.py"
MN = "src/ai_brain/market_narrative.py"
LOOP = "src/broker/topstepx_production_loop.py"
CAPTURE_START = "        from ai_brain import market_narrative\n        authored_market_read = market_narrative.capture("
POP = '        output.pop("descriptive_market_read", None)\n'
HOLD = ('        output, narrative_authority_guard = output_direction_hold(\n'
        '            output, brain_input.get("narrative_continuity") or {})\n')
NESTED = ('    item["descriptive_market_read"] = _transported_descriptive(\n'
          '        read.get("descriptive_market_read"))\n')

EDITS = {
    # 2a: the nested read never reaches the next provider input.
    "drop_nested": [(MN, NESTED,
                     '    item["descriptive_market_read"] = descriptive_unknown("dropped")\n', 1)],
    # 2b: an absent/legacy read is synthesized from the old root campaign fields.
    "substitute_root": [(MN, NESTED,
                         '    item["descriptive_market_read"] = (\n'
                         '        _transported_descriptive(read.get("descriptive_market_read"))\n'
                         '        if read.get("descriptive_market_read") else\n'
                         '        {"status": "AVAILABLE", "authority": AUTHORITY,\n'
                         '         "direction": read.get("narrative_direction"),\n'
                         '         "market_story": read.get("market_story")})\n', 1)],
    # 3: a foreign/missing-custody envelope supplies continuity.
    "foreign_custody": [(MN, "        if not isinstance(read_custody, str) or not read_custody:",
                         "        if False:", 1),
                        (MN, '        if read_custody != lineage.get("custody"):', "        if False:", 1)],
    # 4a: participation consumes the descriptive direction (before the hold).
    "consume_descriptive": [(NB, POP, POP +
                             '        _d = (authored_market_read or {}).get("descriptive_market_read") or {}\n'
                             '        if _d.get("status") == "AVAILABLE":\n'
                             '            output["narrative_direction"] = _d["direction"]\n', 1)],
    # 5a: the recorder reads the scan cycle's (absent or decoy) producer again.
    "cycle_producer": [(LOOP, '            producer = getattr(self, "producer", None)\n',
                        '            producer = getattr(self.cycle, "producer", None)\n', 1),
                       (LOOP, "                          if current else None) or {})",
                        "                          ) or {})", 1)],
    # 5b: the preceding scan's trace is accepted as this scan's.
    "stale_trace": [(LOOP, "                           and owner[0] == scan.get(\"scan_count\")\n"
                           "                           and owner[1] == scan.get(\"snapshot_id\"))",
                     ")", 1)],
    # 6a: a future-dated stance row is no longer withheld.
    "future_row": [("src/ai_brain/stance_memory.py",
                    '        if _instant_after(cutoff, current["recorded_at_cutoff"]):\n'
                    '            return FUTURE_DATED\n', "", 1)],
    # 6b: Phase 2 future_context: a later suffix offered as deep context is used.
    "future_context": [("src/live_scan/production_scan_cycle.py",
                        'return [bar for bar in deep_1m\n'
                        '                    if canonical_instant(bar.get("timestamp"), strict=True) <= at]',
                        'return list(deep_1m)', 1)],
}

if name == "capture_after_hold":
    # 1: capture moved after output_direction_hold (reads the guarded text).
    p = wt / NB
    s = p.read_text()
    start, end = s.index(CAPTURE_START), s.index(POP) + len(POP)
    block = s[start:end]
    assert s.count(CAPTURE_START) == 1 and s.count(HOLD) == 1
    s = s[:start] + s[end:]
    s = s.replace(HOLD, HOLD + block)
    p.write_text(s)
elif name == "f6_c2_promotion":
    subprocess.run(["git", "-C", str(wt), "apply", sys.argv[3]], check=True)
else:
    for rel, old, new, count in EDITS[name]:
        p = wt / rel
        s = p.read_text()
        assert s.count(old) == count, (rel, s.count(old))
        p.write_text(s.replace(old, new))
print(subprocess.run(["git", "-C", str(wt), "diff", "--stat"], capture_output=True,
                     text=True).stdout)

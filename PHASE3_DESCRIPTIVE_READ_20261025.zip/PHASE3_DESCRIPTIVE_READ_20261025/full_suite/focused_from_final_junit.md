| Focused file (from final JUnit, 7b5218a) | passed | skipped | failed |
|---|---|---|---|
| tests/test_descriptive_market_read.py | 46 | 0 | 0 |
| tests/test_decision_trace_ownership.py | 6 | 0 | 0 |
| tests/test_protected_structure_continuity.py | 10 | 0 | 0 |
| tests/test_campaign_lifecycle.py | 63 | 0 | 0 |
| tests/test_po3_full_graph_production_loop.py | 8 | 0 | 0 |
| tests/test_market_narrative_first.py | 23 | 0 | 0 |
| tests/test_stance_history_hygiene.py | 69 | 0 | 0 |
| tests/test_campaign_scope_binding.py | 29 | 0 | 0 |
| tests/test_reversal_foundation_proof_closure.py | 31 | 0 | 0 |
| tests/test_brain_fingerprint_portability.py | 88 | 0 | 0 |
| tests/test_combined_safety_readiness.py | 29 | 1 | 0 |
| tests/test_recognition_current_path.py | 3 | 0 | 0 |
| tests/test_recognition_model_authority.py | 28 | 0 | 0 |

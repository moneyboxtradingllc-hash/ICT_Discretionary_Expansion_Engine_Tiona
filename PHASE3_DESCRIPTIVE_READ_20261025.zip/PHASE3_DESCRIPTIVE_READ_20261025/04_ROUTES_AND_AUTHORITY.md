# 04: Reachability routes and remaining authority (nothing enabled)

Every row was measured at the frozen child `7b5218a`, unless the row says "Phase 2". Each producer fact
cites its exact source. The Friday rows come from the child-commit settled-prefix playback
(`session/FRIDAY_TRACE_non-ecu.json`, 281 last-per-cutoff recorded responses, committed tape
`tests/fixtures/session_20261023_settled_tape.json`). The W5 rows come from the existing
`test_campaign_scope_binding` fixture with CONTROLLED Brain replies.

Source map (child line numbers):

| Gate | Location |
|---|---|
| Origin | `market_state/active_path.py:436 ActivePath._apply`, `:142 extract_occurrences` |
| Origin family | `ai_brain/narrative_continuity.py:204 _authoritative_opposing_origin` (accepts only `rejected_raid_reclaim`, `:215`) |
| Local transfer | `:339 _transfer_proof` |
| Hold | `:761 output_direction_hold` |
| Candidate direction | `:882 candidate_direction_authorized` |
| D3-B STRICT | `market_data/campaign_scope.py:74 campaign_scope_proof` |
| Candidate | `broker/topstepx_production_loop.py:1208/1534 self.producer.produce(..., require_campaign_lifecycle=True)` |

## Route table

| Route | Authoritative source | Actual fact identities | Chronology / scope required | Real producer → consumer | Root Brain intent | Local bearing | Independent supporting life | D3 raid | Draw / Lifecycle | Candidate / tool / plan / final quote | First unresolved witness | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **R1 `rejected_raid_reclaim` + D3-B: W5 healthy** | `_authoritative_opposing_origin`, `_transfer_proof`, `campaign_scope_proof`; owner selection 2026-10-09 (D0=a, D3=B, STRICT, INDEPENDENT_SUPPORTING_LIFE, roles 5m/15m, K=1) | Incumbent 1m low 29524.25 dies 14:23. Bearish 1m rejected buy-side raid origin 14:25. Bearing 5m high 29519.75 `5m:swing_high:29519.8` registered 14:29. 5m raid R 14:25 (Phase 2 02_TRACEABILITY row "Genuine already-authorized positive") | death < origin ≤ cutoff; bearing registered inside the new leg; R strictly after D; same contract/session/custody | ActivePath → `_transfer_proof` → `campaign_scope_proof` (route B) → CampaignScopeCustody (T2 PENDING, T3 ACTIVE) → Lifecycle → `CandidateProducer.produce` | bearish `propose_entry` (CONTROLLED) | present, intact, expected side | the 5m life, certificate INTACT | passes (R 14:25 > D 14:23) | T3 newborn refusal; T4 ACTIVE_DELIVERY | Real bearish candidate at T4. The bound watching plan survives a fresh cutoff; lost custody refuses; `validate_final_quote` is enforced | none | **REACHABLE**. Re-proven at `7b5218a` with a descriptive read in BOTH lanes (`test_existing_w5_bearish_candidate_and_bound_plan_are_unchanged[non-ecu/ecu]`); its geometry and assertions are the parent's own |
| **R1-neg matched missing witness** | same | The same life registered **before** the death (FICTIONAL tape) | same | same | same | absent (G7) | n/a | not evaluated (`lt_not_verified`) | TRANSFER_UNRESOLVED | `campaign_lifecycle_refused` | `G7_load_bearing_present` | **LEGITIMATE REFUSAL** (`test_same_life_bears_only_when_registered_inside_the_new_leg`, both directions; in the 7b5218a suite) |
| **R1-Friday 17:15** | same | Owner bearish/active. Origin 1m `buy_side_raid_rejected` 17:09. Death bullish 1m 29195.0 at 17:08. Bearish catalog life 5m high 29294.5 `5m:swing_high:29294.5` registered 15:59 (certificate INTACT, `d3 = {route_b: null, reason: lt_not_verified}`). Bearish raids 15:55/16:00/16:05 | as above | same | recorded raw `conflicted`/`stand_down` (17:15 ordinal 330) | **absent**: the 1m 29263 high re-registered 16:48 and the 5m 29294.5 high both precede the 17:08 death | the 5m life is present but registered before D | would fail independently: every bearish raid (≤16:05) precedes D 17:08 | TRANSFER_UNRESOLVED (`narrative_control_transfer_not_yet_confirmed`) | `campaign_lifecycle_refused` | `G7_load_bearing_present` | **LEGITIMATE REFUSAL**; unchanged from 736c610 (`test_friday_retained_high_*` both lanes, with and without a descriptive read) |
| **R2 CISD contribution (UNAPPROVED reference)** | `0df06ea:docs/recognition_validation/cisd/CISD_CONTRACT_PROPOSAL.md` + `cisd_shadow.py`. **Not an ancestor of 736c610.** Not ratified: O1–O9 open | Rebased onto the child's committed tape: bearish 5m run 15:45–15:55, anchor open 29231.75, extreme 29306.0 (16:00 bucket); break bucket 16:20, close 29215.25, available 16:25 → first knowable at production cutoff 16:24 (`session/CISD_REBASE.json`; the reference run/event reproduces exactly) | O5 (precede vs follow death) and O2 (extreme selection) are owner choices; under the current law the origin must follow the proved death | none: no `src` reference to CISD at 7b5218a (`git grep -i cisd -- src` empty) | 16:22/16:29 raw `conflicted` then `bearish`, all `stand_down` | absent | the bearish 5m 29294.5 life (registered 15:59, before the 16:23 death) | **fails**: bearish raids 15:55–16:05 precede D 16:23 | TRANSFER_UNRESOLVED | `campaign_lifecycle_refused` | as descriptive evidence: changes no gate. As a hypothetical origin it still fails G1 (owner none), G2 (forming, not active), G5 (family unregistered), G6 (no progression), G7–G9 (no bearish bearing) and D3-B STRICT | **DESCRIPTIVE EVIDENCE ONLY / AUTHORITY DISABLED**. A new origin label alone completes no path. The 16:20 close available at 16:25 cannot justify the earlier noon entry |
| **R3 Q-BEARING-R** (Phase 2 proposal) | Phase 2 `05_REMAINING_AUTHORITY_LIMITS.md`. Needs an amendment to the ActivePath bearing law | Friday 1m 29263 (16:48) / C2 5m 29500 (03:04): no post-death event names either life | a post-death event naming the exact LifeRef | none (not implemented) | n/a | unchanged | unchanged | unchanged | unchanged | unchanged | the post-death event does not exist on any measured tape | **UNAPPROVED, DISABLED**. No demonstrated participation change on Friday, C2 or W5 |
| **R4 f6 old-life binder** (`f6e4013`) | rejected by the Phase 2 contract ("mere survival cannot convert C2") | binds any still-current pre-death life | none | scratch mutant only | n/a | binds the pre-death life | n/a | n/a | C2 `confirmed_transfer` | n/a | it fails C2 | **REJECTED**. Re-run as activated mutant 4b at 7b5218a (see 02) |

## Additional evidence vs an authority origin (CISD)

- **Descriptive.** A settled CISD fact is something the Brain could cite in `descriptive_market_read`. That field is
  OBSERVATIONAL_ONLY and has no reader in participation code (`test_no_participation_module_reads_the_descriptive_view`;
  mutant 4a). It changes no gate, no hold, no candidate and no plan.
- **Authority.** It would have to be registered in `_authoritative_opposing_origin`, a bound closure source. That
  rotates the fingerprint and needs fresh authorization. Even then, every gate in R2 above still fails on Friday:
  - G1, G2: the owner is `none`/forming; the bullish 3m `sell_side_raid_rejected` at 16:24 replaced the hypothesis.
  - G6–G9: no bearish progression or bearing.
  - D3-B STRICT: no bearish supporting raid after the 16:23 death.
- No route-specific loophole is proposed.

## New participation rule?

**None proposed.** Current primary evidence does not justify one:

- Every recorded primary action in the 397-record derivative was `stand_down` (382 AVAILABLE; 15 UNKNOWN/non-primary).
- All 281 Friday playback cutoffs refuse at `campaign_lifecycle_refused`, each for a causally explained lifecycle
  state:
  - ESTABLISHING: 14 cutoffs, 13:18–13:31, while the owner is still forming;
  - AUTHORITY_UNKNOWN: 96 cutoffs, interleaved; mostly a bullish owner whose Draw authority is UNKNOWN;
  - TRANSFER_UNRESOLVED: 171 cutoffs.
  - From 17:15 the bearish owner has no load-bearing structure (`G7_load_bearing_present`, 26 cutoffs), then from
    17:41 is no longer active (`G2_status_active`, 17:41–17:58, 18 cutoffs).
- The healthy W5 route shows that the existing law reaches a candidate when its witnesses exist.
- The descriptive field now lets the Brain state a different read without permission.

Proposing a rule would mean choosing trading doctrine (O1/O5 for CISD, or the bearing law for Q-BEARING-R). That is
reserved for Codex/Maurice ratification.

## Strictly reserved decisions (unchanged; not chosen here)

- CISD O1–O9. In particular, O1 decides evidence vs origin family and O5 decides whether CISD may precede the death.
- Q-BEARING-R as an amendment to the ActivePath bearing law.
- Any D3 relaxation, any new transfer family, any broad f6 binder, and any change to economic, risk or execution
  policy.
- Whether historical recognition improved. This is UNPROVEN: no fresh-model calls were authorized, and the new field
  did not exist historically.

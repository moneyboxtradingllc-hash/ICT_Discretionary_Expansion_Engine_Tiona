import copy, json, os
from datetime import datetime, timedelta
import test_protected_structure_continuity as P

def test_dump(tmp_path, monkeypatch):
    out = {}
    for tag, deep in (("settled", [b for b in P.TAPE if b["timestamp"] <= P._cut("17:15")]),
                      ("future", copy.deepcopy(P.TAPE))):
        monkeypatch.setenv("OCCURRENCE_LEDGER_DIR", str(tmp_path / tag))
        cut = P._cut("17:15")
        rows = [b for b in P.TAPE if b["timestamp"] <= cut][-300:]
        scan = P._friday_cycle(tag).scan(rows, now=datetime.fromisoformat(cut) + timedelta(minutes=1),
                                         invoke_brain=False, deep_1m=deep)
        out[tag] = {"catalog": scan["snapshot"].get("campaign_premise_catalog"),
                    "session_context": scan["snapshot"].get("session_context"),
                    "facts": P._facts(scan)}
    open(os.environ["P3_FC_OUT"], "w").write(json.dumps(out, indent=1, default=str))

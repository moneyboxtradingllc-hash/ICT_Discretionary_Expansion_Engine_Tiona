"""Phase 3 parent reproducer: actual ProductionLoop decision-record trace ownership.

Real ProductionLoop._scan_once over the existing W5 natural tape (disarmed), real
ProductionScanCycle and CandidateProducer; Brain responses are the existing MOCKED
W5 replies. Test-only instrumentation wraps the producer instance's produce() to log
which scan actually called it and the trace it left; nothing else is changed.
"""
import copy, json, os, sys
from pathlib import Path
import pytest
import test_po3_full_graph_production_loop as G
import test_po3_anchor_replacement_revocation as C

OUT = Path(os.environ["P3_OUT"])
KEYS = ("requested_objective_id", "resolved_objective_id", "resolved_invalidation_id",
        "tool_selected", "tool_matched", "geometry_valid", "reward_risk")


class Decoy:
    last_decision_trace = {"requested_objective_id": "DECOY-OBJECTIVE",
                           "resolved_objective_id": "DECOY-OBJECTIVE", "geometry_valid": True}


@pytest.mark.parametrize("decoy", [False, True], ids=["plain", "decoy-cycle-producer"])
@pytest.mark.parametrize("ecu", [False, True], ids=["non-ecu", "ecu"])
def test_recorder(tmp_path, monkeypatch, ecu, decoy):
    from broker.luna_candidate_producer import CandidateProducer
    calls = []
    real = CandidateProducer.produce

    def logged(self, **kw):
        try:
            return real(self, **kw)
        finally:
            calls.append({"snapshot_id": kw.get("snapshot_id"),
                          "trace": {k: copy.deepcopy(self.last_decision_trace.get(k)) for k in KEYS}})
    monkeypatch.setattr(CandidateProducer, "produce", logged)
    if decoy:
        from live_scan.production_scan_cycle import ProductionScanCycle
        monkeypatch.setattr(ProductionScanCycle, "producer", Decoy(), raising=False)
    out, loop, venue, mission, chosen, payloads = G._loop(
        tmp_path / "run", monkeypatch, C._HEALTHY, ecu=ecu, arm_at=None)
    root = tmp_path / "run" / "replay"
    files = list(root.rglob("candidate_decisions.jsonl"))
    assert files, list(root.rglob("*"))
    records = [json.loads(l) for f in files for l in f.read_text().splitlines() if l.strip()]
    produced = {c["snapshot_id"]: c["trace"] for c in calls}
    rows = []
    for r in records:
        t = produced.get(r["scan_id"])
        rows.append({"scan_id": r["scan_id"], "disposition": r["final_disposition"],
                     "reason": r["final_rejection_reason"],
                     "produce_called_this_scan": t is not None,
                     "recorded": {k: r.get(k) for k in KEYS},
                     "actual_producer_trace": t})
    lane = ("ecu" if ecu else "non-ecu") + ("-decoy" if decoy else "")
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / f"RECORDER_PARENT_{lane}.json").write_text(json.dumps(rows, indent=1, default=str))
    created = [r for r in rows if r["disposition"] == "CANDIDATE_CREATED"]
    print("\nLANE", lane, "records", len(rows), "produced", len(calls), "created", len(created),
          "not_produced_records", sum(not r["produce_called_this_scan"] for r in rows))
    for r in created[:2]:
        print(" CREATED", r["scan_id"], "recorded", r["recorded"], "actual", r["actual_producer_trace"])

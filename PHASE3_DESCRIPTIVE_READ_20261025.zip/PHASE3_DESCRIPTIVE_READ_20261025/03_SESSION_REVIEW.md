# 03: Whole-session review, Friday 2026-10-23 (DIAGNOSTIC ONLY)

## Inputs and their limits

| Input | Identity | Limit |
|---|---|---|
| `FRIDAY_NARRATIVE_FIELDS_397.json` | sha256 `1bab76a7…`; verified inside the supplied ZIP `c470b9a9…` | Raw response fields AS RECORDED, not revalidated. 382 AVAILABLE, 15 UNKNOWN (`llm_failed_fallback`). 12 records have privacy-withheld cells, kept UNKNOWN. No input payloads |
| Settled tape | committed `tests/fixtures/session_20261023_settled_tape.json`, canonical sha256 `b872b6a2…` | The fixture's own archival provenance only, not provider certification. Bar stamped ≤ cutoff = settled (the playback convention) |
| Producer facts per cutoff | `session/FRIDAY_TRACE_non-ecu.json`: real ProductionScanCycle settled-prefix playback, re-run at the child | The honest scope is 281 last-per-cutoff recorded responses. The other 116 records were not replayed and are marked NOT_REPLAYED, not inferred. Quotes are CONTROLLED. The ECU lane was identical in Phase 2 and was not re-run here |
| `descriptive_market_read` | did not exist historically | UNKNOWN for every one of the 397 records; never copied from legacy fields |

Every imported module of the playback is byte-identical to `7b5218a`. The run happened while
`topstepx_production_loop.py` (not imported by the probe) and the pinned literals were still being edited. It equals
the first run in every field except the corrected `scope` projection (`cmp` of both traces with `scope` removed).

## Step 1: inventory (all 397 ordinals; no collapse)

`session/INVENTORY_397.csv` has one row per ordinal, sorted by ordinal, with source-record identity kept.
Summary (`session/INVENTORY_SUMMARY.json`):

| Measure | Value |
|---|---|
| Records / distinct cutoffs | 397 / 281 (116 records at duplicate cutoffs) |
| Raw direction | conflicted 217, bullish 147, bearish 18, null 15 |
| Raw action | stand_down 382, null 15 |
| Guarded direction | conflicted 251, bullish 145, bearish 1 |
| Guarded action | stand_down 397 |
| Raw → guarded direction | bearish→conflicted 17, bullish→conflicted 13, None→bullish 11, None→conflicted 4 |
| Guarded story differs from raw story | 275 |

The model label recorded in all 397 records is the historical label only. It is not a claim about any current model.

## Step 2: sealed checkpoint rule (written BEFORE any scoring)

The rule: take all records at the cutoff; otherwise the latest earlier cutoff within two minutes; otherwise MISSING.

`session/CHECKPOINT_MANIFEST.json`, sha256 `0c8f5759f450fa2c4a585774d1e129adfb9557aa82ea40697a398dbc27c1d403`, was
written at 17:49:08Z. `session_review.py` was first written after that. All 13 checkpoints were SELECTED at their exact
cutoff. Ordinals: 0; 19, 20; 61; 118; 143; 177; 223; 248, 249; 259, 260; 285; 330; 367, 368; 396.

## Steps 3–4: facts per checkpoint and the (a)–(e) separation

The facts are producer facts at the cutoff, from the playback, with their identities. Historical INPUT provenance is
MISSING, because the derivative has no payloads. The full fact blocks are in `session/SESSION_REVIEW.json`; they
include the protected lives alive at the cutoff and the sweeps of the last 30 minutes with occurrence ids and
`observed_at`.

How to read the columns:

- (a) and (b) are the recorded raw fields.
- (c) has two parts: the recorded guarded output, and the child playback's guarded output plus candidate. The second
  exists only for the last record per cutoff.
- (d) is MISSING everywhere. The derivative records no tool, objective or plan, and every action was `stand_down`.
  Nothing was inferred.
- (e) is the first actual blocker in the child playback.
- The transfer-gate column is the `_transfer_proof` conjunct diagnostic evaluated from the prior recorded direction.
  It is not a blocker. G0b "directions valid and differ" means no opposing transfer was in question.

Describing selling is not proposing a short. A stand_down can be correct. No owner setup annotation or trade intent
was inferred.

| CP | cutoff | settled 1m bar (O/H/L/C) | session range since 13:00Z | ActivePath owner / forming / status | origin (family, event, at, tf) | last death (owner, at, level, tf) | lifecycle | first failed transfer gate | candidate |
|---|---|---|---|---|---|---|---|---|---|
| 13:18 | 13:18 | 29028.5/29050.25/29024.25/29029.25 | 29007.0–29080.25 | none / bullish / forming | rejected_raid_reclaim, sell_side_raid_rejected, 13:15, 1m | bullish, 13:14, 29041.75, 1m | ESTABLISHING (active_path_causal_hypothesis_only) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 13:30 | 13:30 | 29029.75/29054.75/28993.5/29052.5 | 28993.5–29080.25 | none / bullish / forming | rejected_raid_reclaim, sell_side_raid_rejected, 13:15, 1m | bullish, 13:14, 29041.75, 1m | ESTABLISHING (active_path_causal_hypothesis_only) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 14:00 | 14:00 | 29169.75/29189.75/29123.0/29138.25 | 28986.25–29189.75 | bullish / None / active | rejected_raid_reclaim, sell_side_raid_rejected, 13:15, 1m | bullish, 13:14, 29041.75, 1m | AUTHORITY_UNKNOWN (campaign_draw_authority_unknown) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 14:45 | 14:45 | 29265.75/29268.0/29235.0/29255.25 | 28986.25–29270.75 | bullish / None / active | rejected_raid_reclaim, sell_side_raid_rejected, 13:15, 1m | bullish, 13:14, 29041.75, 1m | AUTHORITY_UNKNOWN (campaign_draw_authority_unknown) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 15:06 | 15:06 | 29259.75/29269.25/29251.75/29260.5 | 28986.25–29325.75 | bullish / None / active | rejected_raid_reclaim, sell_side_raid_rejected, 13:15, 1m | bullish, 13:14, 29041.75, 1m | AUTHORITY_UNKNOWN (campaign_draw_authority_unknown) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 15:30 | 15:30 | 29260.5/29271.25/29248.0/29262.5 | 28986.25–29325.75 | bullish / None / active | rejected_raid_reclaim, sell_side_raid_rejected, 15:17, 1m | bullish, 15:14, 29235.75, 1m | AUTHORITY_UNKNOWN (campaign_draw_authority_unknown) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 16:05 | 16:05 | 29289.0/29297.5/29282.75/29290.5 | 28986.25–29325.75 | bullish / None / active | rejected_raid_reclaim, sell_side_raid_rejected, 15:44, 5m | bullish, 15:43, 29234.25, 1m | TRANSFER_UNRESOLVED (narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 16:22 | 16:22 | 29240.5/29245.5/29229.5/29239.25 | 28986.25–29325.75 | none / bullish / forming | rejected_raid_reclaim, sell_side_raid_rejected, 16:21, 1m | bullish, 16:20, 29238.0, 1m | TRANSFER_UNRESOLVED (narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 16:29 | 16:29 | 29219.5/29223.25/29210.75/29214.25 | 28986.25–29325.75 | none / bullish / forming | rejected_raid_reclaim, sell_side_raid_rejected, 16:24, 3m | bullish, 16:23, 29238.0, 1m | TRANSFER_UNRESOLVED (narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 16:45 | 16:45 | 29253.75/29264.25/29248.75/29260.5 | 28986.25–29325.75 | none / bullish / forming | rejected_raid_reclaim, sell_side_raid_rejected, 16:24, 3m | bullish, 16:23, 29238.0, 1m | TRANSFER_UNRESOLVED (narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 17:15 | 17:15 | 29179.75/29181.5/29147.0/29148.75 | 28986.25–29325.75 | bearish / None / active | rejected_raid_reclaim, buy_side_raid_rejected, 17:09, 1m | bullish, 17:08, 29195.0, 1m | TRANSFER_UNRESOLVED (narrative_control_transfer_not_yet_confirmed) | G7_load_bearing_present | campaign_lifecycle_refused |
| 17:40 | 17:40 | 29163.25/29169.75/29157.5/29159.25 | 28986.25–29325.75 | bearish / None / active | rejected_raid_reclaim, buy_side_raid_rejected, 17:09, 1m | bullish, 17:08, 29195.0, 1m | TRANSFER_UNRESOLVED (narrative_control_transfer_not_yet_confirmed) | G7_load_bearing_present | campaign_lifecycle_refused |
| 17:58 | 17:58 | 29192.5/29224.75/29190.5/29214.25 | 28986.25–29325.75 | bearish / None / contested | rejected_raid_reclaim, buy_side_raid_rejected, 17:09, 1m | bullish, 17:08, 29195.0, 1m | TRANSFER_UNRESOLVED (narrative_control_transfer_not_yet_confirmed) | G2_status_active | campaign_lifecycle_refused |

| CP | ordinal | record | (a) raw phase | (b) raw direction / action | (c) recorded guarded direction / action | (c) child playback | (d) tool/objective/plan | (e) first actual blocker | transfer-gate diagnostic (from prior recorded direction) |
|---|---|---|---|---|---|---|---|---|---|
| 13:18 | 0 | 20261023_092051_MNQ.json | transition | bearish / stand_down | bearish / stand_down | bearish / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (ESTABLISHING: active_path_causal_hypothesis_only) | G0b_directions_valid_and_differ |
| 13:30 | 19 | 20261023_093137_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | NOT_REPLAYED (playback scope is last-per-cutoff) | MISSING (not recorded) | recorded action stand_down; downstream blocker NOT_REPLAYED | NOT_REPLAYED |
| 13:30 | 20 | 20261023_093217_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (ESTABLISHING: active_path_causal_hypothesis_only) | G0b_directions_valid_and_differ |
| 14:00 | 61 | 20261023_100201_MNQ.json | retracement | bullish / stand_down | bullish / stand_down | bullish / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (AUTHORITY_UNKNOWN: campaign_draw_authority_unknown) | G0b_directions_valid_and_differ |
| 14:45 | 118 | 20261023_104644_MNQ.json | continuation | bullish / stand_down | bullish / stand_down | bullish / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (AUTHORITY_UNKNOWN: campaign_draw_authority_unknown) | G0b_directions_valid_and_differ |
| 15:06 | 143 | 20261023_110813_MNQ.json | retracement | bullish / stand_down | bullish / stand_down | bullish / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (AUTHORITY_UNKNOWN: campaign_draw_authority_unknown) | G0b_directions_valid_and_differ |
| 15:30 | 177 | 20261023_113219_MNQ.json | retracement | bullish / stand_down | bullish / stand_down | bullish / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (AUTHORITY_UNKNOWN: campaign_draw_authority_unknown) | G0b_directions_valid_and_differ |
| 16:05 | 223 | 20261023_120643_MNQ.json | transition | bullish / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (TRANSFER_UNRESOLVED: narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ |
| 16:22 | 248 | 20261023_122353_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | NOT_REPLAYED (playback scope is last-per-cutoff) | MISSING (not recorded) | recorded action stand_down; downstream blocker NOT_REPLAYED | NOT_REPLAYED |
| 16:22 | 249 | 20261023_122419_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (TRANSFER_UNRESOLVED: narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ |
| 16:29 | 259 | 20261023_123045_MNQ.json | transition | bearish / stand_down | conflicted / stand_down | NOT_REPLAYED (playback scope is last-per-cutoff) | MISSING (not recorded) | recorded action stand_down; downstream blocker NOT_REPLAYED | NOT_REPLAYED |
| 16:29 | 260 | 20261023_123126_MNQ.json | transition | bearish / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (TRANSFER_UNRESOLVED: narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ |
| 16:45 | 285 | 20261023_124704_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (TRANSFER_UNRESOLVED: narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ |
| 17:15 | 330 | 20261023_131633_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (TRANSFER_UNRESOLVED: narrative_control_transfer_not_yet_confirmed) | G7_load_bearing_present |
| 17:40 | 367 | 20261023_134136_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | NOT_REPLAYED (playback scope is last-per-cutoff) | MISSING (not recorded) | recorded action stand_down; downstream blocker NOT_REPLAYED | NOT_REPLAYED |
| 17:40 | 368 | 20261023_134202_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (TRANSFER_UNRESOLVED: narrative_control_transfer_not_yet_confirmed) | G7_load_bearing_present |
| 17:58 | 396 | 20261023_140006_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (TRANSFER_UNRESOLVED: narrative_control_transfer_not_yet_confirmed) | G2_status_active |


## Step 5: claim grades (diagnostics, not recognition scores)

`session/CLAIM_GRADES.csv` holds 139 claims over 17 checkpoint records. Each row carries source evidence, rationale
and quoted context. The rules:

- **Direction claim.** The raw `narrative_direction` is compared with the producer ActivePath owner at the cutoff:
  - EVIDENCE_SUPPORTED when it equals a bullish or bearish owner;
  - CONTRADICTED when a bullish or bearish owner is opposite;
  - AMBIGUOUS when the owner is none or forming, or the read is `conflicted`;
  - MISSING when there is no direction.
- **Level claims.** Each quoted price is matched by identity only:
  - EVIDENCE_SUPPORTED: a producer life, sweep or registry level available at the cutoff. This shows the level is a
    producer fact. It does not show the claimed raid, causal role, timing or campaign read.
  - AMBIGUOUS: only an OHLC print at or before the cutoff matches. That is number presence only.
  - CONTRADICTED: the number first prints only after the cutoff, or the text calls a life "intact" although the ledger
    shows it VIOLATED with no re-registered life alive at that level.
  - MISSING: a quote, bid or ask value (the recorded quote is not in the derivative), or no print and no producer fact.

| Kind | EVIDENCE_SUPPORTED | AMBIGUOUS | CONTRADICTED | MISSING |
|---|---|---|---|---|
| direction (17) | 5 | 12 | 0 | 0 |
| level (122) | 74 | 39 | 0 | 9 |

| CP | EVIDENCE_SUPPORTED | AMBIGUOUS | CONTRADICTED | MISSING |
|---|---|---|---|---|
| 13:18 | 3 | 3 | 0 | 1 |
| 13:30 | 7 | 8 | 0 | 1 |
| 14:00 | 7 | 1 | 0 | 2 |
| 14:45 | 5 | 2 | 0 | 1 |
| 15:06 | 5 | 1 | 0 | 0 |
| 15:30 | 6 | 2 | 0 | 0 |
| 16:05 | 5 | 1 | 0 | 0 |
| 16:22 | 10 | 6 | 0 | 0 |
| 16:29 | 6 | 8 | 0 | 0 |
| 16:45 | 4 | 3 | 0 | 2 |
| 17:15 | 3 | 6 | 0 | 0 |
| 17:40 | 12 | 5 | 0 | 0 |
| 17:58 | 6 | 5 | 0 | 2 |

**Analysis error found and repaired before reporting.** The first grading pass produced 8 CONTRADICTED claims, and
all 8 were artifacts of my grader:

- 3 were quoted bid/ask values that I had treated as bar prints.
- 5 were "29294.5 / 29263 remain intact" statements. The ledger shows both lives violated (16:02 and 16:46) **and
  re-registered at the same level** (3m 16:08, 1m 16:48), so they were alive at the cutoff.

The corrected grader treats quotes as MISSING and checks re-registration. No claim is CONTRADICTED. The first-pass
CSV was overwritten by the corrected run; its 8 CONTRADICTED rows, exactly as printed, are in
`session/first_pass/FIRST_PASS_CONTRADICTED.txt`.

What the grades do and do not say:

- The 5 supported direction claims are the five bullish reads at 14:00–16:05, during a bullish owner. Every
  `conflicted` read, and the bearish reads while the owner was none/forming (13:18, 16:29), are AMBIGUOUS, not wrong.
- At 17:15–17:58 the producer owner is bearish and every record reads `conflicted`. That is AMBIGUOUS, consistent with
  the transfer being unresolved (G7 then G2).
- None of these grades certifies recognition or sets a threshold.

## Step 6: new descriptive-field transport vs historical reads (separate)

- **Constructed acceptance cases** (02): MOCK cognition only. The descriptive read survives the hold into the next
  provider input in both lanes, and a CONTROLLED follow-up consumes it.
- **Historical reads:** the field is UNKNOWN for all 397 records.
- No retrospective model call was made. No claim is made that a current model now reasons better about Friday.

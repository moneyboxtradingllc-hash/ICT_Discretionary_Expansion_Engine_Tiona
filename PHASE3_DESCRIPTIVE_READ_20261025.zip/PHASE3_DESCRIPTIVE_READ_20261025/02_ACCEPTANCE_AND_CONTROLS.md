# 02: Acceptance matrix, parent reproducers, activated controls, trace ownership

Every case below uses the real ProductionScanCycle, the production StanceMemory accessors and both ECU lanes unless
the row says otherwise. Labels:

- **MOCK** cognition: CONTROLLED Brain replies.
- **CONSTRUCTED/FICTIONAL** tapes are marked as such; the W5 and C2 tapes are existing fixtures.
- **DEFENSE-ONLY** injection is marked.
- The provider input is copied at call time (`_capture_transport` deep-copies inside `_call_llm`).

The healthy twin of every control is the final full suite at `7b5218a` (all of these cases pass; see 05).

## 1. Acceptance matrix → tests (`tests/test_descriptive_market_read.py` 46 cases, `tests/test_decision_trace_ownership.py` 6)

| Matrix row | Test(s), both lanes unless noted | What it proves |
|---|---|---|
| Healthy authorized bullish campaign + opportunity | `test_descriptive_read_survives_hold_into_next_input_without_permission`; `test_existing_bullish_retained_reversal_candidate_is_unchanged` (the RF positive, re-run with an opposite **bearish** descriptive read) | Candidate geometry (direction, entry, invalidation, objective identity/kind/price, narrative) and every scan's participation tuple equal the no-descriptive baseline |
| Symmetric healthy bearish (W5) | `test_existing_w5_bearish_candidate_and_bound_plan_are_unchanged[non-ecu/ecu]` (adds a bullish descriptive read) | The parent's own T2 PENDING → T3 newborn refusal → T4 bearish candidate assertions and the bound-plan assertions all hold |
| Intact bullish campaign, bearish local description, no transfer | `test_descriptive_read_survives_hold_…` | The bearish read is captured pre-hold. The guarded output equals `NF.HELD` and has no descriptive key. The read reaches the NEXT provider input in `market_narrative_history.last.descriptive_market_read` (AVAILABLE, bearish), with `root_fields_basis = pre_hold_campaign_response`. It is absent from the guarded `stance_history` and from `narrative_continuity`. Root campaign/action/qualification are unchanged |
| C2 and Friday retained highs | `test_c2_surviving_high_refusal_is_unchanged_with_a_descriptive_read`; `test_friday_retained_high_refusal_is_unchanged_with_a_descriptive_read` | The parent's own C2/Friday assertions run unmodified with a bearish descriptive read added: fact transported, the same missing-bearing/transfer refusal, no f6 promotion. The C2 case also asserts that an AVAILABLE bearish read really reached the provider inputs |
| Root `stand_down` + strong setup prose | `test_strong_descriptive_language_never_becomes_entry_or_plan[stand_down]` | Every scan's candidate is a refusal and its participation tuple equals the baseline; `authored_action` stays the root's. No entry or conditional plan is inferred from prose or descriptive direction |
| Root valid `propose_entry`, unresolved transfer | `test_strong_descriptive_language_never_becomes_entry_or_plan[propose_entry]` (bearish propose_entry against the intact bullish incumbent) | Refused at the same gate with the same reason as the no-descriptive baseline at every scan; no fallback to a permissive field. A wrong-occurrence variant was not separately constructed |
| Valid watching / conditional plan | `test_existing_w5_bearish_candidate_and_bound_plan_are_unchanged` (`test_real_bound_plan_survives_fresh_cutoff_and_refuses_lost_custody` inside it) | Plan authoring, fresh-cutoff survival, lost-custody refusal and `validate_final_quote` are unchanged |
| Invalid root packet | `test_invalid_root_packet_is_not_repaired_by_a_valid_descriptive_read` (non-ECU; `current_action: enter_short_now`) | The guarded output and source equal the no-descriptive invalid baseline (existing fallback). The nested read is UNKNOWN; a valid descriptive block cannot repair or authorize it |
| Missing / null / malformed | `test_malformed_descriptive_field_is_unknown_and_root_is_untouched` × 8 (non-ECU: absent, null, string, unexpected action key, unexpected metadata key, blank story, bad direction, too many uncertainties); `test_descriptive_text_is_bounded_and_truncation_declared` | Nested UNKNOWN with the precise reason, at capture and in the next input. The legacy pre-hold capture stays AVAILABLE with the original story; source stays `llm`; participation (including the guarded root keys) equals the baseline at every scan. Truncation is declared |
| Degraded / fallback / circuit-open | `test_degraded_or_fallback_cognition_has_no_available_descriptive_read` (unit level over `capture`: `degraded`, `deterministic`, `llm_failed_fallback`, `provider_circuit_open`; legacy row) | Nested UNKNOWN with no prose, even when the payload carried a valid object; no forged prior cognition |
| Foreign/missing custody, relabel, legacy row | `test_follow_up_read_depends_on_transported_history[healthy/legacy_row/foreign_custody/authority_relabel]` | Only the healthy row supplies continuity. The others give `legacy_read_without_descriptive_field` / `provenance_mismatch:history_lineage.custody` / `authority_label_invalid` |
| Wrong contract/session, superseded, future, legacy schema, malformed chronology | `test_withheld_row_never_supplies_descriptive_continuity` × 6 (non-ECU) | Each row carries a well-formed descriptive read, is withheld with its existing reason, and supplies nothing |
| A later fact changes the read | `test_follow_up_read_depends_on_transported_history[healthy]` (and the `[legacy_row]`/`[foreign_custody]` controls) | The MOCK follow-up builds its story from the ACTUAL transported prior read and the current ActivePath (owner/status/last failure). Removing or poisoning that history changes the follow-up to `NO PRIOR DESCRIPTIVE READ (<reason>)`. No automatic campaign transfer |
| Duplicate cutoff | `test_duplicate_cutoff_keeps_honest_identity` | The original cutoff/provenance is kept; no future suffix |
| Restart / rebuild | `test_restart_keeps_the_persisted_read_but_lends_it_no_continuity` | The persisted row keeps the exact capture and provenance. A new process cannot prove the lineage, so nothing is transported. The new lineage's fresh read becomes the next continuity |
| Contract / reader scope | `test_prompt_states_the_two_roles_narrowly`; `test_no_participation_module_reads_the_descriptive_view` | The prompt string is a small contract check only. Reader scope is `market_narrative`, `brain_prompt`, and the single pop in `narrative_brain` |
| Report | `test_report_separates_descriptive_campaign_permitted_and_refusal` | Four columns from four sources; a legacy record's descriptive is UNKNOWN |
| Observability: real producer vs decoy | `test_decision_trace_ownership.py` (6) | See §4 |

**Rolling eviction and revision** are covered by the existing hygiene suites, which run unchanged in the final suite.
The descriptive view rides only on rows those suites already admit. No separate descriptive case was added.

The CONTROLLED follow-up is a deterministic cognition seam, not model reasoning. Its story is constructed from the
transported prior read and current input precisely so that removing or poisoning the history visibly changes it.

## 2. Parent reproducers (736c610 + the Phase 3 test files, unmodified)

| Run | Result |
|---|---|
| Both new files | **37 failed, 6 passed** (`logs/parent_repro.log`, `PARENT_REPRODUCER_FIRST_ERRORS.txt`) |
| Restart cases added later | **2 failed** |
| Withheld-row and C2 cases added later | **8 failed** (6 withheld-row cases, 2 C2) |

The first errors:
- `KeyError: 'descriptive_market_read'` (no nested field);
- `KeyError: 'decision_trace_source'`;
- the prompt contract missing;
- the decoy case `AssertionError`, where the parent journals `DECOY-OBJECTIVE`.

The 6 parent passes are the invariance reruns of existing positives (RF, W5 ×2, Friday ×2) and the broken-journal
case. They pass by design, because they assert unchanged behaviour.

The parent's absence of the field reproduces transport and expressibility. It is not evidence about what a model
would have recognized.

## 3. Activated controls (scratch worktrees at `9be032e`)

`9be032e` is source-identical to `7b5218a`; the amend added only the withheld-row parametrization and the C2 case. The
diffs are `mutants/mutant_<name>.diff`, and the logs and JUnit files are `mutants/run_<name>.log` and `junit_<name>.xml`.

| # | Mutant | Diff | Result | First failure |
|---|---|---|---|---|
| 1 | `capture_after_hold`: capture moved after `output_direction_hold` | narrative_brain 8+/8− | **6 failed**, 2 passed | `survives_hold[non-ecu]`: captured story is the guarded "Directional control is developing… stand down." instead of the authored text. Also caught by `strong_descriptive[propose_entry]` (authored action became `stand_down`) and the report case |
| 2a | `drop_nested`: nested read replaced by UNKNOWN before the next input | market_narrative 1+/2− | **10 failed**, 2 passed | `survives_hold[non-ecu]` (nested not AVAILABLE in the next input), then follow-up and restart cases |
| 2b | `substitute_root`: an absent or legacy read is synthesized from root campaign fields | market_narrative 6+/2− | **2 failed**, 10 passed | `follow_up[legacy_row-*]`: a synthesized AVAILABLE read appears where UNKNOWN with a reason is required |
| 3 | `foreign_custody`: custody checks removed | market_narrative 2+/2− | **2 failed**, 6 passed | `follow_up[foreign_custody-*]`: foreign envelope supplies continuity |
| 4a | `consume_descriptive`: participation reads the descriptive direction before the hold | narrative_brain 3+ | **5 failed**, 2 passed | `survives_hold[non-ecu]`: `NoCandidate: campaign_lifecycle_refused:AUTHORITY_UNKNOWN` where the baseline has a candidate; also mismatched-permission and existing-positive reruns |
| 4b | `f6_c2_promotion` (`f6_binder.diff`, the rejected f6 old-life binder) | active_path 67+, production_scan_cycle 4+ | **7 failed**, 1 passed | `test_friday_retained_high_…[ecu]`: 29263 high becomes load-bearing (`is None` expected); C2 cases fail too |
| 5a | `cycle_producer`: recorder reads `self.cycle.producer` again (the parent behaviour) | loop 2+/2− | **5 failed**, 1 passed | `records_carry_this_scans_real_producer_trace[non-ecu]` at `scan-20260819T143900` (CANDIDATE_CREATED with a blank trace); the decoy cases fail too |
| 5b | `stale_trace`: ownership check reduced, so a preceding scan's trace is accepted | loop 1+/2− | **1 failed**, 5 passed | `a_scan_without_produce_records_unknown…`: `loop_producer_current_scan` recorded for the refused scan 144000 |
| 6a | `future_row`: the stance FUTURE_DATED withholding removed | stance_memory 2− | **1 failed** | `future_dated_row…`: `withheld_rows.future_dated` is 0. The leaked row still supplied no descriptive read, because `market_narrative._item` rejects it independently (`provenance_mismatch:settled_cutoff`). That is a second defensive layer, reported rather than claimed |
| 6b | `future_context`: Phase 2 mutant; a later suffix offered as deep context is used | production_scan_cycle 1+/2− | **1 failed** | `future_session_bars_…`: the corrected context view differs |

### 3b. Re-run at the final `7b5218a`

| Mutant | Result | Failing cases |
|---|---|---|
| 6a `future_row`, against the parametrized withheld-row cases | **1 failed**, 5 passed | Only `[future_dated]` fails (`withheld_rows.future_dated` is 0). The other five withholding reasons are untouched by this mutant, as expected |
| 4b `f6_c2_promotion`, with the new C2 case | **9 failed**, 1 passed | Both Friday, Friday cold restart, both C2, and both Friday and both C2 descriptive cases. First failure: the 29263 high becomes load-bearing |

The logs are `mutants/final_run_*.log` and `final_junit_*.xml`.

## 4. Decision-trace ownership: before and after

| | Parent `736c610` (`out/RECORDER_PARENT_*.json`) | Final (`out/RECORDER_CHILD_9be032e_*.json`; src = 7b5218a) |
|---|---|---|
| Real loop, W5 tape, both lanes | CANDIDATE_CREATED records carry **blank** objective/invalidation/tool/geometry, although the producer's actual trace has them, because the recorder read `self.cycle.producer` (None) | Every record equals the loop producer's actual trace for that scan. Example: `scan-20260819T143900` has OBJ_LIQ_SSL_2 / INV_PH_5m_2 / fvg / bearish_fvg / geometry_valid / R:R 5.167. `decision_trace_source = loop_producer_current_scan` |
| Decoy `ProductionScanCycle.producer` | `DECOY-OBJECTIVE` journaled as the decision for every scan | Ignored; records identical to the plain run |
| Scan refused before `produce()` (DEFENSE-ONLY injection at the binding gate, bar 14:39 → scan 144000) | n/a (no source field) | `UNKNOWN:no_producer_call_this_scan`, all trace keys null. The preceding scan 143900 keeps its own trace |
| Failing journal (`build_record` raises) | n/a | No records, and every scan outcome is identical to the plain run |

**An error of mine, repaired.** The first implementation wrapped the two calls in a `_produce_for` helper. That hid
both `self.producer.produce(..., require_campaign_lifecycle=True)` call sites from the existing AST structural guard
`test_campaign_lifecycle::test_both_production_candidate_paths_remain_visible_to_structural_guard`, which then failed
in my focused run. The guard was right. The fix keeps both visible calls and only sets the owning scan immediately
before each. The intermediate commits (`84ad106`, then `9be032e`) were never pushed. The final fingerprint
(d17223b71ac698ff) is measured on the final source.

## 5. Phase 2 future-context diagnostic: correction

**What was wrong.** Phase 2's `_context_view` projected `{supports, life_ref, raids}`. No catalog row has a `life_ref`
field, so it compared `None`. Certificates and D3 were omitted. The Phase 2 statement that the rows' "contents, ids
and authority were equal" is therefore **withdrawn** and not reused.

**What the corrected test does.** It now compares the catalog rows' real fields: `life`, `supports`, `certificate`,
`raids` and `d3`, keyed by `life.registration_occurrence_id`. It also compares the catalog context without its process
identifiers, and checks non-vacuity: two lives (bearish 5m 29294.5, bullish 15m 29022.5), both certificates INTACT,
D3 present.

**Context-dependent identifiers, checked separately.** Each `premise_candidate_id` must equal `"pc:" +
sha256({context, life})[:24]` exactly. Between the settled and future-offered runs:

- `custody_lineage` differs, and so do the ids.
- The real fields are equal (`fc/dump.json`): same lives, certificates (`tip_digest`, `settled_through` 17:14, 15
  covered buckets) and `d3` (`route_b: null`, `lt_not_verified`).

**Legitimate nondeterminism.** `custody_lineage` is a fresh `uuid4` at CampaignScopeCustody construction, at
`reset()`, and at a context boundary (`campaign_scope.py:203/223/258`). `premise_candidate_id`, the row order (sorted
by that id) and the catalog `digest` all derive from it.

**Remains unproved.** Phase 2 observed the row order differing between two 17:15 scans "in one process". I did not
establish whether those scans shared a custody lineage. If they did, the order difference has another cause. This is
recorded, not inferred. No production authority defect is inferred from row ordering.

# PHASE 3 return package: index

| File | Contents |
|---|---|
| 00_COMPLETION_REPORT.md | Disposition, identity, repaired errors, practical limits |
| 01_SOURCE_CALL_GRAPH_AND_SCHEMA.md | Changed files, call graph with lines, schema, prompt edits, report columns, authority readers |
| 02_ACCEPTANCE_AND_CONTROLS.md | Matrix → tests, parent reproducers, activated controls (+ final re-runs), trace ownership before/after, Phase 2 diagnostic correction |
| 03_SESSION_REVIEW.md | 397-record inventory, sealed checkpoints, per-checkpoint facts and (a)–(e), claim grades |
| 04_ROUTES_AND_AUTHORITY.md | Route table (`rejected_raid_reclaim`/D3-B incl. W5 + matched refusal, CISD rebased, Q-BEARING-R, f6), reserved decisions |
| 05_VERIFICATION.md | Runtime, identity, ledger, final full suite, superseded runs |
| FULL_DIFF_736c610..7b5218a.patch | `git diff 736c610 7b5218a` |
| PHASE3_review_736c610..7b5218a.bundle | Git bundle of the review branch (prerequisite 736c610) |
| session/ | Manifest (sealed), inventory, review JSON, claim grades, tables, CISD rebase, first-pass contradicted rows |
| traces/ | Friday playback at the child (gzip) |
| out/ | Recorder parent/child records, parent reproducer first errors |
| mutants/ | mutate3.py, runners, every mutant diff/log/JUnit (9be032e and final re-runs) |
| full_suite/ | Collection, shard plan, shard logs, merged JUnit, union, skip reasons, focused table |
| logs/ | Parent reproducers, probes, ledger verification, fingerprints, runner |
| probes/, review_tools/ | Scratch diagnostics (not in the repository) |
| cisd_reference/ | UNAPPROVED reference copies from 0df06ea (not an ancestor of 736c610) |
| fc/ | Future-context settled vs offered catalog dump |
| MANIFEST_SHA256.txt | sha256 of every file above |

To reproduce, `git fetch <bundle> review/descriptive-read-integration-20261025` onto a clone containing 736c610.

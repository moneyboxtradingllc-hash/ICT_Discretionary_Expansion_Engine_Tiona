| CP | cutoff | settled 1m bar (O/H/L/C) | session range since 13:00Z | ActivePath owner / forming / status | origin (family, event, at, tf) | last death (owner, at, level, tf) | lifecycle | first failed transfer gate | candidate |
|---|---|---|---|---|---|---|---|---|---|
| 13:18 | 13:18 | 29028.5/29050.25/29024.25/29029.25 | 29007.0–29080.25 | none / bullish / forming | rejected_raid_reclaim, sell_side_raid_rejected, 13:15, 1m | bullish, 13:14, 29041.75, 1m | ESTABLISHING (active_path_causal_hypothesis_only) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 13:30 | 13:30 | 29029.75/29054.75/28993.5/29052.5 | 28993.5–29080.25 | none / bullish / forming | rejected_raid_reclaim, sell_side_raid_rejected, 13:15, 1m | bullish, 13:14, 29041.75, 1m | ESTABLISHING (active_path_causal_hypothesis_only) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 14:00 | 14:00 | 29169.75/29189.75/29123.0/29138.25 | 28986.25–29189.75 | bullish / None / active | rejected_raid_reclaim, sell_side_raid_rejected, 13:15, 1m | bullish, 13:14, 29041.75, 1m | AUTHORITY_UNKNOWN (campaign_draw_authority_unknown) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 14:45 | 14:45 | 29265.75/29268.0/29235.0/29255.25 | 28986.25–29270.75 | bullish / None / active | rejected_raid_reclaim, sell_side_raid_rejected, 13:15, 1m | bullish, 13:14, 29041.75, 1m | AUTHORITY_UNKNOWN (campaign_draw_authority_unknown) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 15:06 | 15:06 | 29259.75/29269.25/29251.75/29260.5 | 28986.25–29325.75 | bullish / None / active | rejected_raid_reclaim, sell_side_raid_rejected, 13:15, 1m | bullish, 13:14, 29041.75, 1m | AUTHORITY_UNKNOWN (campaign_draw_authority_unknown) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 15:30 | 15:30 | 29260.5/29271.25/29248.0/29262.5 | 28986.25–29325.75 | bullish / None / active | rejected_raid_reclaim, sell_side_raid_rejected, 15:17, 1m | bullish, 15:14, 29235.75, 1m | AUTHORITY_UNKNOWN (campaign_draw_authority_unknown) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 16:05 | 16:05 | 29289.0/29297.5/29282.75/29290.5 | 28986.25–29325.75 | bullish / None / active | rejected_raid_reclaim, sell_side_raid_rejected, 15:44, 5m | bullish, 15:43, 29234.25, 1m | TRANSFER_UNRESOLVED (narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 16:22 | 16:22 | 29240.5/29245.5/29229.5/29239.25 | 28986.25–29325.75 | none / bullish / forming | rejected_raid_reclaim, sell_side_raid_rejected, 16:21, 1m | bullish, 16:20, 29238.0, 1m | TRANSFER_UNRESOLVED (narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 16:29 | 16:29 | 29219.5/29223.25/29210.75/29214.25 | 28986.25–29325.75 | none / bullish / forming | rejected_raid_reclaim, sell_side_raid_rejected, 16:24, 3m | bullish, 16:23, 29238.0, 1m | TRANSFER_UNRESOLVED (narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 16:45 | 16:45 | 29253.75/29264.25/29248.75/29260.5 | 28986.25–29325.75 | none / bullish / forming | rejected_raid_reclaim, sell_side_raid_rejected, 16:24, 3m | bullish, 16:23, 29238.0, 1m | TRANSFER_UNRESOLVED (narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ | campaign_lifecycle_refused |
| 17:15 | 17:15 | 29179.75/29181.5/29147.0/29148.75 | 28986.25–29325.75 | bearish / None / active | rejected_raid_reclaim, buy_side_raid_rejected, 17:09, 1m | bullish, 17:08, 29195.0, 1m | TRANSFER_UNRESOLVED (narrative_control_transfer_not_yet_confirmed) | G7_load_bearing_present | campaign_lifecycle_refused |
| 17:40 | 17:40 | 29163.25/29169.75/29157.5/29159.25 | 28986.25–29325.75 | bearish / None / active | rejected_raid_reclaim, buy_side_raid_rejected, 17:09, 1m | bullish, 17:08, 29195.0, 1m | TRANSFER_UNRESOLVED (narrative_control_transfer_not_yet_confirmed) | G7_load_bearing_present | campaign_lifecycle_refused |
| 17:58 | 17:58 | 29192.5/29224.75/29190.5/29214.25 | 28986.25–29325.75 | bearish / None / contested | rejected_raid_reclaim, buy_side_raid_rejected, 17:09, 1m | bullish, 17:08, 29195.0, 1m | TRANSFER_UNRESOLVED (narrative_control_transfer_not_yet_confirmed) | G2_status_active | campaign_lifecycle_refused |

| CP | ordinal | record | (a) raw phase | (b) raw direction / action | (c) recorded guarded direction / action | (c) child playback | (d) tool/objective/plan | (e) first actual blocker | transfer-gate diagnostic (from prior recorded direction) |
|---|---|---|---|---|---|---|---|---|---|
| 13:18 | 0 | 20261023_092051_MNQ.json | transition | bearish / stand_down | bearish / stand_down | bearish / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (ESTABLISHING: active_path_causal_hypothesis_only) | G0b_directions_valid_and_differ |
| 13:30 | 19 | 20261023_093137_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | NOT_REPLAYED (playback scope is last-per-cutoff) | MISSING (not recorded) | recorded action stand_down; downstream blocker NOT_REPLAYED | NOT_REPLAYED |
| 13:30 | 20 | 20261023_093217_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (ESTABLISHING: active_path_causal_hypothesis_only) | G0b_directions_valid_and_differ |
| 14:00 | 61 | 20261023_100201_MNQ.json | retracement | bullish / stand_down | bullish / stand_down | bullish / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (AUTHORITY_UNKNOWN: campaign_draw_authority_unknown) | G0b_directions_valid_and_differ |
| 14:45 | 118 | 20261023_104644_MNQ.json | continuation | bullish / stand_down | bullish / stand_down | bullish / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (AUTHORITY_UNKNOWN: campaign_draw_authority_unknown) | G0b_directions_valid_and_differ |
| 15:06 | 143 | 20261023_110813_MNQ.json | retracement | bullish / stand_down | bullish / stand_down | bullish / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (AUTHORITY_UNKNOWN: campaign_draw_authority_unknown) | G0b_directions_valid_and_differ |
| 15:30 | 177 | 20261023_113219_MNQ.json | retracement | bullish / stand_down | bullish / stand_down | bullish / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (AUTHORITY_UNKNOWN: campaign_draw_authority_unknown) | G0b_directions_valid_and_differ |
| 16:05 | 223 | 20261023_120643_MNQ.json | transition | bullish / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (TRANSFER_UNRESOLVED: narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ |
| 16:22 | 248 | 20261023_122353_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | NOT_REPLAYED (playback scope is last-per-cutoff) | MISSING (not recorded) | recorded action stand_down; downstream blocker NOT_REPLAYED | NOT_REPLAYED |
| 16:22 | 249 | 20261023_122419_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (TRANSFER_UNRESOLVED: narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ |
| 16:29 | 259 | 20261023_123045_MNQ.json | transition | bearish / stand_down | conflicted / stand_down | NOT_REPLAYED (playback scope is last-per-cutoff) | MISSING (not recorded) | recorded action stand_down; downstream blocker NOT_REPLAYED | NOT_REPLAYED |
| 16:29 | 260 | 20261023_123126_MNQ.json | transition | bearish / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (TRANSFER_UNRESOLVED: narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ |
| 16:45 | 285 | 20261023_124704_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (TRANSFER_UNRESOLVED: narrative_control_transfer_not_yet_confirmed) | G0b_directions_valid_and_differ |
| 17:15 | 330 | 20261023_131633_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (TRANSFER_UNRESOLVED: narrative_control_transfer_not_yet_confirmed) | G7_load_bearing_present |
| 17:40 | 367 | 20261023_134136_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | NOT_REPLAYED (playback scope is last-per-cutoff) | MISSING (not recorded) | recorded action stand_down; downstream blocker NOT_REPLAYED | NOT_REPLAYED |
| 17:40 | 368 | 20261023_134202_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (TRANSFER_UNRESOLVED: narrative_control_transfer_not_yet_confirmed) | G7_load_bearing_present |
| 17:58 | 396 | 20261023_140006_MNQ.json | transition | conflicted / stand_down | conflicted / stand_down | conflicted / stand_down; campaign_lifecycle_refused | MISSING (not recorded) | campaign_lifecycle_refused (TRANSFER_UNRESOLVED: narrative_control_transfer_not_yet_confirmed) | G2_status_active |

| CP | EVIDENCE_SUPPORTED | AMBIGUOUS | CONTRADICTED | MISSING |
|---|---|---|---|---|
| 13:18 | 3 | 3 | 0 | 1 |
| 13:30 | 7 | 8 | 0 | 1 |
| 14:00 | 7 | 1 | 0 | 2 |
| 14:45 | 5 | 2 | 0 | 1 |
| 15:06 | 5 | 1 | 0 | 0 |
| 15:30 | 6 | 2 | 0 | 0 |
| 16:05 | 5 | 1 | 0 | 0 |
| 16:22 | 10 | 6 | 0 | 0 |
| 16:29 | 6 | 8 | 0 | 0 |
| 16:45 | 4 | 3 | 0 | 2 |
| 17:15 | 3 | 6 | 0 | 0 |
| 17:40 | 12 | 5 | 0 | 0 |
| 17:58 | 6 | 5 | 0 | 2 |

"""Narrative transport acceptance case; not an instruction to enter a trade.

The existing constructed tape establishes a genuine healthy candidate, then
an unresolved local failure. The controlled Brain describes bearish delivery
and explicitly stands down. Its read must remain available to the next Brain
as observational context while mechanical entry authority remains withheld.
"""
from pathlib import Path
import os,json,copy
import pytest
import test_campaign_draw_temporal_authority as TA
import test_reversal_foundation_proof_closure as RF
import test_stance_history_hygiene as H
import test_campaign_leg_scope_labels as L

R=Path(os.environ.get('OWNER_NARRATIVE_EVIDENCE_DIR',str(Path(__file__).resolve().parent)))
STORY='AUDIT CONTROL: price rejected buy-side liquidity at 29500 and broke the protected local low at 29457. Bearish delivery challenges the prior bullish leg; campaign transfer remains unproved, and no entry is proposed.'

@pytest.mark.parametrize('ecu',[False,True],ids=['non-ecu','ecu'])
def test_authored_market_read_reaches_next_brain_without_granting_participation(tmp_path,monkeypatch,ecu):
    def reply(out,ordinal,payload):
        if ordinal<4:return out
        return {**out,'narrative_direction':'bearish','narrative_phase':'transition',
                'market_story':STORY,'dominant_reasoning':STORY,
                'current_action':'stand_down','objective_id':None,'invalidation_id':None,
                'allowed_direction':'none','forbidden_direction':None,
                'invalidation_level':None,'active_draw':'none',
                'recommended_playbook_family':'none','recommended_tool_family':['none']}
    cycle,calls=H._lane(tmp_path,monkeypatch,ecu,mutator=reply)
    H._brain_scan(cycle,calls,RF.TAPE_1M)
    positive,_=H._brain_scan(cycle,calls,TA.LATER)
    assert RF._produce_candidate(positive).direction=='bullish'
    rows=list(TA.LATER);records=[]
    for bar in L.SCENARIOS['C2'][:3]:
        rows.append(bar);scan,payload=H._brain_scan(cycle,calls,rows)
        records.append((scan,payload))
    held=records[1][0]
    assert held['brain_block']['narrative_continuity']['control_state']=='developing_transfer'
    assert held['brain_block']['output']['current_action']=='stand_down'
    assert L._candidate(held)=='campaign_lifecycle_refused'
    next_payload=records[2][1]
    prior=(next_payload.get('narrative_continuity') or {}).get('prior_thesis') or {}
    (R/('NARRATIVE_CONTEXT_CURRENT_'+('ecu' if ecu else 'non_ecu')+'.json')).write_text(json.dumps(dict(controlled_authored_story=STORY,held_story=held['brain_block']['output']['market_story'],next_authority_prior_story=prior.get('market_story'),next_market_narrative_history=next_payload.get('market_narrative_history'),next_control=(next_payload.get('narrative_continuity') or {}).get('control_state'),candidate_refusal=L._candidate(held)),indent=2))
    # Desired additive, observational-only context. Existing authority fields
    # must remain unchanged; this field must never supply positive permission.
    authored=((next_payload.get('market_narrative_history') or {}).get('last') or {})
    assert authored.get('market_story')==STORY,'Actual next Brain receives the held template but lacks the separate authored market read'
    assert authored.get('narrative_direction')=='bearish'
    assert authored.get('authority')=='OBSERVATIONAL_ONLY'

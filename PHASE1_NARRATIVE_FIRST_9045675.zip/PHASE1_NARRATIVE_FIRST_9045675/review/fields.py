"""Recover authored fields from each call's ORIGINAL response (full dict or truncated sorted-JSON head)."""
import gzip, json, re, sys
FIELDS = ("narrative_direction", "narrative_phase", "current_action", "market_story", "dominant_reasoning",
          "delivery_interpretation", "liquidity_interpretation", "protected_high_interpretation",
          "protected_low_interpretation", "thesis_health")

def recover(resp):
    if not isinstance(resp, dict):
        return {}, "none"
    if not resp.get("_truncated"):
        return {k: resp.get(k) for k in FIELDS}, "full"
    head, out = resp.get("_head") or "", {}
    for k in FIELDS:
        m = re.search(r'"%s": ("(?:[^"\\]|\\.)*")' % k, head)
        if m:
            out[k] = json.loads(m.group(1))
    return out, "head"

def load(path):
    return json.loads(gzip.decompress(open(path, "rb").read()))

if __name__ == "__main__":
    x = load(sys.argv[1]); stats = {}
    for c in x["calls"]:
        f, how = recover(c.get("original_response"))
        for k in FIELDS:
            stats.setdefault(k, 0); stats[k] += int(k in f and f[k] not in (None, ""))
        stats.setdefault("_" + how, 0); stats["_" + how] += 1
    print(stats)

"""Mechanical, causal fact checks of each authored read against the settled tape (no grading by outcome)."""
import json, re, sys, collections
sys.path.insert(0, ".")
from fields import load, recover
EXTRACT, FIXTURE = sys.argv[1], sys.argv[2]
x = load(EXTRACT)
tape = sorted(json.load(open(FIXTURE))["tape"], key=lambda b: b["timestamp"])
NUM = re.compile(r"(?<![\d.])(2[89]\d{3}(?:\.\d{1,2})?)(?![\d.])")
TEXT = ("market_story", "dominant_reasoning", "delivery_interpretation", "liquidity_interpretation",
        "protected_high_interpretation", "protected_low_interpretation")

def settled(cut):   # bars whose minute closed at or before the scan cutoff (cutoff = last 1m bar open)
    return [b for b in tape if b["timestamp"] <= cut]

def buckets(bars, n):
    out = collections.OrderedDict()
    for b in bars:
        t = b["timestamp"]; mm = int(t[14:16]); key = t[:14] + "%02d" % (mm - mm % n)
        out.setdefault(key, []).append(b)
    return [(k, v) for k, v in out.items() if len(v) == n]

def classify(level, cut, ctx_text):
    before = settled(cut); after = [b for b in tape if b["timestamp"] > cut]
    hit = lambda bars: any(abs(level - b[f]) <= 0.25 for b in bars for f in ("open", "high", "low", "close"))
    if hit(before): return "SUPPORTED_PRINTED"
    if ("%g" % level) in ctx_text or ("%.2f" % level) in ctx_text: return "SUPPORTED_INPUT_CONTEXT"
    if abs(level * 4 - round(level * 4)) > 1e-6:
        return "AMBIGUOUS_DERIVED_OFF_TICK_LEVEL"        # e.g. a computed midpoint/equilibrium
    soon = [b for b in after if b["timestamp"] <= _plus(cut, 3)]
    if hit(soon): return "AMBIGUOUS_FORMING_BAR_OR_QUOTE"  # the Brain also sees the forming bar/quote
    if hit(after): return "AMBIGUOUS_NOT_SETTLED_IN_SESSION_TAPE"
    return "AMBIGUOUS_NOT_IN_EXTRACT"

def _plus(cut, minutes):
    from datetime import datetime, timedelta
    return (datetime.fromisoformat(cut) + timedelta(minutes=minutes)).isoformat()

rows, totals = [], collections.Counter()
for c in x["calls"]:
    f, _ = recover(c.get("original_response"))
    rec = c.get("record") or {}
    if not f.get("market_story"):
        continue
    cut = rec.get("timestamp")
    ctx = json.dumps(c.get("input_context"), default=str)
    levels = sorted({float(m) for k in TEXT for m in NUM.findall(str(f.get(k) or ""))})
    cls = {lv: classify(lv, cut, ctx) for lv in levels}
    for v in cls.values(): totals[v] += 1
    five = buckets([b for b in settled(cut) if b["timestamp"] >= "2026-10-23T13:30"], 5)
    move30 = (five[-1][1][-1]["close"] - five[-7][1][0]["open"]) if len(five) >= 7 else None
    d = f.get("narrative_direction")
    agree = (None if move30 is None or d not in ("bullish", "bearish") else
             ("ALIGNED" if (move30 > 0) == (d == "bullish") else "OPPOSED"))
    if agree: totals["direction_vs_30m_" + agree] += 1
    rows.append({"file": c["file"], "cutoff": cut, "dir": d, "phase": f.get("narrative_phase"),
                 "action": f.get("current_action"), "levels": {"%g" % k: v for k, v in cls.items()},
                 "move30_5m": move30, "dir_vs_30m": agree})
json.dump({"totals": totals, "rows": rows}, open("checks.json", "w"), indent=0)
print(dict(totals)); print("calls checked", len(rows))
for r in rows:
    bad = [k for k, v in r["levels"].items() if v.startswith("CONTRADICTED")]
    if bad: print(r["file"], r["cutoff"][11:16], r["dir"], bad)

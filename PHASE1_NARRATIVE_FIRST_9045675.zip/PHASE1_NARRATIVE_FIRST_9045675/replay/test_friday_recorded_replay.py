"""Replay Friday's RECORDED original responses through the actual scan cycle (offline, no model call).

Tape: the archived PROD-20261023-C1 December-contract 1m tape (repository fixture at f6e4013, same
archive). Responses: each call's original `llm_raw_response` fields recovered from the narrative
extract (sha256 86cd5fc9...); fields the extractor truncated are left at the schema-valid
stand-down defaults (every recorded primary response authored stand_down). The 15
llm_failed_fallback calls are replayed as provider failures. Nothing is invented: no new
judgment is authored and no current model is called.

Checks, for every consecutive pair of replayed calls (A then B): B's actual transported input
carries A's authored read in market_narrative_history.last (or an honest UNKNOWN when A was
degraded), separately from the guarded prior_thesis story.
"""
import copy
import gzip
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

EXTRACT = Path(os.environ["NARR_EXTRACT"])
FIXTURE = Path(os.environ["FRIDAY_TAPE_FIXTURE"])
OUT = Path(os.environ["REPLAY_OUT"])
sys.path.insert(0, os.environ["REVIEW_TOOLS"])
from fields import recover  # noqa: E402

CONTRACT = "CON.F.US.MNQ.Z26"


def _recorded():
    x = json.loads(gzip.decompress(EXTRACT.read_bytes()))
    by_cutoff = {}
    for c in x["calls"]:
        rec = c.get("record") or {}
        cut = rec.get("timestamp")
        fields, how = recover(c.get("original_response"))
        by_cutoff[cut] = {"file": c["file"], "source": rec.get("source"), "fields": fields,
                          "recovery": how}          # last call at a cutoff wins
    return x["archive_sha256"], by_cutoff


@pytest.mark.parametrize("ecu", [False, True], ids=["non-ecu", "ecu"])
def test_friday_recorded_reads_survive_holds_into_next_input(tmp_path, monkeypatch, ecu):
    import ai_brain.ecu as ECU
    import ai_brain.narrative_brain as NB
    from ai_brain import production_model as PM
    from ai_brain.brain_schema import empty_brain_output
    from ai_brain.stance_memory import StanceMemory
    from broker.topstepx_slippage import QuoteCapture
    from live_scan.production_scan_cycle import ProductionScanCycle

    archive_sha, recorded = _recorded()
    tape = sorted(json.loads(FIXTURE.read_text())["tape"], key=lambda b: b["timestamp"])
    for b in tape:
        b["contract"] = CONTRACT
    for key in ("OCCURRENCE_LEDGER_DIR", "AI_BRAIN_DIR", "AI_RETRIEVAL_DIR", "REPLAY_SESSIONS_DIR"):
        monkeypatch.setenv(key, str(tmp_path / key))
    monkeypatch.setenv("BRAIN_ECU_MODE", "true" if ecu else "false")
    monkeypatch.setenv("AI_BRAIN_ENABLED", "false")
    monkeypatch.setenv("AI_BRAIN_LLM", "false")
    state = {"close": tape[0]["close"]}

    def quote():
        return QuoteCapture(captured_at=datetime.now(timezone.utc), best_bid=state["close"],
                            best_ask=state["close"] + 0.25, last_trade=state["close"],
                            contract_id=CONTRACT, market_data_age_seconds=0.25)
    cycle = ProductionScanCycle(symbol="MNQ", contract_id=CONTRACT,
                                session_id="FRIDAY-RECORDED-REPLAY", quote_provider=quote)

    sent, current = [], {}

    def transport(payload, repair=None):
        sent.append({"cutoff": current.get("cut"), "payload": copy.deepcopy(payload)})
        call = current.get("call")
        if call is None or call["source"] != "llm" or not call["fields"].get("market_story"):
            return {"ok": False, "error": "recorded_call_degraded", "parsed": None,
                    "model": None, "provider_request_attempted": False}
        out = empty_brain_output()
        out.update({k: v for k, v in call["fields"].items() if v not in (None, "")})
        out.update(current_action="stand_down", allowed_direction="none",
                   objective_id=None, invalidation_id=None, invalidation_level=None)
        return {"ok": True, "parsed": out, "model": PM.PRODUCTION_MODEL,
                "prompt": "recorded replay", "user_content": "recorded replay",
                "raw_response": copy.deepcopy(out), "usage": {}}

    def scan(cut, brain):
        rows = [b for b in tape if b["timestamp"] <= cut][-300:]
        state["close"] = rows[-1]["close"]
        now = datetime.fromisoformat(cut) + timedelta(minutes=1)
        return cycle.scan(rows, now=now, invoke_brain=brain)

    cutoffs = sorted(c for c in recorded if c)
    warm = (datetime.fromisoformat(cutoffs[0]) - timedelta(minutes=1)).isoformat()
    scan(warm, False)
    memory = StanceMemory(persist=False)
    monkeypatch.setattr(ECU, "_stance", lambda: memory)
    monkeypatch.setattr(NB, "persist_brain_call", lambda *a, **k: None)
    monkeypatch.setattr(NB, "_call_llm", transport)
    monkeypatch.setenv("AI_BRAIN_ENABLED", "true")
    monkeypatch.setenv("AI_BRAIN_LLM", "true")

    timeline = []
    minute = datetime.fromisoformat(cutoffs[0])
    end = datetime.fromisoformat(cutoffs[-1])
    while minute <= end:
        cut = minute.isoformat()
        call = recorded.get(cut)
        current.update(cut=cut, call=call)
        before = len(sent)
        result = scan(cut, call is not None)
        if call is not None:
            block = result.get("brain_block") or {}
            if ecu and isinstance(block.get("brain_block"), dict):
                block = block["brain_block"]
            read = (block or {}).get("authored_market_read") or {}
            timeline.append({"cutoff": cut, "file": call["file"], "recorded_source": call["source"],
                             "provider_calls": len(sent) - before,
                             "captured_status": read.get("status"),
                             "captured_story": read.get("market_story"),
                             "recorded_story": call["fields"].get("market_story"),
                             "held_story": ((block or {}).get("output") or {}).get("market_story")})
        minute += timedelta(minutes=1)

    # Pair each provider input with the read captured on the previous replayed call.
    by_cut = {s["cutoff"]: s["payload"] for s in sent}
    pairs, survived, unknown_ok, mismatches = 0, 0, 0, []
    latest_read = None   # (cutoff, story) of the most recent AVAILABLE capture so far
    for prev, nxt in zip(timeline, timeline[1:]):
        if prev["captured_status"] == "AVAILABLE":
            latest_read = (prev["cutoff"], prev["recorded_story"])
        payload = by_cut.get(nxt["cutoff"])
        if payload is None:
            continue
        pairs += 1
        last = (payload.get("market_narrative_history") or {}).get("last") or {}
        if prev["captured_status"] == "AVAILABLE":
            if (last.get("market_story") == prev["recorded_story"]
                    and last.get("authority") == "OBSERVATIONAL_ONLY"):
                survived += 1
            else:
                mismatches.append({"prev": prev["cutoff"], "next": nxt["cutoff"],
                                   "got": last.get("status"), "reason": last.get("reason")})
        elif last.get("status") == "UNKNOWN":
            unknown_ok += 1
        elif (latest_read is not None and last.get("market_story") == latest_read[1]
              and last.get("recorded_at_cutoff") is not None
              and last["recorded_at_cutoff"] < prev["cutoff"]):
            # A degraded call records no cognition; the next input shows the last
            # real read honestly dated at its own earlier cutoff, never as the
            # degraded call's read.
            unknown_ok += 1
        else:
            mismatches.append({"prev": prev["cutoff"], "next": nxt["cutoff"], "degraded_prev": True,
                               "got": last.get("status")})
    held = sum(1 for t in timeline if t["captured_status"] == "AVAILABLE"
               and t["held_story"] != t["captured_story"])
    summary = {"lane": "ecu" if ecu else "non-ecu", "archive_sha256": archive_sha,
               "replayed_calls": len(timeline),
               "captured_available": sum(t["captured_status"] == "AVAILABLE" for t in timeline),
               "captured_unknown": sum(t["captured_status"] != "AVAILABLE" for t in timeline),
               "held_rewrites_in_replay": held, "next_input_pairs": pairs,
               "authored_read_survived_into_next_input": survived,
               "degraded_previous_handled_honestly": unknown_ok, "mismatches": mismatches[:20],
               "mismatch_count": len(mismatches)}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / f"REPLAY_{summary['lane']}.json").write_text(json.dumps(
        {"summary": summary, "timeline": timeline}, indent=1, default=str))
    examples = [s for s in sent if s["cutoff"] in ("2026-10-23T16:23:00+00:00",
                                                   "2026-10-23T16:30:00+00:00")]
    (OUT / f"REPLAY_EXCERPTS_{summary['lane']}.json").write_text(json.dumps(
        [{"cutoff": e["cutoff"],
          "market_narrative_history.last": (e["payload"].get("market_narrative_history") or {}).get("last"),
          "narrative_continuity.prior_thesis.market_story":
              ((e["payload"].get("narrative_continuity") or {}).get("prior_thesis") or {}).get("market_story")}
         for e in examples], indent=1, default=str))
    print(json.dumps(summary, indent=1))
    assert summary["mismatch_count"] == 0, summary

"""Independent actual-consumer controls; no production changes or model calls."""
import copy, json
from pathlib import Path
import pytest
import test_market_narrative_first as P

@pytest.mark.parametrize('ecu',[False,True],ids=['non-ecu','ecu'])
@pytest.mark.parametrize('case',['healthy','foreign_contract','foreign_custody'])
def test_read_row_identity_at_next_consumer(tmp_path,monkeypatch,ecu,case):
    def poison(cycle):
        row=cycle.stance_memory._buf[-1]
        read=row['authored_market_read']
        if case=='foreign_contract':
            read['provenance']['contract_id']='CON.F.US.MES.Z26'
        if case=='foreign_custody':
            assert read['provenance']['history_lineage']['custody']==row['history_lineage']['custody']
            read['provenance']['history_lineage']['custody']='different-producer-custody'
    cycle,positive,pp,records=P._run(tmp_path,monkeypatch,ecu,P._bearish(),poison=poison)
    held,payload=records[2]
    last=payload['market_narrative_history']['last']
    evidence={'case':case,'ecu':ecu,'next_read':last,
              'candidate':P.L._candidate(held),'control_state':payload['narrative_continuity']['control_state']}
    out=Path(__file__).parent/f'PROVENANCE_{case}_{ecu}.json'
    out.write_text(json.dumps(evidence,indent=2,default=str),encoding='utf-8')
    assert P.L._candidate(held)=='campaign_lifecycle_refused'
    if case=='healthy':
        assert last['status']=='AVAILABLE' and last['market_story']==P.STORY
    else:
        assert last['status']=='UNKNOWN', 'A read with mismatched producer provenance reached actual next Brain as AVAILABLE'

import os, sys, json, tempfile
root = tempfile.mkdtemp()
for k in ("OCCURRENCE_LEDGER_DIR","AI_BRAIN_DIR","AI_RETRIEVAL_DIR","REPLAY_SESSIONS_DIR"):
    os.environ[k] = os.path.join(root, k)
import test_reversal_foundation_proof_closure as RF
import test_campaign_draw_temporal_authority as TA
import test_campaign_leg_scope_labels as L
from live_scan.production_scan_cycle import ProductionScanCycle
from market_data import local_authority as LA
prof = getattr(LA, sys.argv[1]) if len(sys.argv) > 1 else LA.OFFLINE_TEST_PROFILE_V1
c = ProductionScanCycle(symbol="MNQ", contract_id=RF.CONTRACT, session_id=RF.SESSION_ID,
                        quote_provider=RF._quote, local_authority_profile=prof)
RF._scan_prefix(c, len(RF.TAPE_1M) - 5)
rows = list(TA.LATER)
c.scan(rows, now=RF._now_for(rows), invoke_brain=False)
for bar in L.SCENARIOS["C2"]:
    rows.append(bar)
    snap = c.scan(rows, now=RF._now_for(rows), invoke_brain=False)["snapshot"]
    p = snap["active_path_state"]; d = c.local_authority.diagnostics[-1] if c.local_authority.diagnostics else {}
    li = p.get("last_invalidated") or {}
    print(bar["timestamp"][11:16], p.get("owner"), p.get("status"), (p.get("origin") or {}).get("proof_family"),
          (p.get("origin") or {}).get("source_bar_time","")[11:16], "fail", li.get("owner"), (li.get("source_bar_time") or "")[11:16],
          json.dumps(d.get("events") if d.get("cutoff") == LA._instant(snap["timestamp"]) else "-")[:300])
print("--- packet adjudication at C2 cutoffs (DEFAULT cycle path, isolated ledger)")
from ai_brain.narrative_continuity import build_narrative_continuity
root2 = tempfile.mkdtemp()   # a separate ledger: two cycles never share runtime state
for k in ("OCCURRENCE_LEDGER_DIR","AI_BRAIN_DIR","AI_RETRIEVAL_DIR","REPLAY_SESSIONS_DIR"):
    os.environ[k] = os.path.join(root2, k)
c2 = ProductionScanCycle(symbol="MNQ", contract_id=RF.CONTRACT, session_id=RF.SESSION_ID + "-D", quote_provider=RF._quote)
RF._scan_prefix(c2, len(RF.TAPE_1M) - 5)
rows = list(TA.LATER); c2.scan(rows, now=RF._now_for(rows), invoke_brain=False)
for bar in L.SCENARIOS["C2"]:
    rows.append(bar)
    snap = c2.scan(rows, now=RF._now_for(rows), invoke_brain=False)["snapshot"]
    p = snap["active_path_state"]; stamp = LA._instant(snap["timestamp"])
    pk, why = LA.delivery_change_packet(path=p, facts=snap.get("campaign_premise_shadow"), ledger_rows=c2._current_chronology_occurrences(), settled_1m=rows[-300:], cutoff=stamp, contract_id=RF.CONTRACT, market_session=p.get("session"), history_revision=c2._history.revision)
    rs, rwhy = LA.retained_support_adoption(path=p, facts=snap.get("campaign_premise_shadow"), ledger_rows=c2._current_chronology_occurrences(), cutoff=stamp, contract_id=RF.CONTRACT, market_session=p.get("session"), history_revision=c2._history.revision)
    lives = [(l.get("source_tf"), l.get("side"), l.get("level"), (l.get("certificate") or {}).get("status"), l.get("eligible_for_new_selection")) for l in (snap.get("campaign_premise_shadow") or {}).get("lives") or []]
    print(bar["timestamp"][11:16], p.get("owner"), "packet:", why or pk["market_proof_id"][:16], "| retained:", rwhy or rs["adoption_id"][:16], "| lb:", (p.get("load_bearing_structure") or {}).get("level"), lives)

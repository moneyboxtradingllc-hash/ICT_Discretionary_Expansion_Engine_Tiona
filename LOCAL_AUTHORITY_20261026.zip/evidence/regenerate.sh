#!/bin/bash
# Regenerate the evidence tables against a frozen tree: regenerate.sh <tree> <outdir>
S=[scratch]
T=$1; O=$2; E=$(cd "$(dirname "$0")" && pwd)
run() { (cd "$T" && env -i PATH=$S/g5/venv/bin:/usr/bin:/bin HOME=$S/g5/rt LANG=C.UTF-8 TZ=UTC PYTHONPATH=src:tests \
  PYTHONDONTWRITEBYTECODE=1 HTTPS_PROXY=http://127.0.0.1:9 HTTP_PROXY=http://127.0.0.1:9 EXECUTION_ENABLED=false \
  ALLOW_PAPER_ORDERS=false AI_BRAIN_ENABLED=false AI_BRAIN_LLM=false BRAIN_ECU_MODE=false "$@"); }
run python $E/m2_walk.py 16:10 16:50 > $O/walk_delivery_change_real_1610_1650.txt 2>&1 &
run LA_PROFILE=OFFLINE_RETAINED_SUPPORT_TEST_PROFILE_V1 python $E/m2_walk.py 17:05 17:45 > $O/walk_retained_support_real_1705_1745.txt 2>&1 &
run python $E/m2_events.py 09:30 17:58 real > $O/events_full_session_real.txt 2>&1 &
run python $E/m2_events.py 09:30 17:58 mirror > $O/events_full_session_mirror.txt 2>&1 &
run python $E/m2_c2.py > $O/c2_adjudication.txt 2>&1 &
wait

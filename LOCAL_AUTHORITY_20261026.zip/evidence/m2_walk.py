import copy, json, os, sys, tempfile
from datetime import datetime, timedelta
root = tempfile.mkdtemp()
for k in ("OCCURRENCE_LEDGER_DIR","AI_BRAIN_DIR","AI_RETRIEVAL_DIR","REPLAY_SESSIONS_DIR"):
    os.environ[k] = os.path.join(root, k)
import test_protected_structure_continuity as P
from ai_brain.narrative_continuity import _transfer_proof
from live_scan.production_scan_cycle import ProductionScanCycle
from market_data import local_authority as LA
start, end = sys.argv[1], sys.argv[2]
cyc = {"default": ProductionScanCycle(symbol="MNQ", contract_id=P.C, session_id="D"),
       "offline": ProductionScanCycle(symbol="MNQ", contract_id=P.C, session_id="O",
                                      local_authority_profile=getattr(LA, os.environ.get("LA_PROFILE", "OFFLINE_TEST_PROFILE_V1")))}
for hm in P._minutes(start, end):
    cut = P._cut(hm); bars = [b for b in P.TAPE if b["timestamp"] <= cut][-300:]
    line = [hm]
    for name, c in cyc.items():
        scan = c.scan(bars, now=datetime.fromisoformat(cut)+timedelta(minutes=1), invoke_brain=False)
        snap = scan["snapshot"]; path = snap["active_path_state"]
        o = path.get("origin") or {}; li = path.get("last_invalidated") or {}
        lb = path.get("load_bearing_structure") or {}
        route = LA.authenticated_local_route(path, snap)
        tp = None
        if path.get("owner") in ("bullish","bearish"):
            frm = {"bullish":"bearish","bearish":"bullish"}[path["owner"]]
            tp = _transfer_proof(path, frm, path["owner"], snapshot=snap)
        line.append(f"{name}:{path.get('owner')}/{path.get('status')}/{o.get('proof_family')}"
                    f"@{(o.get('source_bar_time') or '')[11:16]} fail={li.get('owner')}@{(li.get('source_bar_time') or '')[11:16]}"
                    f" lb={lb.get('level')}{'*' if lb.get('adoption') else ''} route={route} tp={'Y' if tp else '-'}")
        if name == "offline" and c.local_authority.diagnostics:
            ev = c.local_authority.diagnostics[-1]
            if ev.get("cutoff") == LA._instant(snap.get("timestamp")):
                line.append("EV=" + json.dumps(ev["events"]))
    print(" | ".join(line))

import json, os, sys, tempfile
from datetime import datetime, timedelta
root = tempfile.mkdtemp()
for k in ("OCCURRENCE_LEDGER_DIR","AI_BRAIN_DIR","AI_RETRIEVAL_DIR","REPLAY_SESSIONS_DIR"):
    os.environ[k] = os.path.join(root, k)
import test_protected_structure_continuity as P
from live_scan.production_scan_cycle import ProductionScanCycle
from market_data import local_authority as LA
import local_authority_loop as H
tape = P.TAPE if sys.argv[3] == "real" else H.mirrored_tape(P.TAPE)
c = ProductionScanCycle(symbol="MNQ", contract_id=P.C, session_id="O",
                        local_authority_profile=getattr(LA, os.environ.get("LA_PROFILE", "OFFLINE_TEST_PROFILE_V1")))
last = None
for hm in P._minutes(sys.argv[1], sys.argv[2]):
    cut = P._cut(hm); bars = [b for b in tape if b["timestamp"] <= cut][-300:]
    snap = c.scan(bars, now=datetime.fromisoformat(cut)+timedelta(minutes=1), invoke_brain=False)["snapshot"]
    d = c.local_authority.diagnostics[-1] if c.local_authority.diagnostics else {}
    evs = [e for e in d.get("events", []) if d.get("cutoff") == LA._instant(snap["timestamp"])]
    key = json.dumps(evs, sort_keys=True)
    path = snap["active_path_state"]
    if evs and key != last:
        print(hm, path.get("owner"), (path.get("origin") or {}).get("proof_family"), key[:400])
    last = key

#!/bin/bash
# Stage5 offline runner: <clone> <log> <cmd...>; allowlisted env (env -i), no .env, isolated runtime roots, disarmed.
S=[scratch]
C=$1; LOG=$2; shift 2
RT=$(mktemp -d $S/g5/rt/rt.XXXX)
cd "$C" && env -i PATH=[scratch]/g5/venv/bin:/usr/local/bin:/usr/bin:/bin HOME=$RT/home LANG=C.UTF-8 TZ=UTC PYTHONPATH=src:tests PYTHONIOENCODING=utf-8 PYTHONDONTWRITEBYTECODE=1 \
  EXECUTION_ENABLED=false ALLOW_PAPER_ORDERS=false AI_BRAIN_LLM=false TWO_BRAIN_MODE=off \
  OCCURRENCE_LEDGER_DIR=$RT/occurrence_ledger_dir AI_BRAIN_DIR=$RT/ai_brain_dir REPLAY_SESSIONS_DIR=$RT/replay_sessions_dir AI_RETRIEVAL_DIR=$RT/ai_retrieval_dir \
  PERFORMANCE_TABLES_DIR=$RT/performance_tables_dir HTF_MEMORY_DIR=$RT/htf_memory_dir GLOBAL_MEMORY_DIR=$RT/global_memory_dir \
  HTTPS_PROXY=http://127.0.0.1:9 HTTP_PROXY=http://127.0.0.1:9 NO_PROXY= \
  "$@" > "$LOG" 2>&1; rc=$?; echo "exit $rc -> $(tail -1 $LOG)"; exit $rc

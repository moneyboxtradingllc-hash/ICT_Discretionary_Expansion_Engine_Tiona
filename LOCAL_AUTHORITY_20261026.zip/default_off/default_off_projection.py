"""Default-off invariance projection: run in a repo (cwd), print per-cutoff digests.

usage: python default_off_projection.py <tape: real|mirror> <out.json>
A DEFAULT ProductionScanCycle (no profile argument at all -- the parent has
none) walks the archived Friday tape; per settled cutoff it digests the
decision-bearing published surfaces. Random custody lineage (uuid), the ids/digests derived from it are scrubbed
and catalog rows (ordered by such an id) are compared in canonical order.
"""
import hashlib, json, os, sys, tempfile
from datetime import datetime, timedelta

root = tempfile.mkdtemp()
for k in ("OCCURRENCE_LEDGER_DIR", "AI_BRAIN_DIR", "AI_RETRIEVAL_DIR", "REPLAY_SESSIONS_DIR"):
    os.environ[k] = os.path.join(root, k)
import test_protected_structure_continuity as P
from ai_brain.narrative_continuity import build_narrative_continuity
from live_scan.production_scan_cycle import ProductionScanCycle

SCRUB = {"custody_lineage", "lineage", "digest", "premise_candidate_id"}
SURFACES = ("active_path_state", "campaign_premise_shadow", "campaign_premise_catalog",
            "campaign_scope_custody", "campaign_scope_custody_shadow", "campaign_lifecycle",
            "protected_swings", "reversal_formation_view", "derived_state")


def scrub(value):
    if isinstance(value, dict):
        out = {k: scrub(v) for k, v in value.items() if k not in SCRUB}
        if isinstance(out.get("rows"), list):
            # Catalog rows are ordered by a lineage-derived id; order canonically.
            out["rows"] = sorted(out["rows"], key=lambda r: json.dumps(r, sort_keys=True, default=str))
        return out
    if isinstance(value, list):
        return [scrub(v) for v in value]
    return value


def digest(value):
    return hashlib.sha256(json.dumps(scrub(value), sort_keys=True, default=str).encode()).hexdigest()[:16]


def mirrored(tape, axis=58_500.0):
    return [{**b, "open": axis - b["open"], "high": axis - b["low"],
             "low": axis - b["high"], "close": axis - b["close"]} for b in tape]


tape = P.TAPE if sys.argv[1] == "real" else mirrored(P.TAPE)
cycle = ProductionScanCycle(symbol="MNQ", contract_id=P.C, session_id="DEFAULT-OFF")
out = {}
for hm in P._minutes("09:30", "17:58"):
    cut = P._cut(hm)
    bars = [b for b in tape if b["timestamp"] <= cut][-300:]
    snap = cycle.scan(bars, now=datetime.fromisoformat(cut) + timedelta(minutes=1),
                      invoke_brain=False)["snapshot"]
    row = {k: digest(snap.get(k)) for k in SURFACES}
    row["narrative_continuity"] = digest(build_narrative_continuity(snap, {}))
    out[hm] = row
json.dump(out, open(sys.argv[2], "w"), indent=0, sort_keys=True)
print(len(out), digest(out))

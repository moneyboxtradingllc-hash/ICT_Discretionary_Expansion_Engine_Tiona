"""Activated break-one-invariant mutants for LOCAL-AUTHORITY-20261026.

Usage: python mutants.py <frozen_repo> <workdir> <outfile.json>
Each mutant copies the frozen tree, applies ONE source edit, runs the named
tests, and must turn at least one of them red. The unmutated copy must pass.
"""
import json
import os
import shutil
import subprocess
import sys

S = "[scratch]"
LA = "src/market_data/local_authority.py"
NC = "src/ai_brain/narrative_continuity.py"
CS = "src/market_data/campaign_scope.py"
CPA = "src/broker/conditional_plan_authority.py"
AP = "src/market_state/active_path.py"
DC = "tests/test_local_authority_delivery_change.py"
MO = "tests/test_local_authority_member_order.py"
CO = "tests/test_local_authority_composition.py"

MUTANTS = [
    ("M01_profile_accepts_lookalike", LA,
     "    if not any(value is profile for profile in _OFFLINE_PROFILES):",
     "    if not any(value == profile for profile in _OFFLINE_PROFILES):",
     [f"{DC}::test_component_profile_is_an_exact_object_and_disabled_otherwise",
      f"{MO}::test_only_the_exact_offline_profile_object_enables_anything"]),
    ("M02_route_ignores_current_issue", LA,
     "    issued, _ = current_issue(snapshot)\n    if not issued or issued.get(\"cutoff\") != _instant(snapshot.get(\"timestamp\")):\n        return None",
     "    issued = {**local_refinements(path), \"cutoff\": _instant(snapshot.get(\"timestamp\"))}",
     [f"{DC}::test_copied_revoked_and_duplicate_authority",
      f"{DC}::test_history_revision_retires_the_issue"]),
    ("M03_incumbency_launders_revoked_route", NC,
     "                                or authenticated_local_route(path, snap) is None)",
     "                                )",
     [f"{DC}::test_copied_revoked_and_duplicate_authority"]),
    ("M04_no_scoped_exclusion", CS,
     "    if any(local_refinements(path).values()):\n        return None, LOCAL_ONLY_SCOPE_REASON",
     "    pass",
     [f"{DC}::test_scoped_proof_excludes_both_local_bases_even_with_a_b3_passing_raid"]),
    ("M05_adopts_beside_a_bound_campaign", LA,
     "        unbound = bool(custody is not None and getattr(custody, \"_campaign\", True) is None\n                       and getattr(custody, \"_pending\", True) is None)",
     "        unbound = True",
     [f"{DC}::test_a_bound_campaign_is_never_shadowed_by_a_local_refinement"]),
    ("M06_body_run_start_unproved", LA,
     "    if first == 0:\n        return {**base, \"status\": \"UNAVAILABLE\", \"reason\": \"run_start_not_covered\"}",
     "    pass",
     [f"{DC}::test_body_open_break_on_campaign_timeframes"]),
    ("M07_gap_inside_run_ignored", LA,
     "        if _dt(buckets[first][\"open_time\"]) - _dt(buckets[first - 1][\"open_time\"]) != step:\n            break",
     "        pass",
     [f"{DC}::test_each_broken_relation_refuses_the_delivery_change"]),
    ("M08_confirmation_before_failure_admitted", LA,
     "            if not failure_at < completed:",
     "            if False:",
     [f"{DC}::test_each_broken_relation_refuses_the_delivery_change"]),
    ("M09_ladder_credit_inherited", AP,
     "        self.ladder, self.adverse_replacements, self.ambiguous_invalidations = [], [], []\n        return True",
     "        self.ladder = [float(load_bearing.get(\"level\"))]\n        self.adverse_replacements, self.ambiguous_invalidations = [], []\n        return True",
     [f"{DC}::test_support_is_the_existing_life_with_zero_ladder_credit"]),
    ("M10_no_revalidation_of_adopted_generation", LA,
     "            if packet is None or packet[\"market_proof_id\"] != (cited or {}).get(\"market_proof_id\"):",
     "            packet = packet or cited   # keep the cited generation unrevalidated\n            if packet is None:",
     [f"{CO}::test_changed_or_withdrawn_local_authority_refuses_the_brainless_trigger"]),
    ("M11_retained_support_ignores_contradiction", LA,
     "    if path.get(\"status\") != \"active\" or any(\n            not isinstance(flags.get(n), bool) or flags.get(n) for n in names):",
     "    if False:",
     [f"{DC}::test_each_broken_relation_refuses_retained_support",
      f"{DC}::test_retained_support_is_revalidated_and_withdrawn_on_contradiction"]),
    ("M12_plan_trigger_skips_local_binding", CPA,
     "    if current_local != bound.get(\"local_authority_binding\"):\n        return refuse(\"conditional_plan_local_authority_changed\")",
     "    pass",
     [f"{CO}::test_changed_or_withdrawn_local_authority_refuses_the_brainless_trigger"]),
    ("M13_final_quote_trusts_unbound_scope", CPA,
     "    try:\n        final_local = _current_local_binding(checked[\"snapshot\"], bound.get(\"direction\"))\n    except ValueError:\n        return refuse(\"conditional_plan_local_authority_changed\")",
     "    final_local = bound.get(\"local_authority_binding\")",
     [f"{CO}::test_plan_binds_the_route_and_survives_the_brainless_trigger_and_final_quote"]),
    ("M14_telemetry_omits_route", "src/broker/candidate_decision_record.py",
     "            out[\"local_authority_route\"] = local",
     "            pass",
     [f"{CO}::test_v2_records_name_the_route_proof_source_and_first_refusal"]),
    ("M15_member_witness_same_minute", LA,
     "    if crossing < available:",
     "    if crossing < available - timedelta(minutes=1):",
     [f"{MO}::test_same_minute_12_23_crossing_stays_refused"]),
]


def run(repo, tests, log):
    cmd = [f"{S}/g5/run.sh", repo, log, "python", "-m", "pytest", "-q", "-p", "no:cacheprovider",
           "-x", *tests]
    return subprocess.run(cmd, capture_output=True, text=True).returncode


def main(frozen, work, out, only=None):
    results = []
    os.makedirs(work, exist_ok=True)
    for name, rel, old, new, tests in MUTANTS:
        if only and name not in only:
            continue
        dest = os.path.join(work, name)
        shutil.rmtree(dest, ignore_errors=True)
        shutil.copytree(frozen, dest, ignore=shutil.ignore_patterns(".git", "__pycache__"))
        path = os.path.join(dest, rel)
        text = open(path).read()
        count = text.count(old)
        if count != 1:
            results.append({"mutant": name, "status": "NOT_APPLIED", "matches": count})
            continue
        open(path, "w").write(text.replace(old, new))
        rc = run(dest, tests, os.path.join(work, name + ".log"))
        results.append({"mutant": name, "file": rel, "tests": tests, "exit": rc,
                        "status": "KILLED" if rc == 1 else ("ERROR" if rc not in (0, 1) else "SURVIVED")})
        shutil.rmtree(dest, ignore_errors=True)
        print(name, results[-1]["status"], flush=True)
    json.dump(results, open(out, "w"), indent=1)


if __name__ == "__main__":
    main(*sys.argv[1:4], only=sys.argv[4:] or None)

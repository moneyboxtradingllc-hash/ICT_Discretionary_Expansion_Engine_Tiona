# Bounded assignment: exact participation-refusal telemetry

Maurice authorizes this repair and its independent verification. This assignment supersedes the priority of the 2026-10-25 PREPARE ONLY current-Brain evaluation email, Gmail `1a174bb6f9fdbf67`. Stop that evaluation preparation, pricing research and adapter work; preserve existing work separately without merging it here. **Zero paid/current-model/provider/venue calls.** Do not request a call budget or propose spending. Phase 3 remains accepted.

## Ownership and frozen parent

Tiona/Claude owns this observational implementation, debugging, focused and complete supported offline verification and one final return. Codex separately owns doctrine reconciliation for successor chronology, protected-high ownership and proof vocabulary. Do not implement answers to those three questions. No routine approval requests or incremental implementation prompts.

Start a new review branch from exact accepted parent `7b5218ac2fe9bdc1f348c1c433fa4060ae8ba3a2`, tree `d1ef036f1b2dbb5d91f53243673580f85767ad5e`. Verify it. Preserve newer/unrelated work in its existing branch; never reset or erase evidence. Proposed branch `review/participation-refusal-telemetry-20261025`. Do not mix evaluation-adapter changes into this branch.

Parent Brain `brain:d17223b71ac698ff`; retrieval `retr:0c241bdb8234d1ba`; closure 49; 32 protected-source pins. Existing release fingerprint/ledger rules apply: measure the final closure and update only genuinely affected pins under those rules, with reason/diff. Do not repin strategy behavior or alter the protected-source policy to allow this patch. Report any genuinely incompatible protected boundary without bypassing it; complete the feasible observational work.

## Demonstrated defect (not a trade-permission defect)

At the parent, actual `ProductionLoop._record_decision()` receives a scan containing an exact `campaign_lifecycle` assessment. Its journal omits the structured assessment/reason; `campaign_lifecycle_refused` maps to `UNCLASSIFIED`, and actual emitted refusal rows fail `reconcile()`. Friday has 380 such terminal rows, plus two correctly recorded `STOOD_DOWN` rows. Phase 3 fixed producer ownership but not these two omissions.

Inspect actual definitions/callers before editing:

* `src/broker/topstepx_production_loop.py::_record_decision`, both real `self.producer.produce(..., require_campaign_lifecycle=True)` seams and all record paths.
* `src/broker/candidate_decision_record.py::blank_trace`, `terminal_disposition` (near 180), `build_record` (229/245), `reconcile` (254), schema constants and all real readers/exporters.
* `src/broker/luna_candidate_producer.py::produce` near 1260–1360, trace reset/ownership and Lifecycle refusal.
* `src/market_data/campaign_lifecycle.py::evaluate_campaign_lifecycle` and `participation_authority_bound` as read-only source of actual assessments, never new authorization logic.
* Existing tests for producer trace ownership, refusal accounting, stale traces and journal-failure isolation.

The attached nested audit contains `test_offline_boundaries.py`: its first both-mode test instruments the real loop recorder and exposes available-versus-stored Lifecycle causes; its last test isolates terminal/whitelist loss. Those are **parent reproducers**, intentionally asserting the defect. Preserve them as parent evidence; create corrected final expectations rather than claiming an unchanged defect-asserting test proves a repair. Its path assumptions point into Codex's Windows scratch layout; adapt import/output/runtime roots for your supported environment, preserving assertions and frozen source identity. All fixtures/helpers imported by it are already in the accepted repository tests. No runtime credentials are required.

## Required output contract

Choose the smallest backward-compatible typed schema that records the following, with explicit schema/version/read compatibility. Do not add an authority framework.

1. **Exact first refusal:** original rejection code, actual component/gate, Lifecycle state and exact reason, actual participation permission/authorized direction, control state/phase, campaign episode and objective identity when supplied. Use actual source fields. A diagnostic reference may identify the producer function/required witness, but must be clearly separate from an observed reason. Never synthesize a detailed reason from a state label.
2. **Supporting facts and identity:** scan id, contract, settled cutoff; the same-scan assessment's Draw status/binding/generation/history/coverage and current acceptance evidence or an existing safe reference if actually available; actual scope-proposal outcome/witness identities if available. Preserve explicit MISSING/UNKNOWN reasons where unavailable. Do not read private runtime state, reconstruct historical process authority from JSON or invent missing facts. Do not dump an entire unrestricted snapshot or confidential state.
3. **Intent separation:** link the same-scan authored/pre-hold action/direction and guarded/consumed action/direction using the existing authentic envelope/provenance, when present. Never use the observational descriptive field as participation authority or manufacture historical intent. References/digests are acceptable if resolvable in the existing evidence flow; missing evidence stays UNKNOWN.
4. **Terminal accounting:** a dedicated neutral category such as `PARTICIPATION_REFUSED` for the known mechanical refusal. It must not become Brain `STOOD_DOWN`, candidate creation or readiness. Persist exact underlying code/reason. Update actual reconciliation/report consumers so recognized current mechanical refusal records account correctly, while unknown/unmapped reasons, missing mandatory identity, malformed records and contradictory dispositions still fail or report explicit incompleteness. Do not blanket-map unknown reasons to a pass.
5. **Ownership:** distinguish current scan-level Lifecycle assessment from producer trace, and producer execution from a gate never reached. Keep Phase 3's actual `self.producer` and current-scan marker rules. An available scan assessment must not imply the producer ran. Never inherit previous-scan, foreign-contract/session, superseded or decoy-object causes. Record not-reached/unknown downstream stages honestly.
6. **Historical compatibility:** old journals remain readable as old schemas and retain their missing-information status. Do not rewrite or backfill originals, claim historical detailed reasons were known, or silently declare old UNCLASSIFIED rows complete. Any derived classification is a separate versioned output with source digest/provenance.

Persist only JSON-safe bounded diagnostic data under existing redaction rules. Avoid credentials, account identifiers and unrestricted exception/provider payloads. A journal serialization/write failure must remain observational and cannot change candidate/plan/order outcomes. No telemetry field may be consumed as execution permission.

## Forbidden collateral changes

No Brain prompt/schema/constitution tuning; no narrative-hold, ActivePath, campaign-scope/Lifecycle, Draw or CandidateProducer eligibility changes; no CISD/Q-BEARING/f6 binder or D3 relaxation; no new proof family. Read those modules as needed; do not modify their strategy logic. Preserve D0=a, D1=a, 5m/15m, K=1, D3=B/STRICT/INDEPENDENT_SUPPORTING_LIFE, D4=a, D5=a, D6=a. No economics, reward/risk floors, sizing, stops, management, trade-frequency, execution permission or risk changes. Do not alter approved behavior to manufacture candidates.

No main/production merge, deployment, live credentials/private Mac state, authenticated provider probe, current-model/paid call, venue call, arming or orders. Controlled fixture transports and disarmed venue doubles only. Prior session authorization is not reusable.

## Acceptance proof — both ECU and non-ECU

1. Reproduce both defect surfaces on the exact parent using the actual loop/producer/recorder, then prove them fixed on final source. Retain logs/JUnit and causally match available assessment to persisted fields.
2. Healthy controls: existing W5 production-loop qualified candidate remains `QUALIFIED_CANDIDATE_OBSERVED` with `EXECUTION_DISARMED`; original Brain stand-down retains its distinct disposition. Compare stable decision/candidate/plan/geometry/permission outputs against parent, excluding identified nonsemantic IDs/timing with explicit rationale.
3. Mechanical controls: exercise real unknown Draw, newborn Draw, retired/current-acceptance, establishing/unresolved transfer and delivered-destination reasons using existing fixtures. Persist actual reason and current evidence, and reconcile the new known terminal category. Retired formation/tool refusal remains unchanged. Do not fake a reason packet when a real producer path is available.
4. Custody controls: stale previous-scan trace, decoy producer, foreign contract/session, skipped producer call and superseded evidence must not leak into the current journal. Missing current-acceptance or scope-detail evidence must remain typed UNKNOWN without invented cause.
5. Reader controls: mixed legacy/new journal, unknown reason, malformed identity and contradictory disposition. Valid new mechanical refusals reconcile; truly unknown/incomplete evidence must not turn green. Original archives remain unchanged.
6. Failure isolation: serialization or write error does not change outcome/authority; bounded diagnostics remain readable/redacted. No telemetry reader influences participation.
7. Activated negative controls on final code: deliberately restore dropped Lifecycle fields, generic UNCLASSIFIED mapping, stale ownership or blanket unknown-to-pass behavior, one invariant at a time. Healthy final source passes; each relevant mutant is caught by an actual consumer assertion. Preserve mutant diffs and results; do not commit mutants.
8. Re-run existing conditional-plan/fresh-cutoff/brainless/final-quote/lost-custody and narrative-history separation controls in both lanes, without real orders. No new trading permission is part of testing.

Run focused tests, then the **complete isolated offline suite at the final frozen source** in the supported runtime. Use credential-free isolated roots and deny network; report all skips and runtime limitations honestly. When any relevant source changes after a checkpoint, rerun affected checks and the final full suite. Resolve your demonstrated implementation defects independently until the bounded deliverable is complete.

## One final return

Return one indexed package with: exact parent/final SHA and tree, branch/full diff and portable source bundle; cause-to-code/schema/readers map; parent/final reproducers; stable parent/final decision comparisons; both-mode positives/refusals and activated mutants; focused and complete collection/JUnit/logs/skip accounting; unchanged protected pins and measured final Brain/retrieval closure; archive/manifest digests; known limitations. Include a short statement that doctrine reconciliation and natural-model recognition remain unproven by this telemetry patch, and production remains disarmed.

No incremental status emails unless a substantive blocker makes this bounded mission impossible. Do not ask Maurice for daily supervision or another prompt after each test. Codex will independently audit the one final return. This is not a new implementation program and conveys no trading authorization.

## Evidence included

`OFFLINE_AUTHORITY_RECONCILIATION_20261025.zip` contains the completed owner-side report, 397-row forensic reconstruction, exact source/gate references, proof episodes and controlled whole-path checks. Original nested archive SHA256 `921d97734b14ae3eb9820b342a96a1b670672ab889d70d059993e2fbe1fe1d0a`, 434,889 bytes, 31 sealed artifacts plus manifest. It is evidence, not an instruction to implement its proposed authority routes. The original Friday archive/source/fixtures already delivered remain authoritative inputs; do not fabricate unavailable originals.

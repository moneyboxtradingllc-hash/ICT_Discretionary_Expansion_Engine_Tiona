# PARTICIPATION_REFUSAL_TELEMETRY_20261025: index

| Path | Contents |
|---|---|
| `00_COMPLETION_REPORT.md` | Identity, defect, change, acceptance table, superseded checkpoint, suites, limitations |
| `01_SCHEMA_AND_READER_MAP.md` | v2 schema, cause → code → field → reader map, reconciliation rules (also committed under `docs/recognition_validation/`) |
| `identity/` | `source_identity_{parent,final}.json`, `PINS_AND_CLOSURE.json` (32 protected pins, closure 49, changed files, measured fingerprints), `LEDGER_VERIFY.json`, the contract mission text |
| `source/` | Full diff 7b5218a..14c996c, diff stat, commit text, git bundle (prerequisite 7b5218a) |
| `parent_reproduction/` | Owner reproducer `test_offline_boundaries.py` (assertions unchanged) at 7b5218a: 7 passed, log, JUnit, whole-path/C2 outputs |
| `final_reproduction/` | The same file at 14c996c: the defect assertions fail as intended (2 failed, 5 passed), log, JUnit |
| `stable_comparison/` | Parent and final dumps of decisions, candidate geometry, plan, permissions and v1 record fields, plus the dumper and `STABLE_COMPARISON.json` |
| `final_records/` | Actual v2 journal records from the real loop (both lanes), plus the Friday ESTABLISHING probe |
| `focused/` | Focused run (pre-commit), the 176-test rerun after the hand-off fix, and the superseded-checkpoint finding log |
| `mutants/` | `apply.py`, six mutant diffs, logs and JUnit (never committed) |
| `full_suite/` | Collection, shard plan, four shard logs/JUnit/done markers, merged JUnit, `union.json`, `skip_accounting.json`, runner and tools |
| `MANIFEST_SHA256.txt` | SHA-256 of every file in this package |

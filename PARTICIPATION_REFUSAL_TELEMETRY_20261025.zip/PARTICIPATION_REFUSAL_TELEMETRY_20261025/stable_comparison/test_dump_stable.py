"""Dump stable decision/candidate/plan/geometry/permission outputs for parent-vs-final comparison."""
import json, os
from pathlib import Path
import pytest
import test_po3_full_graph_production_loop as G
import test_po3_anchor_replacement_revocation as C
import test_campaign_scope_binding as B

OUT = Path(os.environ.get("STABLE_OUT", "."))
V1_FIELDS = None

def _journal(root):
    return [json.loads(l) for f in Path(root).rglob("candidate_decisions.jsonl") for l in f.read_text().splitlines() if l.strip()]

def _stable_record(r):
    from broker.candidate_decision_record import blank_trace
    keep = ["scan_id", "timestamp_et", "instrument", "contract", "direction", "action", "playbook",
            "final_rejection_reason", "detail", "decision_trace_source", "active_draw", "invalidation_level",
            "conditional_plan", "plan_expires_at"] + list(blank_trace())
    return {k: r.get(k) for k in keep}

@pytest.mark.parametrize("seq", ["_HEALTHY", "_REPLACED"])
@pytest.mark.parametrize("ecu", [False, True], ids=["non-ecu", "ecu"])
def test_dump(tmp_path, monkeypatch, ecu, seq):
    out, loop, venue, mission, chosen, payloads = G._loop(tmp_path / "x", monkeypatch, getattr(C, seq), ecu=ecu, arm_at=None)
    cand = loop.active_candidate
    doc = {"outcomes": {hm: {k: o.get(k) for k in ("outcome", "reason", "execution", "stand_down", "detail")} for hm, o in out.items()},
           "candidate": None if cand is None else {"direction": cand.direction, "entry": cand.entry_price,
                "invalidation": cand.invalidation_price, "objective": cand.objective.price,
                "objective_identity": cand.objective.identity,
                "occurrence": cand.extras.get("selected_tool_occurrence_id")},
           "plan": None if not loop.active_conditional_plan else {k: loop.active_conditional_plan.get(k) for k in ("zone_low", "zone_high")},
           "armed": loop.armed, "place_calls": venue.place_calls, "tokens": mission.token_count,
           "attempts": mission.entry_attempt_count, "payloads": payloads,
           "records": [_stable_record(r) for r in _journal(tmp_path / "x")],
           "dispositions": [r.get("final_disposition") for r in _journal(tmp_path / "x")]}
    (OUT / f"stable_{seq}_{ecu}.json").write_text(json.dumps(doc, indent=1, sort_keys=True, default=str))

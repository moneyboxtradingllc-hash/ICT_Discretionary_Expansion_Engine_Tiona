"""Apply ONE activated negative control to a throwaway worktree (never committed)."""
import sys
from pathlib import Path
name, root = sys.argv[1], Path(sys.argv[2])
REC = root / "src/broker/candidate_decision_record.py"
LOOP = root / "src/broker/topstepx_production_loop.py"
MUTANTS = {
    # M1: restore the parent's dropped Lifecycle cause (v2 shell, no evidence).
    "M1_DROP_LIFECYCLE_FIELDS": (REC, '''        record.update(participation_evidence(parsed=kwargs.pop("parsed", None) or {
            "current_action": record.get("action"), "narrative_direction": record.get("direction")}, **kwargs))''',
        '''        record.update(participation_evidence(parsed=kwargs.pop("parsed", None) or {
            "current_action": record.get("action"), "narrative_direction": record.get("direction")}, **kwargs))
        for key in ("participation_refusal", "campaign_lifecycle_assessment"):
            record[key] = None'''),
    # M2: restore the generic UNCLASSIFIED mapping.
    "M2_GENERIC_UNCLASSIFIED": (REC, '''    "campaign_lifecycle_refused": PARTICIPATION_REFUSED,
''', ""),
    # M3: stale ownership -- read the producer trace whether or not this scan owns it.
    "M3_STALE_OWNERSHIP": (LOOP, '''                producer_current=current,
                producer_trace=(getattr(producer, "last_decision_trace", None)
                                if current else None),''', '''                producer_current=True,
                producer_trace=getattr(producer, "last_decision_trace", None),'''),
    # M4: blanket unknown-to-pass in the reconciler.
    "M4_BLANKET_RECONCILE_PASS": (REC, '''    if record.get("schema_version") != SCHEMA_VERSION_V2:
        return ["legacy_record_lacks_participation_refusal_evidence"]''', '''    return []'''),
    # M5: blanket unknown reasons into the new category.
    "M5_BLANKET_UNKNOWN_REASON": (REC, '''    return _REASON_TO_DISPOSITION.get(str(reason or ""), UNCLASSIFIED)''',
        '''    return _REASON_TO_DISPOSITION.get(str(reason or ""), PARTICIPATION_REFUSED)'''),
    # M6: stale refusal hand-off -- read whatever refusal was left, for any scan.
    "M6_STALE_REFUSAL_HANDOFF": (LOOP, '''            refusal = (pending[2] if isinstance(pending, tuple) and len(pending) == 3
                       and pending[0] == scan.get("scan_count")
                       and pending[1] == scan.get("snapshot_id")
                       and getattr(pending[2], "reason", None) == reason else None)''',
        '''            refusal = pending[2] if isinstance(pending, tuple) and len(pending) == 3 else None'''),
}
path, old, new = MUTANTS[name]
text = path.read_text()
assert text.count(old) == 1, name
path.write_text(text.replace(old, new))
print("applied", name)

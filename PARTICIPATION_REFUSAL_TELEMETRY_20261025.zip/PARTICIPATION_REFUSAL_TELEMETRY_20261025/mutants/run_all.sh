#!/bin/bash
S=/tmp/claude-0/-home-user-ICT-Discretionary-Expansion-Engine-Tiona/4c1b4a67-6e49-58ef-be1e-a80c4037fc0a/scratchpad
run() { m=$1; $S/g5/run.sh $S/t1/mutants/$m $S/t1/mutants/$m.log python -m pytest -p no:cacheprovider -q -rf --junitxml=$S/t1/mutants/$m.junit.xml tests/test_participation_refusal_telemetry.py tests/test_decision_accounting_stood_down.py tests/test_decision_accounting_held.py; }
run M1_DROP_LIFECYCLE_FIELDS & run M2_GENERIC_UNCLASSIFIED & run M3_STALE_OWNERSHIP & run M6_STALE_REFUSAL_HANDOFF & wait
run M4_BLANKET_RECONCILE_PASS & run M5_BLANKET_UNKNOWN_REASON & wait
echo ALLDONE

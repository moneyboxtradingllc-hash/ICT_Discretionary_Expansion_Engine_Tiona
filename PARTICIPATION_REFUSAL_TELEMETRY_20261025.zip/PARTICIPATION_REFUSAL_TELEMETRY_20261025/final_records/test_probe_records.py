import json
from pathlib import Path
import pytest
import test_po3_full_graph_production_loop as G
import test_po3_anchor_replacement_revocation as C
from broker.candidate_decision_record import reconcile

@pytest.mark.parametrize('ecu',[False,True],ids=['non-ecu','ecu'])
def test_dump(tmp_path,monkeypatch,ecu):
    good,loop,venue,mission,chosen,payloads=G._loop(tmp_path/'healthy',monkeypatch,C._HEALTHY,ecu=ecu,arm_at=None)
    records=[json.loads(s) for p in (tmp_path/'healthy').rglob('candidate_decisions.jsonl') for s in p.read_text().splitlines() if s.strip()]
    out=Path(__file__).parent/f'records_{ecu}.json'
    out.write_text(json.dumps({'terminal':good['15:06'],'records':records,'reconcile':reconcile(records)},indent=1,default=str))

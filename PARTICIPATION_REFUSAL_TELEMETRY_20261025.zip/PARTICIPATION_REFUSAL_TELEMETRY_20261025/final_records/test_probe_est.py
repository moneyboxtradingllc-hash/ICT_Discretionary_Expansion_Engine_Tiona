import json
from pathlib import Path
import pytest
import test_protected_structure_continuity as PS
import test_reversal_foundation_proof_closure as RF
from test_protected_structure_continuity import _isolated_runtime  # noqa: F401

@pytest.mark.parametrize('ecu',[False,True])
def test_states(monkeypatch,ecu):
    cycle=PS._friday_cycle()
    for hhmm in PS._minutes("12:55","13:15"):
        PS._scan(cycle,hhmm,False)
    calls=[]
    RF._mock_current_brain(monkeypatch,calls,output_mutator=PS._controlled)
    monkeypatch.setenv("BRAIN_ECU_MODE","true" if ecu else "false")
    rows=[]
    for hhmm in PS._minutes("13:16","13:34"):
        s=PS._scan(cycle,hhmm,True)
        lc=s['snapshot']['campaign_lifecycle']
        rows.append((hhmm,lc['state'],lc['reason'],PS._candidate(s)))
    Path(__file__).with_name(f'est_{ecu}.json').write_text(json.dumps(rows))

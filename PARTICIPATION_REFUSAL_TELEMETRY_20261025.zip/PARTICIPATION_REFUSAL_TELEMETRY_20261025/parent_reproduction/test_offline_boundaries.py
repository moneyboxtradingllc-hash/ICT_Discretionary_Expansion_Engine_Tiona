"""Owner-side controlled proofs. No historical intent is invented; no arm switch.

All Brain replies in these constructed-tape cases are explicit transport
doubles. Venue objects are doubles and every loop remains disarmed.
"""
import copy,json
from pathlib import Path
import pytest
import test_po3_full_graph_production_loop as G
import test_po3_anchor_replacement_revocation as C
import test_campaign_scope_binding as B
import test_campaign_draw_temporal_authority as TA
import test_campaign_leg_scope_labels as L
import test_reversal_foundation_proof_closure as RF
import test_stance_history_hygiene as H
from broker.topstepx_production_loop import ProductionLoop
from broker.candidate_decision_record import reconcile,build_record,terminal_disposition

R=Path(__file__).resolve().parent

@pytest.mark.parametrize('ecu',[False,True],ids=['non-ecu','ecu'])
def test_actual_disarmed_candidate_and_matched_retirement_and_journal_gap(tmp_path,monkeypatch,ecu):
    observations=[]
    original=ProductionLoop._record_decision
    def observe(self,scan,*args,**kwargs):
        observations.append({'scan_id':scan.get('snapshot_id'),'cutoff':(scan.get('snapshot') or {}).get('timestamp'),'lifecycle':copy.deepcopy((scan.get('snapshot') or {}).get('campaign_lifecycle')),'disposition':args[0] if args else None,'refusal':args[1] if len(args)>1 else None})
        return original(self,scan,*args,**kwargs)
    monkeypatch.setattr(ProductionLoop,'_record_decision',observe)
    good,loop,venue,mission,chosen,payloads=G._loop(tmp_path/'healthy',monkeypatch,C._HEALTHY,ecu=ecu,arm_at=None)
    assert good['15:06']['outcome']==G.PL.QUALIFIED_CANDIDATE_OBSERVED
    assert good['15:06']['execution']==G.PL.EXECUTION_DISARMED
    assert not loop.armed and venue.place_calls==0 and payloads==[]
    assert mission.token_count==mission.entry_attempt_count==0
    candidate=loop.active_candidate
    assert candidate.extras['selected_tool_occurrence_id']==G.FORMATION_ID
    journals=list((tmp_path/'healthy').rglob('candidate_decisions.jsonl'))
    records=[json.loads(s) for p in journals for s in p.read_text().splitlines() if s.strip()]
    observed={o['scan_id']:o for o in observations}
    refused=[d for d in records if d['final_rejection_reason']=='campaign_lifecycle_refused']
    assert refused, 'A genuine earlier lifecycle refusal is the observability negative'
    losses=[]
    for d in refused:
        event=observed[d['scan_id']]
        assert event['lifecycle']['state'] and event['lifecycle']['reason']
        assert 'campaign_lifecycle' not in d and 'campaign_lifecycle_reason' not in d
        assert d['final_disposition']=='UNCLASSIFIED'
        losses.append({'scan_id':d['scan_id'],'available_actual_lifecycle':event['lifecycle'],'stored_detail':d['detail'],'stored_terminal':d['final_disposition']})
    assert reconcile(refused)['status']=='CANDIDATE_DECISION_ACCOUNTING_FAILURE'
    # Same true market/campaign setup, one changed bar retires the selected
    # formation. It must refuse before any token/order, STILL disarmed.
    monkeypatch.undo()
    bad,bloop,bvenue,bmission,bchosen,bpayloads=G._loop(tmp_path/'retired',monkeypatch,C._REPLACED,ecu=ecu,arm_at=None)
    assert bchosen[max(bchosen)]==G.FORMATION_ID
    assert bad['15:06']['outcome']==G.PL.NO_CANDIDATE
    assert bad['15:06']['reason']=='tool_not_detected'
    assert not bloop.armed and bvenue.place_calls==0 and bpayloads==[]
    assert bmission.token_count==bmission.entry_attempt_count==0
    (R/f'WHOLE_PATH_{ecu}.json').write_text(json.dumps({'cognition':'CONTROLLED_NOT_HISTORICAL','ecu':ecu,'healthy_terminal':good['15:06'],'candidate':{'direction':candidate.direction,'entry':candidate.entry_price,'invalidation':candidate.invalidation_price,'objective':candidate.objective.price,'selected_occurrence':candidate.extras['selected_tool_occurrence_id']},'matched_retired_terminal':bad['15:06'],'zero_orders_and_tokens':True,'remaining_journal_cause_loss_confirmed':losses},indent=2,default=str))

@pytest.mark.parametrize('ecu',[False,True],ids=['non-ecu','ecu'])
def test_actual_scope_candidate_and_plan_fresh_quote_refusals(tmp_path,monkeypatch,ecu):
    (tmp_path/'direct').mkdir();(tmp_path/'plan').mkdir()
    B.test_real_t2_pending_t3_newborn_refusal_t4_candidate(tmp_path/'direct',monkeypatch,ecu)
    B.test_real_bound_plan_survives_fresh_cutoff_and_refuses_lost_custody(tmp_path/'plan',monkeypatch,ecu)

@pytest.mark.parametrize('ecu',[False,True],ids=['non-ecu','ecu'])
def test_actual_c2_healthy_then_missing_bearing_refuses(tmp_path,monkeypatch,ecu):
    cycle,calls=H._lane(tmp_path,monkeypatch,ecu)
    H._brain_scan(cycle,calls,RF.TAPE_1M)
    healthy,_=H._brain_scan(cycle,calls,TA.LATER)
    positive=RF._produce_candidate(healthy);assert positive.direction=='bullish'
    rows=list(TA.LATER);trace=[]
    for bar in L.SCENARIOS['C2']:
        rows.append(bar);scan,payload=H._brain_scan(cycle,calls,rows)
        if bar['timestamp'][11:16]>='03:07':
            assert scan['snapshot']['active_path_state']['load_bearing_structure'] is None
            assert scan['brain_block']['narrative_continuity']['control_state']=='developing_transfer'
            assert L._candidate(scan)=='campaign_lifecycle_refused'
            trace.append({'cutoff':bar['timestamp'],'pre_hold_action':scan['brain_block']['authored_market_read']['authored_action'],'post_hold_action':scan['brain_block']['output']['current_action'],'lifecycle':scan['campaign_lifecycle']})
    assert trace
    (R/f'C2_BOUNDARY_{ecu}.json').write_text(json.dumps({'cognition':'CONTROLLED_NOT_HISTORICAL','healthy_candidate_direction':positive.direction,'refusals':trace},indent=2,default=str))

def test_terminal_accounting_healthy_and_actual_mechanical_negative():
    healthy=build_record(session_id='FICTIONAL',scan_id='POSITIVE',timestamp_et='2026-10-23T13:30:00Z',instrument='MNQ',contract='FICTIONAL',parsed={'current_action':'stand_down'},trace={},disposition=terminal_disposition('action_declines_entry'),rejection_reason='action_declines_entry')
    assert reconcile([healthy])['status']=='RECONCILED'
    failed=build_record(session_id='FICTIONAL',scan_id='NEGATIVE',timestamp_et='2026-10-23T13:30:00Z',instrument='MNQ',contract='FICTIONAL',parsed={'current_action':'stand_down'},trace={'campaign_lifecycle_state':'TRANSFER_UNRESOLVED','campaign_lifecycle_refusal':'narrative_control_transfer_not_yet_confirmed'},disposition=terminal_disposition('campaign_lifecycle_refused'),rejection_reason='campaign_lifecycle_refused')
    assert 'campaign_lifecycle_state' not in failed
    assert reconcile([failed])['status']=='CANDIDATE_DECISION_ACCOUNTING_FAILURE'

"""Merge shard JUnit files into one testsuite and check the union against the --collect-only list.

usage: merge_shards.py <shard_dir> <collect.txt> <out.xml> <out_union.json>
"""
import json, sys
import xml.etree.ElementTree as ET
from pathlib import Path

shard_dir, collect, out_xml, out_json = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
plan = json.loads((shard_dir / "shards.json").read_text())
merged = ET.Element("testsuite", name="pytest")
totals = {"tests": 0, "failures": 0, "errors": 0, "skipped": 0, "time": 0.0}
ids = []
for i in range(len(plan["shards"])):
    root = ET.parse(shard_dir / f"shard_{i:02d}.xml").getroot()
    suite = root if root.tag == "testsuite" else root.find("testsuite")
    for k in ("tests", "failures", "errors", "skipped"):
        totals[k] += int(suite.get(k, 0))
    totals["time"] += float(suite.get("time", 0))
    for case in suite.iter("testcase"):
        merged.append(case)
        ids.append((case.get("file"), case.get("classname"), case.get("name")))
for k, v in totals.items():
    merged.set(k, str(round(v, 3) if k == "time" else v))
merged.set("shards", str(len(plan["shards"])))
ET.ElementTree(ET.Element("testsuites", {}, )).getroot()
wrapper = ET.Element("testsuites"); wrapper.append(merged)
ET.ElementTree(wrapper).write(out_xml, encoding="utf-8", xml_declaration=True)
collected = [l for l in collect.read_text().splitlines() if l.startswith("tests/") and "::" in l]
files = sorted({l.split("::", 1)[0] for l in collected})
planned = sorted(f for s in plan["shards"] for f in s["files"])
report = {"collected_tests": len(collected), "collected_files": len(files), "planned_files": len(planned),
          "files_equal_collection": files == planned, "files_disjoint": len(planned) == len(set(planned)),
          "junit_testcases": len(ids), "junit_unique": len(set(ids)), "totals": totals,
          "shard_tests": [s["tests"] for s in plan["shards"]]}
out_json.write_text(json.dumps(report, indent=1))
print(json.dumps(report))

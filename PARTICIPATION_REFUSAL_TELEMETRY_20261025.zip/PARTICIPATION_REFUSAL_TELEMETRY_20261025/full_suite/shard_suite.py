"""Restart-safe full suite: file-disjoint shards from one --collect-only, each in its own process.

usage: shard_suite.py plan <collect.txt> <shard_dir> <n>   -> writes shards.json
       shard_suite.py run <S> <clone> <shard_dir> <worker> <workers>
A shard with a .done marker is never rerun; an interrupted shard's partial log is kept as *.interrupted.N.
"""
import json, subprocess, sys
from pathlib import Path

if sys.argv[1] == "plan":
    collect, out, n = Path(sys.argv[2]), Path(sys.argv[3]), int(sys.argv[4])
    counts = {}
    for line in collect.read_text().splitlines():
        if "::" in line and line.startswith("tests/"):
            path = line.split("::", 1)[0]
            counts[path] = counts.get(path, 0) + 1
    shards = [{"files": [], "tests": 0} for _ in range(n)]
    for path, c in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])):
        target = min(shards, key=lambda s: s["tests"])
        target["files"].append(path); target["tests"] += c
    for s in shards:
        s["files"].sort()
    out.mkdir(parents=True, exist_ok=True)
    (out / "shards.json").write_text(json.dumps({"collected_files": len(counts), "collected_tests": sum(counts.values()),
                                                 "shards": shards}, indent=1))
    print(len(counts), sum(counts.values()), [s["tests"] for s in shards])
else:
    S, clone, out, worker, workers = Path(sys.argv[2]), sys.argv[3], Path(sys.argv[4]), int(sys.argv[5]), int(sys.argv[6])
    plan = json.loads((out / "shards.json").read_text())
    for i, shard in enumerate(plan["shards"]):
        if i % workers != worker or (out / f"shard_{i:02d}.done").exists():
            continue
        log, xml = out / f"shard_{i:02d}.log", out / f"shard_{i:02d}.xml"
        if log.exists():
            k = len(list(out.glob(f"shard_{i:02d}.interrupted.*")))
            log.rename(out / f"shard_{i:02d}.interrupted.{k}")
        xml.unlink(missing_ok=True)
        subprocess.run(["date", "-u", "+%FT%TZ"], stdout=open(out / f"shard_{i:02d}.started", "w"))
        rc = subprocess.run([str(S / "g5/run.sh"), clone, str(log), "python3", "-m", "pytest", "-q", "-rfE",
                             "-p", "no:cacheprovider", f"--junitxml={xml}", *shard["files"]]).returncode
        (out / f"shard_{i:02d}.done").write_text(json.dumps({"rc": rc, "files": len(shard["files"])}))

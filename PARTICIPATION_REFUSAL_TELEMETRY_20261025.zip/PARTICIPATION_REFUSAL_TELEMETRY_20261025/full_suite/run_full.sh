#!/bin/bash
S=<scratch>
for w in 0 1 2 3; do python3 $S/g5/tools/shard_suite.py run $S $S/t1/full/c$w $S/t1/full/run $w 4 > $S/t1/full/run/worker_$w.out 2>&1 & done
wait; date -u +%FT%TZ > $S/t1/full/run/suite.finished; echo FULLDONE

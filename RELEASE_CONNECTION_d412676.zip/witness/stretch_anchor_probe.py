import json, os, sys, tempfile
from datetime import datetime, timedelta
r=tempfile.mkdtemp()
for k in ("OCCURRENCE_LEDGER_DIR","AI_BRAIN_DIR","AI_RETRIEVAL_DIR","REPLAY_SESSIONS_DIR"): os.environ[k]=os.path.join(r,k)
import test_protected_structure_continuity as P
from live_scan.production_scan_cycle import ProductionScanCycle
from market_data import local_authority as LA
ANCHOR=sys.argv[1] if len(sys.argv)>1 else "14:30"
def stretch(tape, anchor, k=3):
    a=datetime.fromisoformat(P._cut(anchor)); out=[]
    for b in tape:
        t=datetime.fromisoformat(b["timestamp"])
        if t<a: out.append(dict(b)); continue
        base=a+(t-a)*k; o,h,l,c=b["open"],b["high"],b["low"],b["close"]
        path=[(o,o,l,l),(l,h,l,h),(h,h,c,c)] if c>=o else [(o,h,o,h),(h,h,l,l),(l,c,l,c)]
        for i,(oo,hh,ll,cc) in enumerate(path):
            out.append({**b,"timestamp":(base+timedelta(minutes=i)).isoformat(),"open":oo,"high":max(oo,hh,ll,cc),"low":min(oo,hh,ll,cc),"close":cc,"volume":b.get("volume",0)/k if isinstance(b.get("volume"),(int,float)) else b.get("volume")})
    return out
T=stretch(P.TAPE,ANCHOR)
print(len(T),T[-1]["timestamp"])
c=ProductionScanCycle(symbol="MNQ",contract_id=P.C,session_id="PR",local_authority_profile=LA.OFFLINE_TEST_PROFILE_V1)
a=datetime.fromisoformat(P._cut(ANCHOR))
def mapped(hm): return a+(datetime.fromisoformat(P._cut(hm))-a)*3
start=mapped("16:00"); end=mapped("16:40")
seen=None
t=start
while t<=end:
    cut=t.isoformat(); bars=[b for b in T if b["timestamp"]<=cut][-300:]
    s=c.scan(bars,now=t+timedelta(minutes=1),invoke_brain=False)
    g=c.local_authority._generation
    if g and g.get("market_proof_id")!=seen:
        seen=g["market_proof_id"]; print(cut, g["direction"], g["life"]["source_tf"], g["body_confirmation"]["timeframe"], g["failure"]["source_tf"], g["completed_at"], seen[:16])
    t+=timedelta(minutes=1) if t>=mapped("16:15") else timedelta(minutes=5)
print("diag", json.dumps(c.local_authority.diagnostics, default=str)[:1500])

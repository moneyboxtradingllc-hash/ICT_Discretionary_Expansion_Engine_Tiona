"""Activated release-connection mutants (LOCAL-AUTHORITY-RELEASE-20261027).

usage: python release_mutants.py <frozen_repo> <workdir> <out.json> [names...]
Each mutant copies the frozen tree (no .git), applies ONE source edit, runs the
named tests (which must turn red) and the healthy OFF baseline (which must stay
green). The unmutated copy runs both sets first and must pass.
"""
import json, os, shutil, subprocess, sys

S = "[scratch]"
LA = "src/market_data/local_authority.py"
PLP = "src/broker/topstepx_production_loop.py"
TOOL = "tools/topstepx_production_session.py"
T = "tests/test_local_authority_release.py"
OFF = [f"{T}::test_normal_off_launch_builds_the_real_default_cycle_disabled",
       f"{T}::test_delivered_release_selection_is_the_literal_none"]

MUTANTS = [
    ("R1_loop_omits_constructor_forwarding", PLP,
     "            local_authority_profile=local_authority_profile)\n        if (local_authority_profile is not None\n                and self.cycle.local_authority.profile is not local_authority_profile):\n            # Refused (e.g. offline beside execution switches): fail, never run\n            # as legacy DISABLED while the caller believes the profile is on.\n            raise LA.ProfileSelectionRefused(\n                self.cycle.local_authority.profile_reason or \"requested_profile_refused\")",
     "            )",
     [f"{T}::test_controlled_selection_reaches_the_launch_built_cycle",
      f"{T}::test_loop_forwards_the_profile_to_its_own_cycle_with_the_real_bindings"]),
    ("R2_offline_guard_removed", LA,
     "    if armed:\n        return DISABLED, \"offline_profile_refused_execution_environment\"",
     "    pass",
     [f"{T}::test_offline_profiles_still_refuse_beside_execution_switches",
      f"{T}::test_a_refused_requested_profile_fails_construction"]),
    ("R3_unknown_profile_accepted", LA,
     "        return DISABLED, \"unrecognized_profile_disabled\"",
     "        return value, None",
     [f"{T}::test_unknown_copies_and_lookalikes_never_become_profiles"]),
    ("R4_invalid_selection_falls_back_to_legacy", LA,
     "        raise ProfileSelectionRefused(\n            \"offline_profile_not_releasable\" if known else \"unknown_release_selection\")",
     "        requested = None\n        return {\"requested\": None, \"profile\": None, \"resolved\": DISABLED.version,\n                \"cases\": [], \"reason\": \"release_selection_off\", \"source\": RELEASE_SELECTION_SOURCE}",
     [f"{T}::test_invalid_selection_refuses_main_before_any_venue_or_model",
      f"{T}::test_invalid_selection_refuses_the_launcher_before_authorization"]),
    ("R5_launcher_drops_the_selection", TOOL,
     "        in_window=lambda: production_window_open(),\n        local_authority_profile=selection[\"profile\"])",
     "        in_window=lambda: production_window_open())",
     [f"{T}::test_controlled_selection_reaches_the_launch_built_cycle"]),
    ("R6_conflict_silently_ignored", PLP,
     "            raise LA.ProfileSelectionRefused(\"profile_conflicts_with_supplied_scan_cycle\")",
     "            pass",
     [f"{T}::test_a_requested_profile_never_silently_loses_to_a_supplied_cycle"]),
    ("R7_production_profile_refused_beside_switches", LA,
     "    if any(value is profile for profile in _PRODUCTION_PROFILES):\n        return value, None\n",
     "",
     [f"{T}::test_production_profile_is_exact_and_runs_beside_execution_switches",
      f"{T}::test_controlled_selection_reaches_the_launch_built_cycle"]),
]


def run(repo, tests, log):
    cmd = [f"{S}/g5/run.sh", repo, log, "python", "-m", "pytest", "-q", "-p", "no:cacheprovider", *tests]
    return subprocess.run(cmd, capture_output=True, text=True).returncode


def main(frozen, work, out, only=None):
    os.makedirs(work, exist_ok=True)
    base = os.path.join(work, "UNMUTATED")
    shutil.rmtree(base, ignore_errors=True)
    shutil.copytree(frozen, base, ignore=shutil.ignore_patterns(".git", "__pycache__"))
    every = sorted({t for m in MUTANTS for t in m[4]} | set(OFF))
    results = [{"mutant": "UNMUTATED", "exit": run(base, every, os.path.join(work, "UNMUTATED.log"))}]
    shutil.rmtree(base, ignore_errors=True)
    for name, rel, old, new, tests in MUTANTS:
        if only and name not in only:
            continue
        dest = os.path.join(work, name)
        shutil.rmtree(dest, ignore_errors=True)
        shutil.copytree(frozen, dest, ignore=shutil.ignore_patterns(".git", "__pycache__"))
        path = os.path.join(dest, rel)
        text = open(path).read()
        if text.count(old) != 1:
            results.append({"mutant": name, "status": "NOT_APPLIED", "matches": text.count(old)})
            continue
        open(path, "w").write(text.replace(old, new))
        rc = run(dest, tests, os.path.join(work, name + ".log"))
        off = run(dest, OFF, os.path.join(work, name + ".off.log"))
        results.append({"mutant": name, "file": rel, "tests": tests, "exit": rc, "off_baseline_exit": off,
                        "status": "KILLED" if rc == 1 and off == 0 else ("ERROR" if rc not in (0, 1) else "SURVIVED")})
        shutil.rmtree(dest, ignore_errors=True)
        print(name, results[-1]["status"], off, flush=True)
    json.dump(results, open(out, "w"), indent=1)


if __name__ == "__main__":
    main(*sys.argv[1:4], only=sys.argv[4:] or None)

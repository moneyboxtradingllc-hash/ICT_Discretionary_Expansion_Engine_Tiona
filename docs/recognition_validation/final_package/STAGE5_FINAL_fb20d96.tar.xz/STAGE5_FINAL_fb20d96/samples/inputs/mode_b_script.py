import test_recognition_current_path as CP  # needs PYTHONPATH=src:tests from the repo root

script, _state = CP._script()

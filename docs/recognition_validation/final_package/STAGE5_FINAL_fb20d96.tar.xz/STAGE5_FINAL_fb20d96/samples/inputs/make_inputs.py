"""Regenerate the CONSTRUCTED sample inputs from the repository's own fixtures (run with PYTHONPATH=src:tests)."""
import json, sys
from pathlib import Path
import test_po3_distinct_anchor_premise as W
import test_recognition_current_path as CP
from recognition_validation import corpus as K, contracts as C
out = Path(sys.argv[1]); repo = Path(sys.argv[2])
corpus = K.build_constructed_corpus(out / "corpus", session_id=CP.SESSION, contract_id=CP.CONTRACT,
                                    market_date="2026-08-19", tape=W._tape(W._HEALTHY),
                                    warmup_end="2026-08-19T15:30:00+00:00",
                                    notes="CONSTRUCTED distinct-anchor tape; mechanics only.",
                                    sealed_at="2026-10-17T00:00:00Z")
digest = K.load_corpus(corpus).digest
base = json.loads((repo / "src/recognition_validation/examples/current_brain_disabled.json").read_text())
prov = {"classification": "CONSTRUCTED", "author_role": "STAGE5_SAMPLE", "source_refs": [],
        "notes": "CONSTRUCTED sample run document; mechanics only."}
for name, over in (("run-B.json", dict(mode="B", ecu=False, trajectory_id="S5-SAMPLE-B", dry_run=False, trajectory_count=1)),
                   ("run-B-ecu.json", dict(mode="B", ecu=True, trajectory_id="S5-SAMPLE-B-ECU", dry_run=False, trajectory_count=1)),
                   ("run-A.json", dict(mode="A", ecu=False, trajectory_id="S5-SAMPLE-B", dry_run=False, trajectory_count=1)),
                   ("run-C-disabled.json", dict(mode="C", ecu=False, trajectory_id="S5-SAMPLE-C", dry_run=True, trajectory_count=0))):
    doc = dict(base, document_id=name[:-5], provenance=prov, corpus_digest=digest, **over)
    C.validate(doc)
    (out / name).write_text(json.dumps(doc, indent=1, sort_keys=True))
(out / "mode_b_script.py").write_text(
    "import sys\nsys.path.insert(0, %r)\nimport test_recognition_current_path as CP\nscript, _state = CP._script()\n"
    % str(repo / "tests"))
print(corpus)

"""Build Mode A 'historical' records from a recorded run's evidence (CONSTRUCTED demonstration only)."""
import json, sys
from pathlib import Path
from recognition_validation import compare as CMP, recorder as REC
root, out, contract = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
ordinals, records = {}, []
for call in REC.read_calls(root):
    key = (call["settled_cutoff"], call["purpose"])
    ordinal = ordinals.get(key, 0); ordinals[key] = ordinal + 1
    if not call["raw_response_ref"]:
        continue
    text = (root / call["input_ref"]["path"]).read_text(encoding="utf-8")
    records.append({"settled_cutoff": call["settled_cutoff"], "cutoff_ordinal": ordinal, "purpose": call["purpose"],
                    "contract_id": contract, "raw_response": (root / call["raw_response_ref"]["path"]).read_text(encoding="utf-8"),
                    "served_model": call["served_model"], "input_digest": call["input_ref"]["sha256"],
                    "input_text": text, "semantic_input_digest": CMP.semantic_input_digest(text),
                    "brain_fingerprint": None, "provider_request_id": None, "provider_response_id": None})
out.write_text(json.dumps(records))
print(len(records))

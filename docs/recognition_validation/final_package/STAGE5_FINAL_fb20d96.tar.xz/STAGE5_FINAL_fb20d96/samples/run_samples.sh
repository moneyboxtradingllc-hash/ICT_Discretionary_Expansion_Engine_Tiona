#!/bin/bash
# Stage 5 CLI sample sequence on the frozen final clone (offline, CONSTRUCTED inputs only).
R="${RUNNER:-./run.sh} ${REPO:?set REPO to a clone of fb20d96}"; I=$(dirname $0)/inputs; O=$(dirname $0)/out; mkdir -p $O
CLI="python3.12 -m recognition_validation"
$R $O/01_validate.log $CLI validate --corpus $I/corpus/corpus.json --run $I/run-B.json; echo "validate rc=$?"
$R $O/02_plan.log $CLI plan --corpus $I/corpus/corpus.json --out $O/plan --prewarm-until 2026-08-19T15:30:00Z; echo "plan rc=$?"
for n in B1 B2; do $R $O/03_run_$n.log $CLI run --mode B --run $I/run-B.json --corpus $I/corpus/corpus.json --script $I/mode_b_script.py --out $O/$n --prewarm-until 2026-08-19T15:30:00Z --ticks-until 2026-08-19T16:46:00Z; echo "run $n rc=$?"; done
$R $O/04_run_B_ecu.log $CLI run --mode B --run $I/run-B-ecu.json --corpus $I/corpus/corpus.json --script $I/mode_b_script.py --out $O/B_ecu --prewarm-until 2026-08-19T15:30:00Z --ticks-until 2026-08-19T16:46:00Z; echo "run B_ecu rc=$?"
$R $O/05_compare_B1_B2.log $CLI compare --left $O/B1 --right $O/B2 --projection semantic-v1; echo "compare rc=$?"
$R $O/06_harvest.log python3.12 $I/harvest_records.py $O/B1/evidence $O/historical_records.json CON.F.US.MNQ.Z26; echo "harvest rc=$?"
$R $O/07_run_A.log $CLI run --mode A --run $I/run-A.json --corpus $I/corpus/corpus.json --records $O/historical_records.json --out $O/A1 --prewarm-until 2026-08-19T15:30:00Z --ticks-until 2026-08-19T16:46:00Z; echo "run A1 rc=$?"
$R $O/08_compare_B1_A1.log $CLI compare --left $O/B1 --right $O/A1 --projection semantic-v1; echo "compare B1/A1 rc=$?"
for n in B1 B_ecu A1; do $R $O/09_report_$n.log $CLI report --run $O/$n --out $O/report_$n --mode B; echo "report $n rc=$?"; done
$R $O/10_run_C_dry.log $CLI run --mode C --dry-run --run $I/run-C-disabled.json --corpus $I/corpus/corpus.json --out $O/C_dry --prewarm-until 2026-08-19T15:30:00Z; echo "C dry rc=$?"
$R $O/11_run_C_live.log $CLI run --mode C --run $I/run-C-disabled.json --corpus $I/corpus/corpus.json --out $O/C_live; echo "C live rc=$?"

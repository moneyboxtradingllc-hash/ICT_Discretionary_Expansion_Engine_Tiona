"""Round 2: replaces MUT-T26-UNKNOWN-USAGE-FREE, which survived round 1 as an EQUIVALENT mutant
(unknown usage is charged via `charged = reserved if (exceeded or not known)` regardless of `actual`)."""
MUTANTS = [
    ("MUT-T26-UNKNOWN-USAGE-UNDERCHARGED", "src/recognition_validation/model_authority.py",
     'charged = reserved if (exceeded or not known) else actual',
     'charged = reserved if exceeded else (actual if known else Decimal(0))',
     "tests/test_recognition_model_authority.py::test_unknown_usage_charges_reservation_and_overrun_halts_the_run"),
]

import json, shutil, subprocess, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from mutants import MUTANTS
src, work, runner, out = map(Path, sys.argv[1:5])
results = []
for mid, path, old, new, node in MUTANTS:
    target = work / mid
    shutil.rmtree(target, ignore_errors=True)
    shutil.copytree(src, target, ignore=shutil.ignore_patterns(".git", "__pycache__"))
    f = target / path
    text = f.read_text()
    assert text.count(old) == 1, (mid, "anchor not unique/absent")
    f.write_text(text.replace(old, new))
    log = out / f"{mid}.log"
    rc = subprocess.run([str(runner), str(target), str(log), "python3.12", "-m", "pytest", "-q", "-p", "no:cacheprovider",
                         "-x", node], capture_output=True, text=True).returncode
    body = log.read_text()
    assertion = next((l for l in body.splitlines() if l.startswith("E ")), None)
    failed = [l for l in body.splitlines() if l.startswith("FAILED")]
    results.append({"mutant": mid, "file": path, "test": node, "exit": rc, "killed": rc != 0 and bool(failed),
                    "first_E_line": assertion, "failed": failed})
    shutil.rmtree(target)
(out / "mutant_results.json").write_text(json.dumps(results, indent=1))
for r in results: print(r["mutant"], "KILLED" if r["killed"] else "SURVIVED", "|", r["first_E_line"])

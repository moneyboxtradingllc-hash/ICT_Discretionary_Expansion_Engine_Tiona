import sys
from datetime import datetime, timedelta
sys.path.insert(0, '/tmp/claude-0/-home-user-ICT-Discretionary-Expansion-Engine-Tiona/4c1b4a67-6e49-58ef-be1e-a80c4037fc0a/scratchpad/g5/m4exit/tests')
import test_recognition_current_path as CP
_inner, _state = CP._script()
def script(request):
    reply = _inner(request)
    if reply and reply.get('current_action') == 'propose_entry':
        at = datetime.fromisoformat(request['decision_time'])
        reply = {**reply, 'current_action': 'watching',
                 'plan_expires_at': (at + timedelta(seconds=1800)).isoformat()}
    return reply

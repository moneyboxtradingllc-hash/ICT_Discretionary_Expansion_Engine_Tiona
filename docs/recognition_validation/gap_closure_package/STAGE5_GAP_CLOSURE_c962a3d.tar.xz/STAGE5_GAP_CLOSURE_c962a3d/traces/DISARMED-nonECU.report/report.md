# Stage 5 report: result:S5-GAP-DISARMED-nonECU

- mode: B; engineering: COMPLETE; final: READY_FOR_OWNER_REVIEW
- current Brain recognition: **UNPROVEN**; historical archive certification: UNPROVEN
- external requests: 0; production authorized: False

## Missing prerequisites

- RULE_COVERAGE_UNDECLARED: no ratified rule set and required session/trajectory set were declared
- CURRENT_RECOGNITION_PREREQUISITES: authorized Mode C, sealed owner annotations, ratified scoring plan and owner acceptance refs

## Required rule coverage: UNDECLARED

| session | trajectory | rule metric | decision | num | den | status | reason |
|---|---|---|---|---|---|---|---|

## DAW-CONSTRUCTED-20260819 / S5-GAP-DISARMED-nonECU

inclusion mask: `{"annotation_state": "FICTIONAL", "current_recognition_eligible": false, "mode": "B", "owner_truth": false, "scoring_ratified": false}`

| metric | num | den | excluded | unproven | value | assessment |
|---|---|---|---|---|---|---|
| episodes_with_evidence | 2 | 3 | 0 | 0 | 0.6667 | DIAGNOSTIC |
| recognition_hits | 0 | 0 | 3 | 2 |  | UNSCORED |
| recognition_hits_diagnostic | 1 | 1 | 0 | 2 | 1.0 | DIAGNOSTIC |
| false_positive_entries | 2 | 2 | 0 | 1 | 1.0 | DIAGNOSTIC |
| correct_refusals | 0 | 2 | 0 | 1 | 0.0 | DIAGNOSTIC |
| exact_occurrence_selected | 2 | 3 | 0 | 0 | 0.6667 | DIAGNOSTIC |
| authority_invariant_violations | 0 | 3 | 0 | 0 | 0.0 | DIAGNOSTIC |
| missing_cognition_calls | 0 | 12 | 0 | 0 | 0.0 | DIAGNOSTIC |
| degraded_scans | 59 | 216 | 0 | 0 | 0.2731 | DIAGNOSTIC |
| unique_candidates | 3 | 3 | 0 | 0 | 1.0 | DIAGNOSTIC |
| layer_market_facts | 2 | 2 | 0 | 1 | 1.0 | DIAGNOSTIC |
| layer_campaign | 2 | 2 | 0 | 1 | 1.0 | DIAGNOSTIC |
| layer_delivery | 1 | 1 | 0 | 2 | 1.0 | DIAGNOSTIC |
| layer_tool | 2 | 2 | 0 | 1 | 1.0 | DIAGNOSTIC |
| layer_composition | 2 | 2 | 0 | 1 | 1.0 | DIAGNOSTIC |
| layer_timing | 2 | 2 | 0 | 1 | 1.0 | DIAGNOSTIC |

| layer | expected | observed | count | eligible | excluded | unproven | assessment |
|---|---|---|---|---|---|---|---|
| RECOGNITION | bearish | HIT | 1 | 0 | 1 | 0 | DIAGNOSTIC |
| TIMING | within_target | ON_TIME | 1 | 0 | 1 | 0 | DIAGNOSTIC |
| REFUSAL | WATCHING | FALSE_POSITIVE | 1 | 1 | 0 | 0 | DIAGNOSTIC |
| FACT | PO3_REVERSAL_ORDER_BLOCK:CON.F.US.MNQ.Z26:5m:2026-08-19T16:25:00+00:00:bearish:LIQUIDITY_SWEEP:CON.F.US.MNQ.Z26:5m:2026-08-19T16:15:00+00:00:5m:swing_high:29518.5:2026-08-19T16:19:00+00:00 | EXACT_OCCURRENCE | 1 | 1 | 0 | 0 | DIAGNOSTIC |
| RECOGNITION | bearish | unavailable | 1 | 0 | 1 | 1 | UNPROVEN |
| REFUSAL | WATCHING | UNPROVEN | 1 | 0 | 0 | 1 | UNPROVEN |
| FACT | PO3_REVERSAL_ORDER_BLOCK:CON.F.US.MNQ.Z26:5m:2026-08-19T16:25:00+00:00:bearish:LIQUIDITY_SWEEP:CON.F.US.MNQ.Z26:5m:2026-08-19T16:15:00+00:00:5m:swing_high:29518.5:2026-08-19T16:19:00+00:00 | NOT_SELECTED | 1 | 1 | 0 | 0 | DIAGNOSTIC |
| RECOGNITION | bearish | unavailable | 1 | 0 | 1 | 1 | UNPROVEN |
| REFUSAL | WATCHING | FALSE_POSITIVE | 1 | 1 | 0 | 0 | DIAGNOSTIC |
| FACT | PO3_REVERSAL_ORDER_BLOCK:CON.F.US.MNQ.Z26:5m:2026-08-19T16:25:00+00:00:bearish:LIQUIDITY_SWEEP:CON.F.US.MNQ.Z26:5m:2026-08-19T16:15:00+00:00:5m:swing_high:29518.5:2026-08-19T16:19:00+00:00 | EXACT_OCCURRENCE | 1 | 1 | 0 | 0 | DIAGNOSTIC |

| label | observed | first recognition | first candidate | latency s | occurrences |
|---|---|---|---|---|---|
| plan | ENTRY | 2026-08-19T16:29:00+00:00 | 2026-08-19T16:30:00+00:00 | 0.0 | PO3_REVERSAL_ORDER_BLOCK:CON.F.US.MNQ.Z26:5m:2026-08-19T16:25:00+00:00:bearish:LIQUIDITY_SWEEP:CON.F.US.MNQ.Z26:5m:2026-08-19T16:15:00+00:00:5m:swing_high:29518.5:2026-08-19T16:19:00+00:00 |
| quiet | missing |  |  |  |  |
| brainless | ENTRY |  | 2026-08-19T16:32:30+00:00 |  | PO3_REVERSAL_ORDER_BLOCK:CON.F.US.MNQ.Z26:5m:2026-08-19T16:25:00+00:00:bearish:LIQUIDITY_SWEEP:CON.F.US.MNQ.Z26:5m:2026-08-19T16:15:00+00:00:5m:swing_high:29518.5:2026-08-19T16:19:00+00:00 |

### Six-layer projection (16 projected ticks)

| layer | cells | scored | agree | unscored | unproven | reasons | source |
|---|---|---|---|---|---|---|---|
| MARKET_FACTS | 3 | 2 | 2 | 0 | 1 | EVIDENCE_ABSENT:no_settled_projection_in_window | snapshot.timeframes.1m.last_candle |
| CAMPAIGN | 3 | 2 | 2 | 0 | 1 | EVIDENCE_ABSENT:campaign_draw | scan_participation_authority(scan) |
| DELIVERY | 3 | 1 | 1 | 0 | 2 | EVIDENCE_ABSENT:lifecycle; LIFECYCLE_AUTHORITY_UNKNOWN | snapshot.campaign_lifecycle + snapshot.active_path_state |
| TOOL | 3 | 2 | 2 | 0 | 1 | EVIDENCE_ABSENT:no_tool_selected | loop.active_candidate | loop.active_conditional_plan.candidate |
| COMPOSITION | 3 | 2 | 2 | 0 | 1 | EVIDENCE_ABSENT:no_lawful_tick | loop outcome + offline_tick_trace/v1 |
| TIMING | 3 | 2 | 2 | 0 | 1 | EVIDENCE_ABSENT:no_matching_projection | projection TIMING + CAMPAIGN |

| label | layer | expected | observed | state | agree | reason |
|---|---|---|---|---|---|---|
| plan | MARKET_FACTS | SEALED_SETTLED_FACTS | CONSISTENT | SCORED | True |  |
| plan | CAMPAIGN | bearish | bearish | SCORED | True |  |
| plan | DELIVERY | RETRACEMENT | ACTIVE_DELIVERY | SCORED | True |  |
| plan | TOOL | PO3_REVERSAL_ORDER_BLOCK:CON.F.US.MNQ.Z26:5m:2026-08-19T16:25:00+00:00:bearish:LIQUIDITY_SWEEP:CON.F.US.MNQ.Z26:5m:2026-08-19T16:15:00+00:00:5m:swing_high:29518.5:2026-08-19T16:19:00+00:00 | PO3_REVERSAL_ORDER_BLOCK:CON.F.US.MNQ.Z26:5m:2026-08-19T16:25:00+00:00:bearish:LIQUIDITY_SWEEP:CON.F.US.MNQ.Z26:5m:2026-08-19T16:15:00+00:00:5m:swing_high:29518.5:2026-08-19T16:19:00+00:00 | SCORED | True |  |
| plan | COMPOSITION | WATCHING | ENTRY | SCORED | True |  |
| plan | TIMING | within_target | ON_TIME | SCORED | True |  |
| quiet | MARKET_FACTS | SEALED_SETTLED_FACTS | unavailable | UNPROVEN |  | EVIDENCE_ABSENT:no_settled_projection_in_window |
| quiet | CAMPAIGN | bearish | unavailable | UNPROVEN |  | EVIDENCE_ABSENT:campaign_draw |
| quiet | DELIVERY | RETRACEMENT | unavailable | UNPROVEN |  | EVIDENCE_ABSENT:lifecycle |
| quiet | TOOL | PO3_REVERSAL_ORDER_BLOCK:CON.F.US.MNQ.Z26:5m:2026-08-19T16:25:00+00:00:bearish:LIQUIDITY_SWEEP:CON.F.US.MNQ.Z26:5m:2026-08-19T16:15:00+00:00:5m:swing_high:29518.5:2026-08-19T16:19:00+00:00 | no_tool_selected | UNPROVEN |  | EVIDENCE_ABSENT:no_tool_selected |
| quiet | COMPOSITION | WATCHING | unavailable | UNPROVEN |  | EVIDENCE_ABSENT:no_lawful_tick |
| quiet | TIMING | within_target | unavailable | UNPROVEN |  | EVIDENCE_ABSENT:no_matching_projection |
| brainless | MARKET_FACTS | SEALED_SETTLED_FACTS | CONSISTENT | SCORED | True |  |
| brainless | CAMPAIGN | bearish | bearish | SCORED | True |  |
| brainless | DELIVERY | RETRACEMENT | UNKNOWN_JUDGMENT | UNPROVEN |  | LIFECYCLE_AUTHORITY_UNKNOWN |
| brainless | TOOL | PO3_REVERSAL_ORDER_BLOCK:CON.F.US.MNQ.Z26:5m:2026-08-19T16:25:00+00:00:bearish:LIQUIDITY_SWEEP:CON.F.US.MNQ.Z26:5m:2026-08-19T16:15:00+00:00:5m:swing_high:29518.5:2026-08-19T16:19:00+00:00 | PO3_REVERSAL_ORDER_BLOCK:CON.F.US.MNQ.Z26:5m:2026-08-19T16:25:00+00:00:bearish:LIQUIDITY_SWEEP:CON.F.US.MNQ.Z26:5m:2026-08-19T16:15:00+00:00:5m:swing_high:29518.5:2026-08-19T16:19:00+00:00 | SCORED | True |  |
| brainless | COMPOSITION | WATCHING | ENTRY | SCORED | True |  |
| brainless | TIMING | within_target | ON_TIME | SCORED | True |  |

Findings: `{"duplicate_cognition_cutoffs": 0, "missed_scans": 0, "restarts": 0, "revisions": 0}`

Limitations:

- ANNOTATION_FICTIONAL: descriptive only, never benchmark truth
- MODE_B: mechanics only; current discretionary recognition UNPROVEN
- SCORING_NOT_RATIFIED: no thresholds; assessments DIAGNOSTIC

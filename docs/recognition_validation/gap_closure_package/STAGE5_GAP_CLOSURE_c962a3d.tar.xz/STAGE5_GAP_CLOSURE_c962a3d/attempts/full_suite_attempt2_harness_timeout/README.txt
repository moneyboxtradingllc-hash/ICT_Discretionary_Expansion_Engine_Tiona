Stopped at 68% (0 failures so far) by the session's 2-hour background-command limit at ~06:45Z; not a test outcome.

Detached single-process run killed at ~5% by a container restart (uptime 0 min at 07:35Z).

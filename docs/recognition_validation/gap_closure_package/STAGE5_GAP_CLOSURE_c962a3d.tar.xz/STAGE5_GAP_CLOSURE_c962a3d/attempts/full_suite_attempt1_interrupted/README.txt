Interrupted at ~2% by a container restart (no pytest process, no finish marker at 04:45Z).

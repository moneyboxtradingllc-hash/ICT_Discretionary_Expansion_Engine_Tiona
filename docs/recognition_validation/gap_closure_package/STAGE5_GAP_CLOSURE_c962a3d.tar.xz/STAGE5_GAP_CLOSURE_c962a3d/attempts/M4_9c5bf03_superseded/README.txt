9c5bf03 (unpushed, local only): first frozen focused run 4 failed / 243 passed; superseded by the rebuilt GAP_M4 commit

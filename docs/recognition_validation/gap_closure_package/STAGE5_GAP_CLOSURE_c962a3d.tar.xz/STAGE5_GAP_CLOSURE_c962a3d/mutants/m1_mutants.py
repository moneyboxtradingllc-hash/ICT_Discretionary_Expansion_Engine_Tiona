"""Mission 1 activated source mutants: copy the candidate tree, apply one edit, run the coverage tests."""
import pathlib, shutil, subprocess, sys
S = pathlib.Path(sys.argv[1]); repo = S / "g5/repo"; out = S / "g5/mutants"
MUTANTS = {
  "MUT-M1-THRESHOLD-DROPS-ZERO-DENOMINATOR": ("src/recognition_validation/scoring.py",
     "    if not (inclusion.ratified and inclusion.current_recognition):\n        return metric\n    for rule",
     "    if not (inclusion.ratified and inclusion.current_recognition) or metric[\"denominator\"] == 0:\n        return metric\n    for rule"),
  "MUT-M1-COVERAGE-DROPS-UNSCORED-OBLIGATION": ("src/recognition_validation/report.py",
     "    return {\"declared\": declared, \"status\": coverage_status(declared, obligations),",
     "    obligations = [o for o in obligations if o[\"status\"] != \"UNPROVEN\"]\n    return {\"declared\": declared, \"status\": coverage_status(declared, obligations),"),
  "MUT-M1-VALIDATOR-SKIPS-OBLIGATION-SET": ("src/recognition_validation/contracts.py",
     "            require(expected == actual, \"RULE_OBLIGATION_SET_INCOMPLETE\", \"/rule_coverage/obligations\")",
     "            pass"),
  "MUT-M1-ZERO-DENOMINATOR-COUNTS-AS-PASS": ("src/recognition_validation/report.py",
     "        return {**base, \"status\": \"UNPROVEN\", \"reason\": \"ZERO_DENOMINATOR\"}",
     "        return {**base, \"status\": \"PASS\", \"reason\": None}"),
}
for name, (path, old, new) in MUTANTS.items():
    work = out / ("work_" + name)
    if work.exists(): shutil.rmtree(work)
    shutil.copytree(repo, work, symlinks=True)
    target = work / path; text = target.read_text()
    assert text.count(old) == 1, name
    target.write_text(text.replace(old, new))
    log = out / f"{name}.log"
    rc = subprocess.run([str(S / "g5/run.sh"), str(work), str(log), "python3", "-m", "pytest", "-q", "-p",
                         "no:cacheprovider", "-rfE", "tests/test_recognition_rule_coverage.py"]).returncode
    print(name, "KILLED" if rc != 0 else "SURVIVED", rc)
    shutil.rmtree(work)

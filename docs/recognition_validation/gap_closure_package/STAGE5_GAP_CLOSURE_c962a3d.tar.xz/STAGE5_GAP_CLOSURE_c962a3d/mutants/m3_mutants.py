"""Mission 3 activated source mutants: copy the candidate tree, apply one edit, run the selected M3 tests."""
import pathlib, shutil, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
S = pathlib.Path(sys.argv[1]); repo = pathlib.Path(sys.argv[2]); out = S / "g5/mutants"
DRV = "src/recognition_validation/driver.py"
T = "tests/test_recognition_quote_wake_trigger.py"
MUTANTS = {
  # The parent defect: every tick is an ordinary scan; the plan's own wake never reaches the trigger.
  "MUT-M3-SCAN-ONLY-ROUTE": (DRV, "    out = loop.handle_pending_conditional_wake()\n",
                             "    out = None\n", "healthy and DISARMED"),
  # Quotes reach the hub but never the registry (no live-provider _on_quote equivalent).
  "MUT-M3-QUOTE-SKIPS-REGISTRY": (DRV, "    if organism.loop.candles.wake_registry is not None:\n        organism.registry.on_quote(",
                                  "    if False:\n        organism.registry.on_quote(", "healthy and DISARMED and non"),
  # The armed loop leaks into the disarmed lane.
  "MUT-M3-ARMED-EVERY-LANE": (DRV, '        armed=venue_lane == "REFUSING_VENUE_DOUBLE",', "        armed=True,",
                              "healthy and DISARMED and non"),
  # Mode C may run against the armed loop.
  "MUT-M3-NO-MODE-C-LANE-GUARD": (DRV, '    C.require(venue_lane == "DISARMED" or getattr(responder, "origin", "MOCK") in ("MOCK", "HISTORICAL"),',
                                  '    C.require(True or getattr(responder, "origin", "MOCK") in ("MOCK", "HISTORICAL"),',
                                  "mode_c"),
  # A quote wake without a stream silently falls back to settled closes.
  "MUT-M3-WAKE-WITHOUT-STREAM": (DRV, '    C.require(quote_port is not None or not any(t.kind == "QUOTE_WAKE" for t in ticks),',
                                 '    C.require(True or not any(t.kind == "QUOTE_WAKE" for t in ticks),', "explicit_quote_stream"),
  # Report forgets the lane: a refusing-venue write becomes an offline violation (and the converse).
  "MUT-M3-REPORT-IGNORES-LANE": ("src/recognition_validation/report.py",
                                 '    if manifest and manifest.get("venue_writes") and manifest.get("venue_lane", "DISARMED") == "DISARMED":',
                                 '    if manifest and manifest.get("venue_writes"):', "venue_write"),
}


def one(item):
    name, (path, old, new, select) = item
    work = out / ("work_" + name)
    if work.exists():
        shutil.rmtree(work)
    shutil.copytree(repo, work, symlinks=True)
    target = work / path; text = target.read_text()
    assert text.count(old) == 1, name
    target.write_text(text.replace(old, new))
    log = out / f"{name}.log"
    rc = subprocess.run([str(S / "g5/run.sh"), str(work), str(log), "python3", "-m", "pytest", "-q", "-p",
                         "no:cacheprovider", "-rfE", T, "-k", select]).returncode
    shutil.rmtree(work)
    return name, rc


with ThreadPoolExecutor(3) as pool:
    for name, rc in pool.map(one, MUTANTS.items()):
        print(name, "KILLED" if rc == 1 else f"SURVIVED_OR_ERROR rc={rc}", flush=True)

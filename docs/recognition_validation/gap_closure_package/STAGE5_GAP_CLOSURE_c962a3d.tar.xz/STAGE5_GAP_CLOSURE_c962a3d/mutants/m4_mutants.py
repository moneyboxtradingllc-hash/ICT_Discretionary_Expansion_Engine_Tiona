"""Mission 4 activated source mutants: copy the candidate tree, apply one edit, run the selected M4 tests."""
import pathlib, shutil, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
S = pathlib.Path(sys.argv[1]); repo = pathlib.Path(sys.argv[2]); out = S / "g5/mutants"
LY = "src/recognition_validation/layers.py"
T = "tests/test_recognition_layer_projection.py"
MUTANTS = {
  # Local opposing movement (an up bar in a bearish campaign) is read as a reversal.
  "MUT-M4-LOCAL-MOVE-IS-REVERSAL": (LY, '            mapped = LIFECYCLE_DELIVERY.get(lifecycle.get("state"), "UNKNOWN")',
      '            mapped = ("REVERSAL_DEVELOPING" if isinstance(last, dict) and direction == "bearish"\n'
      '                      and _num(last.get("close")) > _num(last.get("open"))\n'
      '                      else LIFECYCLE_DELIVERY.get(lifecycle.get("state"), "UNKNOWN"))', "healthy_labels"),
  # A judgment before availability is no longer flagged early.
  "MUT-M4-EARLY-NOT-FLAGGED": (LY, "    early = [p for p in matching if", "    early = [] and [p for p in matching if",
                               "timing_mutations"),
  # A no-trade is scored as wrong.
  "MUT-M4-NO-TRADE-IS-WRONG": (LY, 'observed="NO_TRADE", state="UNSCORED",',
                               'observed="NO_TRADE", state="SCORED", agreement=False,', "no_trade"),
  # Facts are never checked against the sealed corpus.
  "MUT-M4-FACTS-NOT-SEALED-CHECKED": (LY, "        if stream is not None:\n            sealed",
                                      "        if False:\n            sealed", "fact-not-sealed or another_corpus"),
  # Missed scans are not found.
  "MUT-M4-MISSED-SCAN-HIDDEN": (LY, "            if last_scan is not None and _at(cutoff) - _at(last_scan) > BAR:",
                                "            if False:", "missed_scans"),
  # Prefix eviction is ignored.
  "MUT-M4-PREFIX-EVICTION-IGNORED": (LY, '        evicted = camp.get("history_start") and any(',
                                     "        evicted = False and any(", "prefix-eviction"),
  # The scorer drops projection chronology violations.
  "MUT-M4-SCORER-DROPS-VIOLATIONS": ("src/recognition_validation/scoring.py",
                                     '        violations += [f"{code}:tick:', '        violations += [] and [f"{code}:tick:',
                                     "another_corpus"),
  # The driver stops writing projections.
  "MUT-M4-DRIVER-WRITES-NO-PROJECTION": ("src/recognition_validation/driver.py",
                                         "                    refs.append(recorder.json_artifact(_jsonable(LY.project(",
                                         "                    0 and refs.append(recorder.json_artifact(_jsonable(LY.project(",
                                         "healthy_trajectory and DISARMED and non"),
}


def one(item):
    name, (path, old, new, select) = item
    work = out / ("work_" + name)
    if work.exists():
        shutil.rmtree(work)
    shutil.copytree(repo, work, symlinks=True)
    target = work / path; text = target.read_text()
    assert text.count(old) == 1, name
    target.write_text(text.replace(old, new))
    log = out / f"{name}.log"
    rc = subprocess.run([str(S / "g5/run.sh"), str(work), str(log), "python3", "-m", "pytest", "-q", "-p",
                         "no:cacheprovider", "-rfE", T, "-k", select]).returncode
    shutil.rmtree(work)
    return name, rc


with ThreadPoolExecutor(3) as pool:
    for name, rc in pool.map(one, MUTANTS.items()):
        print(name, "KILLED" if rc == 1 else f"SURVIVED_OR_ERROR rc={rc}", flush=True)

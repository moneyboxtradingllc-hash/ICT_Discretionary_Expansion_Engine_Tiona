"""Mission 2 activated source mutants: copy the candidate tree, apply one edit, run the isolation tests."""
import pathlib, shutil, subprocess, sys
S = pathlib.Path(sys.argv[1]); repo = S / "g5/repo"; out = S / "g5/mutants"
MUTANTS = {
  # The parent defect: run the trajectory inside the orchestrating interpreter.
  "MUT-M2-SAME-PROCESS-TRAJECTORY": ("src/recognition_validation/child.py",
     "        completed = subprocess.run(command, cwd=child_root, env=env, capture_output=True, timeout=timeout_seconds,\n                                   stdin=subprocess.DEVNULL)",
     "        code = child_main(str(request_path))\n        completed = subprocess.CompletedProcess(command, code, b\"\", b\"\")"),
  # Inherit the (contaminated, credential-bearing) parent environment.
  "MUT-M2-INHERITS-PARENT-ENV": ("src/recognition_validation/child.py",
     "    env.update(extra_env or {})  # test hook for the refusal controls; the CLI never passes it",
     "    env = dict(os.environ, **env)"),
  # Report trusts the sealed manifest and ignores the parent-side child status.
  "MUT-M2-REPORT-IGNORES-CHILD-STATUS": ("src/recognition_validation/__main__.py",
     "    problems = (CH.verify_child_status(root, manifest or {})",
     "    problems = [] and (CH.verify_child_status(root, manifest or {})"),
}
for name, (path, old, new) in MUTANTS.items():
    work = out / ("work_" + name)
    if work.exists(): shutil.rmtree(work)
    shutil.copytree(repo, work, symlinks=True)
    target = work / path; text = target.read_text()
    assert text.count(old) == 1, name
    target.write_text(text.replace(old, new))
    log = out / f"{name}.log"
    rc = subprocess.run([str(S / "g5/run.sh"), str(work), str(log), "python3", "-m", "pytest", "-q", "-p",
                         "no:cacheprovider", "-rfE", "tests/test_recognition_process_isolation.py"]).returncode
    print(name, "KILLED" if rc != 0 else "SURVIVED", rc, flush=True)
    shutil.rmtree(work)

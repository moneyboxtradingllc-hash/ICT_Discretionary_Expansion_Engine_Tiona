"""GAP_M4 parent reproducer: do the campaign/delivery/tool truth fields change any score?"""
import json, sys
from pathlib import Path
repo = Path(sys.argv[1]); out = Path(sys.argv[2])
sys.path[:0] = [str(repo / "src"), str(repo / "tests")]
import test_recognition_quote_wake_trigger as M3
import test_recognition_scoring_cli as SCLI
from recognition_validation import brain_gateway as G, corpus as K, driver as DR, scoring as SC, recorder as REC
corpus = M3._corpus(out, "HEALTHY")
s = DR.run_offline(corpus_path=corpus, session_id=M3.CP.SESSION, out_root=out / "run", ecu=False, trajectory_id="REPRO",
                   ticks=M3._ticks(corpus, "HEALTHY"), quote_policy="CONSTRUCTED", venue_lane="DISARMED",
                   responder=G.ScriptedResponder(M3._watching_script(1800), fixture_digest="repro"))
ev = Path(s["evidence_root"]); digest = K.load_corpus(corpus).digest
def ev_ref(kind, event_id, level=None, source_time=None):
    return {"kind": kind, "event_id": event_id, "timeframe": None, "source_time": source_time, "available_at": None,
            "level": level, "unresolved_reason": None}
right = SCLI._label("right", "16:29", "16:35", action="WATCHING")
right.update(delivery_state="RETRACEMENT", playbook_family="manipulation_to_distribution",
             campaign_objective=[ev_ref("opposing_external_liquidity", "opposing_external_liquidity:sellside@29505.5")])
wrong = dict(right, label_id="wrong", delivery_state="TRANSFER_CONFIRMED", playbook_family="some_other_playbook",
             campaign_objective=[ev_ref("opposing_external_liquidity", "buyside@29600.0")])
out_rows = {}
for label in (right, wrong):
    scored = SC.score_trace(ev, mode="B", session_id=M3.CP.SESSION, trajectory_id="REPRO",
                            annotation=SCLI._annotation({"digest": digest}, [label]))
    summary = scored["summary"]
    cells = sorted((c["layer"], c["expected"], c["observed"]) for c in summary["confusion_cells"])
    layer = sorted((c["layer"], c["state"], c["agreement"], c["observed"]) for c in summary.get("layer_cells", []))
    out_rows[label["label_id"]] = {"confusion_cells": cells, "layer_cells": layer,
                                   "metrics": sorted(m["name"] for m in summary["metrics"])}
    print(label["label_id"].upper(), json.dumps(out_rows[label["label_id"]]))
projections = [r for e in REC.read_events(ev) for r in e["evidence_refs"]]
print("EVIDENCE_REFS_PER_EVENT", sorted({len(e["evidence_refs"]) for e in REC.read_events(ev)}))
print("TRUTH_FIELDS_CHANGE_SCORE", out_rows["right"]["confusion_cells"] != out_rows["wrong"]["confusion_cells"]
      or out_rows["right"]["layer_cells"] != out_rows["wrong"]["layer_cells"])

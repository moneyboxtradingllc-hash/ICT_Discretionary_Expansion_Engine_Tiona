import sys, socket, tempfile, json
from pathlib import Path
sys.path.insert(0, str(Path.cwd() / 'src'))
def deny(*a, **k): raise RuntimeError('OFFLINE_NETWORK_DENIED')
socket.socket.connect = deny; socket.socket.connect_ex = deny
socket.create_connection = deny; socket.getaddrinfo = deny
from recognition_validation import driver as D
from ai_brain import narrative_brain as N
N._open_hard_quota_circuit('CONSTRUCTED_PRIOR_TRAJECTORY')
before = N.provider_circuit_state()
with D.isolation(Path(tempfile.mkdtemp(prefix='constructed-isolation-')), ecu=False):
    inside = N.provider_circuit_state()
assert before['open'] and inside['open']  # parent defect

print(json.dumps({'before':before,'inside':inside,'fresh_process_isolated':False}))

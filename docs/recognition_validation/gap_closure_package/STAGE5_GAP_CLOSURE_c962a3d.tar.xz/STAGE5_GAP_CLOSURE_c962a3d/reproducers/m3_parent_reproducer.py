"""GAP_M3 parent reproducer (run against the frozen parent worktree 2c063d0)."""
import json, sys
from datetime import datetime, timedelta
from pathlib import Path
repo = Path(sys.argv[1]); out = Path(sys.argv[2])
sys.path[:0] = [str(repo / "src"), str(repo / "tests")]
import test_po3_distinct_anchor_premise as W
import test_recognition_current_path as CP
from recognition_validation import brain_gateway as G, contracts as C, corpus as K, driver as DR, recorder as REC
print("PARENT_TICK_KINDS", DR.TICK_KINDS)
print("PARENT_HAS_VENUE_LANES", hasattr(DR, "VENUE_LANES"))
inner, _ = CP._script()
def script(request):
    reply = inner(request)
    if reply and reply.get("current_action") == "propose_entry":
        at = datetime.fromisoformat(request["decision_time"])
        reply = {**reply, "current_action": "watching", "plan_expires_at": (at + timedelta(seconds=1800)).isoformat()}
    return reply
corpus = K.build_constructed_corpus(out / "corpus", session_id=CP.SESSION, contract_id=CP.CONTRACT, market_date="2026-08-19",
    tape=W._tape(W._HEALTHY), warmup_end="2026-08-19T15:30:00+00:00", notes="parent reproducer", sealed_at="2026-10-17T00:00:00Z")
stream = K.load_corpus(corpus).sessions[CP.SESSION].stream
base = [t for t in DR.minute_schedule(stream, prewarm_until=DR.utc("2026-08-19T16:20:00Z")) if t.decision_time <= DR.utc("2026-08-19T16:35:00Z")]
wake = base + [DR.Tick(len(base), DR.utc("2026-08-19T16:32:30Z"), "QUOTE_WAKE")]
try:
    DR.run_offline(corpus_path=corpus, session_id=CP.SESSION, out_root=out / "wake", ecu=False, trajectory_id="P",
                   ticks=sorted(wake, key=lambda t: t.decision_time), responder=G.ScriptedResponder(script, fixture_digest="p"))
    print("PARENT_QUOTE_WAKE", "ACCEPTED")
except C.ContractError as exc:
    print("PARENT_QUOTE_WAKE_REFUSED", exc.code)
captured = {}
build = DR.build_organism
def remember(**kw):
    captured["o"] = build(**kw); return captured["o"]
DR.build_organism = remember
s = DR.run_offline(corpus_path=corpus, session_id=CP.SESSION, out_root=out / "scan", ecu=False, trajectory_id="P2",
                   ticks=base, responder=G.ScriptedResponder(script, fixture_digest="p"))
loop = captured["o"].loop
print("PARENT_WAKE_REGISTRY", getattr(loop.candles, "wake_registry", "absent"), "ARMED", loop.armed)
rows = []
for e in REC.read_events(Path(s["evidence_root"])):
    if e["observed_at"] >= "2026-08-19T16:29":
        rows.append((e["observed_at"][11:19], e["event_kind"], e["boundary"], e["first_refusal_code"], e["primary_call_count"]))
for r in rows: print("PARENT_EVENT", *r)
plan_events = list(Path(out / "scan").rglob("conditional_plan_events.jsonl"))
events = [json.loads(l)["event"] for p in plan_events for l in p.read_text().splitlines()]
print("PARENT_PLAN_EVENTS", sorted(set(events)))
print("PARENT_TRIGGERS_VIA_WAKE", events.count("trigger_mechanics_scan_completed"))

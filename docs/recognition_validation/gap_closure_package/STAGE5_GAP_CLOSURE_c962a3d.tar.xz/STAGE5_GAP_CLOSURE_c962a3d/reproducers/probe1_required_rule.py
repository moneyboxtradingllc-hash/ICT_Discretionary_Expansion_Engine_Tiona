"""Synthetic unit probe, NOT owner annotations, model output, or ratification."""
from pathlib import Path
import sys,json,socket
root=Path.cwd()
sys.path.insert(0,str(root/'src'))
def deny(*a,**k): raise RuntimeError('INDEPENDENT_AUDIT_NETWORK_DENIED')
socket.socket.connect=deny; socket.getaddrinfo=deny
from recognition_validation import scoring as S
from recognition_validation import report as R
class SyntheticInclusion:
    ratified=True
    current_recognition=True
scoring={'thresholds':[
    {'metric':'recognition_hits','operator':'>=','value':1,'decision_ref':'FICTIONAL-UNIT-RULE-A'},
    {'metric':'false_positive_entries','operator':'<=','value':0,'decision_ref':'FICTIONAL-UNIT-RULE-B'}]}
metrics=[S._threshold(S._metric('recognition_hits',0,0),scoring,SyntheticInclusion()),
         S._threshold(S._metric('false_positive_entries',0,1),scoring,SyntheticInclusion())]
def consume(candidate_metrics):
    summary=dict(session_id='FICTIONAL-UNIT-SESSION',trajectory_id='FICTIONAL-UNIT-TRAJECTORY',
                 scored_episode_count=0,missing_episode_count=1,metrics=candidate_metrics,confusion_cells=[],
                 first_recognition_utc=None,first_candidate_utc=None,first_refusal_code=None,
                 limitations=['CONSTRUCTED unit probe; not owner ground truth or current cognition'])
    item=dict(summary=summary,violations=[],inclusion={'current_recognition_eligible':True},
              external_request_count=0,event_count=1,call_count=0)
    manifest=dict(events=1,tick_count=1,ticks=1,primary_calls=0,repair_calls=0)
    return R.build_result(document_id='FICTIONAL-UNIT-RESULT',run_digest='a'*64,mode='C',scored=[item],
                          manifest=manifest,artifact_refs=[],missing_prerequisites=[],
                          recognition_ratification_ref='FICTIONAL-UNIT-PRECONDITION-ONLY',
                          stage4_owner_acceptance_ref='FICTIONAL-UNIT-PRECONDITION-ONLY')
report=consume(metrics)
control=consume([S._threshold(S._metric('recognition_hits',0,1),scoring,SyntheticInclusion()),metrics[1]])
assert report['current_brain_recognition']=='ELIGIBLE_FOR_OWNER_REVIEW'
assert control['current_brain_recognition']=='FAIL'

print('PARENT_DEFECT_REPRODUCED', report['current_brain_recognition'], control['current_brain_recognition'])

"""Package export: both-lane integrated raw traces + per-layer result/coverage tables from the final commit.

Runs the CONSTRUCTED HEALTHY mission 3/4 world in both venue lanes and both ECU modes through
the CLI child (`run`), then `report` with one FICTIONAL engineering label set and the sealed corpus.
MOCK Brain, offline, disarmed edges; no model, provider, venue or network.
"""
import json, shutil, sys
from pathlib import Path
repo = Path(sys.argv[1]); out = Path(sys.argv[2])
sys.path[:0] = [str(repo / "src"), str(repo / "tests")]
import test_recognition_quote_wake_trigger as M3
import test_recognition_layer_projection as M4
import test_recognition_scoring_cli as SCLI
from recognition_validation import __main__ as CLI, contracts as C, corpus as K
out.mkdir(parents=True, exist_ok=False)
corpus_path = M3._corpus(out / "world", "HEALTHY")
corpus = K.load_corpus(corpus_path)
labels = [M4._label(), M4._label("quiet", "15:40", "15:50"),
          M4._label("brainless", "16:31", "16:33")]
annotation = SCLI._annotation({"digest": corpus.digest}, labels)
(out / "annotation.FICTIONAL.json").write_text(json.dumps(annotation, indent=1))
script = out / "watching_script.py"
script.write_text("import sys\nfrom datetime import datetime, timedelta\n"
                  f"sys.path.insert(0, {str(repo / 'tests')!r})\n"
                  "import test_recognition_current_path as CP\n"
                  "_inner, _state = CP._script()\n"
                  "def script(request):\n"
                  "    reply = _inner(request)\n"
                  "    if reply and reply.get('current_action') == 'propose_entry':\n"
                  "        at = datetime.fromisoformat(request['decision_time'])\n"
                  "        reply = {**reply, 'current_action': 'watching',\n"
                  "                 'plan_expires_at': (at + timedelta(seconds=1800)).isoformat()}\n"
                  "    return reply\n")
summary = {}
for lane in ("DISARMED", "REFUSING_VENUE_DOUBLE"):
    for ecu in (False, True):
        name = f"{lane}-{'ECU' if ecu else 'nonECU'}"
        world = {"corpus_path": corpus_path, "digest": corpus.digest}
        run_path = SCLI._run_doc(world, out / f"{name}.run.json", ecu=ecu, trajectory_id=f"S5-GAP-{name}", venue_lane=lane)
        doc = json.loads(run_path.read_text())
        schedule_path = run_path.parent / doc["schedule_ref"]["path"]
        schedule = json.loads(schedule_path.read_text())
        schedule.update(ticks=[{"session_id": M3.CP.SESSION, "ordinal": t.ordinal, "decision_time_utc": t.decision_time.isoformat(),
                                "kind": t.kind, "source_ref": None} for t in M3._ticks(corpus_path, "HEALTHY")], seal=None)
        schedule["seal"] = {"sha256": C.seal_digest(schedule), "sealed_at": "2026-10-17T00:00:00Z", "sealer_ref": "TEST_ONLY"}
        data = C.canonical(schedule); schedule_path.write_bytes(data)
        doc["schedule_ref"] = {"path": schedule_path.name, "sha256": C.sha256_hex(data), "bytes": len(data), "origin": "CONSTRUCTED"}
        C.validate(doc); run_path.write_text(json.dumps(doc))
        rc_run = CLI.main(["run", "--mode", "B", "--run", str(run_path), "--corpus", str(corpus_path),
                           "--out", str(out / name), "--script", str(script)])
        rc_report = CLI.main(["report", "--run", str(out / name), "--out", str(out / f"{name}.report"),
                              "--annotations", str(out / "annotation.FICTIONAL.json"), "--corpus", str(corpus_path)])
        result = json.loads((out / f"{name}.report" / "result.json").read_text())
        s = result["session_summaries"][0]
        summary[name] = {"run_exit": rc_run, "report_exit": rc_report, "final_status": result["final_status"],
                         "engineering_status": result["engineering_status"],
                         "current_brain_recognition": result["current_brain_recognition"],
                         "invariant_failures": result["invariant_failures"],
                         "layer_projection_count": s["layer_projection_count"], "layer_table": s["layer_table"]}
(out / "EXPORT_SUMMARY.json").write_text(json.dumps(summary, indent=1))
print(json.dumps({k: (v["run_exit"], v["report_exit"], v["final_status"], v["invariant_failures"]) for k, v in summary.items()}))

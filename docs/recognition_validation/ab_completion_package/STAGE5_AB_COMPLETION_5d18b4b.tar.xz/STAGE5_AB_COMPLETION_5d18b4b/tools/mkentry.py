"""Compute a ledger entry for <repo> <parent_sha> <entry_json_template> -> prints entry JSON."""
import json,sys
from pathlib import Path
repo=Path(sys.argv[1]); sys.path.insert(0,str(repo/'tools'))
import verify_engineering_ledger as v
r=v.Repo(repo); parent=sys.argv[2]; tmpl=json.loads(Path(sys.argv[3]).read_text())
pins=json.loads((repo/v.PINS_PATH).read_text())
prot=v.protected_at(r,parent,pins['protected_sources']); clo=v.closure_at(r,parent)
assert prot==dict(sorted(pins['protected_sources'].items()))
brain,retr=v.fingerprints_at(r,parent)
e={"schema":v.ENTRY_SCHEMA,"mission_id":tmpl["mission_id"],"parent_sha":parent,
   "parent_tree":r.git("rev-parse",parent+"^{tree}").strip(),"parent_tracked_status":"",
   "brain_fingerprint":brain,"retrieval_fingerprint":retr,
   "closure_count":len(clo),"closure_digest":v.sha256(v.canonical(clo)),
   "protected_count":len(prot),"protected_digest":v.sha256(v.canonical(prot))}
for k,val in tmpl.items():
    if k!="mission_id": e[k]=val
ents=v.parse_entries((repo/v.LEDGER_PATH).read_text()) if (repo/v.LEDGER_PATH).exists() else []
e["predecessor_receipt_digest"]=ents[-1]["receipt_digest"] if ents else None
e.pop("receipt_digest",None); e["receipt_digest"]=v.receipt_digest(e)
print(json.dumps(e,indent=2))

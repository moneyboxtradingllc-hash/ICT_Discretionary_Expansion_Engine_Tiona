"""Child-environment reproducer: python -I parent_repro.py <worktree> -> JSON on stdout."""
import json, sys, tempfile, inspect
from pathlib import Path
sys.path.insert(0, str(Path(sys.argv[1]) / "src"))
from recognition_validation import child as CH
root = Path(tempfile.mkdtemp()) / "child"
params = inspect.signature(CH.child_environment).parameters
win = dict(platform="nt", environ={"SYSTEMROOT": r"C:\Windows"}, which=lambda n: r"C:\Program Files\Git\cmd\git.exe")
env = CH.child_environment(root, ecu=False, **(win if "platform" in params else {}))
sep = ";" if "platform" in params else ":"
out = {"worktree": sys.argv[1], "builder_accepts_platform": "platform" in params,
       "windows_child_path": env["PATH"].split(sep),
       "windows_child_has_SYSTEMROOT": "SYSTEMROOT" in env,
       "git_dir_reachable": r"C:\Program Files\Git\cmd" in env["PATH"].split(sep),
       "allowlist_admits_SYSTEMROOT_on_windows": "SYSTEMROOT" in (CH.env_allowlist("nt") if hasattr(CH, "env_allowlist") else CH.ENV_ALLOWLIST),
       "posix_allowlist_admits_SYSTEMROOT": "SYSTEMROOT" in CH.ENV_ALLOWLIST}
print(json.dumps(out, indent=1))

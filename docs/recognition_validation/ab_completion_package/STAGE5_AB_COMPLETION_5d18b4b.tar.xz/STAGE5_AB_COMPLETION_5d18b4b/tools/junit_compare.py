"""Summarize a JUnit XML and compare its collected set with a previous run's JUnit.

usage: junit_compare.py <new.xml> <prev.xml> <out_dir>
"""
import json, sys
import xml.etree.ElementTree as ET
from pathlib import Path


def load(path):
    root = ET.parse(path).getroot()
    suite = root if root.tag == "testsuite" else root.find("testsuite")
    cases = {}
    for case in suite.iter("testcase"):
        node = f"{case.get('classname')}::{case.get('name')}"
        status = "passed"
        for tag in ("failure", "error", "skipped"):
            el = case.find(tag)
            if el is not None:
                status = tag
                cases[node] = (status, (el.get("message") or "")[:300])
                break
        else:
            cases[node] = (status, None)
    return dict(suite.attrib), cases


new_attrs, new = load(sys.argv[1])
prev_attrs, prev = load(sys.argv[2])
out = Path(sys.argv[3]); out.mkdir(parents=True, exist_ok=True)
count = lambda cases: {s: sum(1 for v in cases.values() if v[0] == s) for s in ("passed", "skipped", "failure", "error")}
summary = {"testsuite_attrs": new_attrs, "cases": len(new), "status": count(new),
           "failures": [{"node": n, "kind": s, "message": m} for n, (s, m) in sorted(new.items()) if s in ("failure", "error")]}
(out / "junit_summary.json").write_text(json.dumps(summary, indent=1))
added, removed = sorted(set(new) - set(prev)), sorted(set(prev) - set(new))
changed = sorted((n, prev[n][0], new[n][0]) for n in set(new) & set(prev) if prev[n][0] != new[n][0])
skip_new = sorted(n for n, v in new.items() if v[0] == "skipped"); skip_prev = sorted(n for n, v in prev.items() if v[0] == "skipped")
comparison = {"previous": {"attrs": prev_attrs, "cases": len(prev), "status": count(prev)},
              "final": {"attrs": new_attrs, "cases": len(new), "status": count(new)},
              "added_cases": added, "removed_cases": removed, "status_changes": changed,
              "skipped_identical": skip_new == skip_prev,
              "skipped_added": sorted(set(skip_new) - set(skip_prev)), "skipped_removed": sorted(set(skip_prev) - set(skip_new))}
(out / "collection_comparison.json").write_text(json.dumps(comparison, indent=1))
print(json.dumps({"final": comparison["final"]["status"], "cases": len(new), "previous": comparison["previous"]["status"],
                  "added": len(added), "removed": len(removed), "status_changes": changed,
                  "skipped_identical": comparison["skipped_identical"], "failures": [f["node"] for f in summary["failures"]]}, indent=1))

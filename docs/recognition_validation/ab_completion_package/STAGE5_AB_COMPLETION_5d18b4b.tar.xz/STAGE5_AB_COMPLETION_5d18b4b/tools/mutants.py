"""Activate each broken-invariant mutant in a scratch copy of child.py; the fast portability tests must fail."""
import shutil, subprocess, sys, json
from pathlib import Path
wt = Path(sys.argv[1]); out = Path(sys.argv[2])
src = wt / "src/recognition_validation/child.py"; orig = src.read_text()
M = {
 "no_systemroot": ('            env["SYSTEMROOT"] = environ["SYSTEMROOT"]', '            pass'),
 "no_git_dir": ('        dirs.append(paths.dirname(git))', '        pass'),
 "posix_allowlist_widened": ('if platform == "nt" else _POSIX_ENV_NAMES', 'if True else _POSIX_ENV_NAMES'),
 "inherit_parent_environment": ('    for key in RUNTIME_ROOTS:\n        env[key] = str(child_root.parent', '    env.update({k: v for k, v in environ.items() if k != "SYSTEMROOT"} if platform == "nt" else {})\n    for key in RUNTIME_ROOTS:\n        env[key] = str(child_root.parent'),
 "unix_dirs_on_windows": ('    if platform == "nt":\n        dirs +=', '    if False:\n        dirs +='),
}
res = {}
try:
    for name, (a, b) in M.items():
        assert orig.count(a) == 1, name
        src.write_text(orig.replace(a, b))
        r = subprocess.run([sys.executable, "-m", "pytest", "-p", "no:cacheprovider", "-q", "-x",
                            "tests/test_recognition_child_portability.py", "-k", "not run_in_child and not widen"],
                           cwd=wt, capture_output=True, text=True)
        tail = r.stdout.strip().splitlines()[-1]
        failed = [l.split(" ")[1] for l in r.stdout.splitlines() if l.startswith("FAILED")]
        res[name] = {"killed": r.returncode != 0, "summary": tail, "failed": failed}
finally:
    src.write_text(orig)
out.write_text(json.dumps(res, indent=1)); print(json.dumps(res, indent=1))

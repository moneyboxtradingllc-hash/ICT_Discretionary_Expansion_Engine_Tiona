from pathlib import Path
import json,collections,hashlib,subprocess,os,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent;repo=r/'repo'
os.environ.update(GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=repo.as_posix(),GIT_CONFIG_KEY_1='safe.directory',GIT_CONFIG_VALUE_1=(repo/'.git').as_posix())
git=['git','-c',f'safe.directory={repo.as_posix()}','-C',str(repo)]
sha=subprocess.check_output([*git,'rev-parse','HEAD']).decode().strip()
assert sha==json.loads((r/'FROZEN_COMMIT.json').read_text())['sha']
assert not subprocess.check_output([*git,'status','--porcelain','--untracked-files=no']).strip()
nodes=json.loads((r/'cert_collection.collection.json').read_text());assert len(nodes)==len(set(nodes))
weights=collections.defaultdict(float)
junit=r/'e/STAGE5_GAP_CLOSURE_c962a3d/final_suite/full.junit.xml'
baseline=[]
for c in ET.parse(junit).getroot().iter('testcase'):
    parts=c.get('classname','').split('.')
    if len(parts)>1 and parts[0]=='tests':
        module='tests/'+parts[1]+'.py';weights[module]+=float(c.get('time','0'))
        baseline.append(module+'::'+'::'.join(parts[2:]+[c.get('name')]))
assert set(baseline)<=set(nodes),sorted(set(baseline)-set(nodes))[:10]
modules=collections.defaultdict(list)
for n in nodes:modules[n.split('::')[0]].append(n)
shards=[dict(modules=[],nodes=[],weight=0.) for _ in range(4)]
for m in sorted(modules,key=lambda m:(-max(weights[m],len(modules[m])*.01),m)):
    s=min(shards,key=lambda s:s['weight']);s['modules'].append(m);s['nodes']+=modules[m];s['weight']+=max(weights[m],len(modules[m])*.01)
for s in shards:s['modules'].sort();s['nodes'].sort()
plan=dict(source_sha=sha,nodes=len(nodes),modules=len(modules),duplicates=0,omissions=0,
          method='whole-module fixed partition; sender runtimes used only for load balancing before execution',
          collection_sha256=hashlib.sha256((r/'cert_collection.collection.json').read_bytes()).hexdigest(),
          submitted_collection_nodes=len(baseline),added=sorted(set(nodes)-set(baseline)),shards=shards)
(r/'FULL_PLAN_CERT.json').write_text(json.dumps(plan,indent=1))
for i in range(4):
    target=r/'cert_shards'/str(i)/'repo';assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True)
    subprocess.run(['git','-c',f'safe.directory={repo.as_posix()}','clone','--no-hardlinks',str(repo),str(target)],check=True)
    subprocess.run(['git','-c',f'safe.directory={target.as_posix()}','-C',str(target),'checkout','--detach',sha],check=True)
print(json.dumps({k:v for k,v in plan.items() if k not in ('shards','added')},indent=2))
print(json.dumps([dict(shard=i,cases=len(s['nodes']),weight=s['weight']) for i,s in enumerate(shards)]))

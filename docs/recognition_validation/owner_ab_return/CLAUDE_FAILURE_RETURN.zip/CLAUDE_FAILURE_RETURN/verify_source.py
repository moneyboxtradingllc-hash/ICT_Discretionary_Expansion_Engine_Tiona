from pathlib import Path
import sys,os,json,socket,subprocess,hashlib
r=Path(__file__).resolve().parent;repo=r/'repo'
short=r.parents[1]/'.local/ab20/ledger_tmp';short.mkdir(parents=True,exist_ok=True)
os.environ.update(TEMP=str(short),TMP=str(short),GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=repo.as_posix(),
                  AI_BRAIN_LLM='false',AI_BRAIN_ENABLED='false',EXECUTION_ENABLED='false',ALLOW_PAPER_ORDERS='false',TWO_BRAIN_MODE='off')
def deny(*a,**k):raise RuntimeError('OWNER_AUDIT_NETWORK_DENIED')
socket.socket.connect=deny;socket.getaddrinfo=deny
sys.path[:0]=[str(repo/'src'),str(repo/'tools')]
from recognition_validation import contracts as C
import verify_engineering_ledger as V
identity=C.source_identity(repo)
ledger=V.verify(repo,require_clean=True)
git=['git','-c',f'safe.directory={repo.as_posix()}','-C',str(repo)]
changes=subprocess.check_output([*git,'diff','--name-only','c962a3db256eb76b7b66f9fc158f6f6f1bf01bbb','HEAD']).decode().splitlines()
assert all(p.startswith(('src/recognition_validation/','tests/test_recognition_owner_ab.py','docs/recognition_validation/')) for p in changes)
result=dict(identity=identity,ledger=ledger,changed_files=changes,production_and_protected_unchanged=True,network_requests=0)
(r/'FINAL_SOURCE_VERIFIED.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

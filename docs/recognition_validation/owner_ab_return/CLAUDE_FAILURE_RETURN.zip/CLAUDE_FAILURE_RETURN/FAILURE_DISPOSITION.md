# Verification failure disposition

The complete final suite must be read from FULL_VERIFICATION.json. Failed and skipped cases are never passes.

## Pre-existing Windows child-launch incompatibility: ten cases

All ten candidate failures listed in PARENT_HOST_NODES.json were independently executed on exact submitted source c962a3db256eb76b7b66f9fc158f6f6f1bf01bbb: **10 failed**. The exact JUnit, log and child-status evidence are retained in parent_host_cases.* and PARENT_HOST_FAILURES.json.

`child_environment()` builds a Unix-oriented PATH containing the Python executable directory, /usr/local/bin, /usr/bin and /bin. The isolated Windows child cannot find Git. Its `child_main -> contracts.source_identity -> subprocess.run([git,...])` raises FileNotFoundError [WinError 2] before the intended trajectory, responder injection, timeout body or network-attempt body can execute. Successful-path tests therefore receive infrastructure exit 5; injected exit/network tests see premature exit 1; the intended sleeping child exits before it can time out. This also prevents those tests from exercising their intended end-to-end controls on this host.

HOST_PREFLIGHT.json separately reproduces a valid constructed CLI request on exact parent and candidate, with identical missing-Git child failure. This is evidence of a pre-existing portability limitation, not a claim that the process-isolation acceptance tests passed. The audit does not patch unrelated PATH policy or broaden environment access to turn this Windows run green. A supported, pinned runtime remains required for whole-platform certification.

## Own intermediate regression: corrected

The complete 5c6962f source run had 9,093 passed, 584 skipped and 11 failed. Its eleventh failure was introduced by this audit: the new timing disclosure displaced the existing first NO_ANNOTATION limitation. Final commit 201c60c2bc8cb1fb8944248b4055d625edeabf5c appends the disclosure after existing limitations. Existing tests were preserved and a permanent regression assertion checks their ordering. SUPERSEDED_FULL_5c6962f.json and final0..3 logs/JUnit retain the evidence. Only cert0..3 at the final commit count toward final verification.

## Environment and unexecuted evidence

ENVIRONMENT_IDENTITY.json records Windows/Python and every expected versus observed dependency pin. This is not a pinned Linux certification. The default collection excludes operator/archive-dependent modules as listed in the consolidated report; they are not executed, and skipped tests are not passes. No operator credentials or private archives were accessed. These limits do not invalidate the source-frozen actual report/scorer before/after tampering evidence, but they prevent a claim of completely green full-platform acceptance.

## Supplemental test-only adapter attempt: no healthy current-child launch

A PATH-only test harness adapter supplies the existing Git executable directory without changing any environment names or child checks. On both exact parent and final source this gets past Git, then fails during asyncio/_overlapped import with WinError 10106. ADAPTED_HOST_LIMIT.json retains the exact comparison. This identifies a further restricted-Windows initialization limit, not an A/B repair regression. The adapter did not establish a healthy fresh launch; no guard/allowlist was bypassed and no model request occurred. These supplemental failures do not alter the native full-suite totals. The failed candidate attempt remains in adapted_child_0.log; its helper name describes the attempted healthy probe, not a successful result.

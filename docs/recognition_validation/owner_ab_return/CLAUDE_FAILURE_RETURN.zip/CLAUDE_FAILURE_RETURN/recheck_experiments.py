"""Execute the unmodified source's actual CLI report over verified returned traces."""
from pathlib import Path
import sys,os,socket,json,shutil,copy
ROOT=Path(__file__).resolve().parent
repo=ROOT/('repo' if len(sys.argv)>1 else 'parent'); sys.path[:0]=[str(repo/'src'),str(repo/'tests')]
def deny(*a,**k):raise RuntimeError('OWNER_AUDIT_NETWORK_DENIED')
socket.socket.connect=deny;socket.create_connection=deny;socket.getaddrinfo=deny
from recognition_validation import __main__ as CLI,contracts as C,report as RP,child as CH
from recognition_validation import layers as LY,scoring as SC,recorder as REC
import test_recognition_layer_projection as LP
origin=Path('\\\\?\\'+str((ROOT/'e/STAGE5_GAP_CLOSURE_c962a3d/traces/DISARMED-nonECU/evidence').resolve()))
prefix='RECHECK_FIXED' if len(sys.argv)>1 else 'RECHECK_PARENT'
short=ROOT.parents[1]/('.local/ab20/'+prefix.lower()+'_cases');short.mkdir(parents=True,exist_ok=True)
rows=[]
for case in ('healthy','missing_exit','replaced_exit','wrong_exit_request','wrong_exit_completion','manifest_unsealed_change','manifest_resealed_change','wrong_status_request','same_pid'):
    target=short/case;assert not target.exists();shutil.copytree(origin,target/'e')
    e=target/'e'
    manifest=json.loads((e/RP.MANIFEST).read_text())
    status=json.loads((e/CH.STATUS_FILE).read_text())
    child_exit=json.loads((e/CH.EXIT_FILE).read_text())
    if case=='missing_exit':(e/CH.EXIT_FILE).unlink()
    if case=='replaced_exit':(e/CH.EXIT_FILE).write_text('{}')
    if case=='wrong_exit_request':
        child_exit['request_sha256']='0'*64;(e/CH.EXIT_FILE).write_text(json.dumps(child_exit))
    if case=='wrong_exit_completion':
        child_exit['status']='RUN_INCOMPLETE';child_exit['exit_code']=9;(e/CH.EXIT_FILE).write_text(json.dumps(child_exit))
    if case.startswith('manifest_'):
        manifest['audit_constructed_tamper_marker']=True
        if case=='manifest_resealed_change':manifest['seal']['sha256']=C.seal_digest(manifest)
        (e/RP.MANIFEST).write_text(json.dumps(manifest))
    if case=='wrong_status_request':
        status['request_sha256']='0'*64;(e/CH.STATUS_FILE).write_text(json.dumps(status))
    if case=='same_pid':
        status['parent_pid']=manifest['process_isolation']['pid'];(e/CH.STATUS_FILE).write_text(json.dumps(status))
    try:
        code=CLI.main(['report','--run',str(e),'--out',str(target/'report')])
        result_path=target/'report/result.json'
        result=json.loads(result_path.read_text()) if result_path.exists() else {}
        rows.append(dict(case=case,cli_exit=code,engineering_status=result.get('engineering_status'),final_status=result.get('final_status'),
                         limitations=result.get('missing_prerequisites'),parent_digest_matches_current=CH.C.sha256_hex((e/RP.MANIFEST).read_bytes())==status['manifest_sha256']))
    except Exception as exc:rows.append(dict(case=case,exception=type(exc).__name__,detail=str(exc)))
(ROOT/(prefix+'_A_RESULTS.json')).write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
# B uses copies of actual producer projections, never fabricated owner truth.
events=REC.read_events(origin);calls=REC.read_calls(origin)
projections=SC.read_projections(origin,events)
label=LP._label()
brows=[]
for case in ('healthy','no_brain_recognition','wrong_brain_direction','missing_brain','wrong_opportunity','missing_opportunity','early_recognition'):
    ps=copy.deepcopy(projections);lab=copy.deepcopy(label)
    for p in ps:
        camp=p['layers']['CAMPAIGN']
        if camp['state']=='PROJECTED':
            if case in ('no_brain_recognition','missing_brain'):camp['brain_direction']=None
            if case=='wrong_brain_direction':camp['brain_direction']='bullish'
        if case in ('no_brain_recognition','missing_brain'):
            p['layers']['COMPOSITION']['brain_primary_calls']=0
        if case=='missing_opportunity':p['layers']['TOOL']={'state':'ABSENT','reason':'CONSTRUCTED_MISSING','source':'constructed copy of actual producer projection'}
        if case=='wrong_opportunity' and p['layers']['TOOL']['state']=='PROJECTED':p['layers']['TOOL']['occurrence_id']='CONSTRUCTED_WRONG_OCCURRENCE'
    if case=='early_recognition':lab['earliest_available_utc']='2026-08-19T16:34:00Z'
    cells={c['layer']:c for c in LY.score_label(lab,ps,LY.sequence(ps))}
    brows.append(dict(case=case,timing=cells['TIMING'],campaign=cells['CAMPAIGN'],tool=cells['TOOL']))
(ROOT/(prefix+'_B_RESULTS.json')).write_text(json.dumps(brows,indent=2));print(json.dumps(brows,indent=2))

"""Allowlisted offline pytest worker. Logs/JUnit live outside the checkout."""
from pathlib import Path
import sys,os,json,subprocess
ROOT=Path(__file__).resolve().parent
name=sys.argv[1]
repo=ROOT/('parent' if name.startswith('parent') else 'repo')
if name.startswith('full') and name[-1].isdigit():repo=ROOT/'shards'/name[-1]/'repo'
if name.startswith('final') and name[-1].isdigit():repo=ROOT/'final_shards'/name[-1]/'repo'
if name.startswith('cert') and name[-1].isdigit():repo=ROOT/'cert_shards'/name[-1]/'repo'
temp=ROOT.parents[1]/'.local/ab20/t'/name
assert temp.resolve().is_relative_to(ROOT.parents[1].resolve()) and not temp.exists(),'FRESH_TEMP_REQUIRED'
temp.parent.mkdir(parents=True,exist_ok=True)
runtime=ROOT/('runtime_'+name);assert not runtime.exists();runtime.mkdir()
env={k:v for k,v in os.environ.items() if k.upper() in {'PATH','SYSTEMROOT','WINDIR','COMSPEC','PATHEXT','SYSTEMDRIVE','NUMBER_OF_PROCESSORS'}}
env.update(TEMP=str(runtime),TMP=str(runtime),GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=repo.as_posix(),
           PYTHONIOENCODING='utf-8',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',AI_BRAIN_ENABLED='false',AI_BRAIN_LLM='false',
           EXECUTION_ENABLED='false',ALLOW_PAPER_ORDERS='false',AUTO_EXECUTION_ENABLED='false',TWO_BRAIN_MODE='off',TZ='UTC',
           HTTPS_PROXY='http://127.0.0.1:9',HTTP_PROXY='http://127.0.0.1:9',NO_PROXY='')
for key in ('AI_BRAIN_DIR','AI_RETRIEVAL_DIR','OCCURRENCE_LEDGER_DIR','REPLAY_SESSIONS_DIR','PERFORMANCE_TABLES_DIR','HTF_MEMORY_DIR','GLOBAL_MEMORY_DIR'):
    env[key]=str(runtime/key.lower())
args=sys.argv[2:] or ['tests']
if args==['--plan']:args=json.loads((ROOT/('FULL_PLAN_CERT.json' if name.startswith('cert') else 'FULL_PLAN_FINAL.json' if name.startswith('final') else 'FULL_PLAN.json')).read_text())['shards'][int(name[-1])]['modules']
worker='''import sys,socket,json
from pathlib import Path
sys.path[:0]=['src','tests']
def deny(*a,**k):raise RuntimeError('OWNER_AUDIT_NETWORK_DENIED')
socket.socket.connect=deny;socket.socket.connect_ex=deny;socket.create_connection=deny;socket.getaddrinfo=deny
import pytest
dump=json.dumps
class Log:
 def pytest_collection_finish(self,session):Path(sys.argv[1]+'.collection.json').write_text(dump([i.nodeid for i in session.items]))
 def pytest_runtest_logreport(self,report):
  if report.when=='call' or report.failed or report.skipped:
   with open(sys.argv[1]+'.progress.jsonl','a',encoding='utf-8') as f:f.write(dump(dict(nodeid=report.nodeid,when=report.when,outcome=report.outcome,seconds=report.duration,detail=str(report.longrepr) if report.failed else None))+'\\n')
raise SystemExit(pytest.main(['-q','-r','fE','-p','no:cacheprovider','--basetemp='+sys.argv[2],'--junitxml='+sys.argv[1]+'.junit.xml',*sys.argv[3:]],plugins=[Log()]))
'''
with (ROOT/(name+'.log')).open('x',encoding='utf-8') as log:
    result=subprocess.run([sys.executable,'-u','-c',worker,str(ROOT/name),str(temp),*args],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
(ROOT/(name+'.exit.json')).write_text(json.dumps(dict(exit_code=result.returncode,source_repo=str(repo))))
print(json.dumps(dict(name=name,exit_code=result.returncode)))
raise SystemExit(result.returncode)

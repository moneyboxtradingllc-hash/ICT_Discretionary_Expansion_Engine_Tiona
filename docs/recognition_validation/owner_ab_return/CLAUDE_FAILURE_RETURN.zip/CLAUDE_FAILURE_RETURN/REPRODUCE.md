# Reproducing this bounded audit

The source repair is in OWNER_AB_REPAIRS.bundle and OWNER_AB_REPAIRS.patch. The bundle requires the exact submitted base c962a3db256eb76b7b66f9fc158f6f6f1bf01bbb. Its only branch is audit/stage5-ab-owner-20261020, frozen at 201c60c2bc8cb1fb8944248b4055d625edeabf5c. Verify the manifest before using any file. Do not merge or deploy the branch.

Use a fresh disposable workspace. The helpers expect this layout:

- WORKSPACE/.local/audit/ containing these helpers and evidence records.
- WORKSPACE/.local/audit/parent/ checked out at the submitted base.
- WORKSPACE/.local/audit/repo/ checked out at the final audit commit, imported from the bundle.
- WORKSPACE/.local/audit/e/STAGE5_GAP_CLOSURE_c962a3d/ holding the verified submitted evidence archive.

Keep archived result files separate from a fresh execution directory: the worker deliberately refuses reused temporary/output roots and log names. Do not run these helpers in the operator checkout. Preserve all submitted evidence and existing local scratch work.

The original submitted archive is the Git object at evidence commit 976d0c1efbfe22de8e9fe0cf4eba82f5038292a9, path docs/recognition_validation/gap_closure_package/STAGE5_GAP_CLOSURE_c962a3d.tar.xz. Its SHA-256 is c9176583ea6914a36c33606f348fe22b75b07cf5c17fde9628923a5c56e6b057. BASELINE_IDENTITY.json records independent validation of all 451 manifest entries. setup_audit.py documents extraction and verification; inspect its fixed paths before reusing it. This is repository engineering evidence, not an operator archive or owner annotation set.

With the intended Python environment, the allowlisted network-denying runner executes:

    python run_tests.py cert_focused tests/test_recognition_owner_ab.py tests/test_recognition_contracts.py tests/test_recognition_rule_coverage.py
    python run_tests.py cert_collection --collect-only tests
    python prepare_cert.py
    python run_tests.py cert0 --plan
    python run_tests.py cert1 --plan
    python run_tests.py cert2 --plan
    python run_tests.py cert3 --plan

The four partitions are disjoint whole modules. They can execute concurrently in four separate frozen clones. FULL_PLAN_CERT.json binds the exact collection and source commit. The collection must retain all 9,659 original IDs plus 29 audit IDs. Do not reuse an earlier-source result as final-source evidence.

recheck_experiments.py (no argument) selects the exact parent; with argument `fixed` it selects the audit source. It copies actual returned traces into fresh output roots, attacks those copies, and invokes the real report CLI. run_cert_mutants.py activates three broken-invariant controls without changing source files. verify_cert_lanes.py rereads all four untouched returned traces. verify_source.py runs the canonical engineering-ledger verifier and protected-source/fingerprint checks.

On this Windows host all ten isolated-child success-path tests fail before their intended bodies because the submitted Unix-oriented child PATH cannot locate Git. PARENT_HOST_FAILURES.json proves the same ten failures on the exact parent. ENVIRONMENT_IDENTITY.json records all dependency differences. Reproduction on a supported pinned runtime is required before claiming whole-platform certification; never relabel these failed or unexecuted checks as passes. Do not weaken the child environment or access credentials to make a test green.

All Brain/opportunity labels used for the audit are explicitly constructed/fictional. Mode A/B mechanics and fake transports do not establish current discretionary recognition. No provider, model, venue, production arming or trading authorization is included in this audit.


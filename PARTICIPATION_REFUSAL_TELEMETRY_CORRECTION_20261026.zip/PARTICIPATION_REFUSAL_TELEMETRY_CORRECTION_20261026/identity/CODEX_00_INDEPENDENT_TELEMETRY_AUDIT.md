# Independent audit: participation-refusal telemetry

2026-10-25. **Disposition: REQUEST CHANGES â€” one bounded diagnostic validation gap.** No policy or production repair was made by this audit.

## Frozen submission

* Parent `7b5218ac2fe9bdc1f348c1c433fa4060ae8ba3a2`.
* Inspected final source `14c996cea5b636beaba9d0e0a3d4d73dee8b4fdc`; tree `5cb9414e5958e27a2b588e88b4301b57be1112de`.
* Review branch `review/participation-refusal-telemetry-20261025`.
* Evidence commit `3cc7d396cd7b7d6457ad1baff6a66aa2c9a1504c`.
* Received email Gmail `1a175ddcb5d4cdcd`.
* Original ZIP SHA256 `fbd9f9eea098ed58dbbe7d5ad3da7fa2dd1a2ffc7f53e66b4fa49f6dab455b34`, 864,809 bytes. All 94 manifest members and the Git bundle independently verified. Extraction rejects traversal/symlinks.
* Brain independently measured `brain:43569c8bd11004d7`; retrieval `retr:0c241bdb8234d1ba`; closure 49. All 32 protected pins equal parent/final/baseline digest. Tracked audit worktree is clean.
* The actual engineering-ledger verifier was independently executed at the submitted SHA: `LEDGER_VERIFIED`, all 32 protected sources verified, fingerprint checks passed, zero network requests; receipt `3b415ed2180e369643473df41e28c81c07a2d98a1f2603b224ae7bd9fc844873`.

## What the submission establishes

The original producer/recorder reporting loss is addressed: actual same-scan Lifecycle assessment and exact observed refusal can be persisted, mechanical refusal has a neutral `PARTICIPATION_REFUSED` category, and ordinary valid v2 refusal records reconcile. Phase 3's actual producer/current-scan ownership stays in place. Root intent is diagnostic, not new trading permission.

Only two runtime sources differ from the parent: `src/broker/candidate_decision_record.py` and observational additions to `src/broker/topstepx_production_loop.py`. The producer, campaign Lifecycle/Draw/scope rules, Brain prompt and risk/execution policy source are unchanged. The changed fingerprint is expected because the existing closure includes the loop file; this does not imply a new model invocation.

The final decision trace handoff is keyed by scan count/id/reason and consumed by the recorder. The obsolete checkpoint's added recorder keyword is absent. No code correction is needed merely because two old tests asserting the original defect fail after repair. The unchanged bare-record negative also correctly remains incomplete. These disclosures are not new findings.

The supplied selected stable projections match parent/final for healthy and retired cases, both ECU modes, after explicitly normalizing process-random IDs. Six mechanical terminal rows per case move from `UNCLASSIFIED` to `PARTICIPATION_REFUSED`. These comparisons cover the fields the dumper selected; they are not an independent assertion that every possible runtime value was compared.

## Confirmed remaining defect: inconsistent refusal evidence can report complete

**Classification: CONFIRMED DEFECT in observational reader/reconciliation validation.** This is not a candidate-permission defect, proof of naturally corrupted production output, a missing Friday trade or a new strategy requirement.

### Source and reachable consumer

`src/broker/candidate_decision_record.py::refusal_problems` checks that the nested identity has a nonempty scan id and contract and that those two equal the top-level record. It does not validate its session or settled cutoff. It also accepts any recognized nested Lifecycle state/nonempty reason without comparing them to the same record's `campaign_lifecycle_assessment`.

`reconcile()` treats an empty problem list as complete. The actual user-facing consumer `tools/topstepx_session_outcome_report.py::decisions` reads journal JSONL and invokes that reconciler. It therefore reports `RECONCILED` for records containing these contradictions or missing required chronology.

This violates the delivered mission's exact session/cutoff identity, complete/consistent v2 evidence and contradictory-record refusal requirements. It is a specific missed relationship check; it does not justify a new integrity framework or changes to trading safeguards.

### Healthy and activated controls

`test_independent_reader_integrity.py` starts from authenticated actual W5 production-loop journal records supplied for both ECU lanes. It does not fabricate a mock refusal packet or alter market/Brain/permission input. Each original record reports `RECONCILED` through the real session-report reader. Each attack changes only a diagnostic copy, writes JSONL into an isolated report session, and calls that same reader:

| Single change to otherwise healthy emitted record | Expected | Actual, both lanes |
|---|---|---|
| Nested identity session changed to `FOREIGN-SESSION`, top-level session unchanged | Incomplete/inconsistent | `RECONCILED` |
| Nested settled cutoff removed (`null`) | Incomplete chronology | `RECONCILED` |
| Nested Lifecycle reason contradicts assessment's reason | Inconsistent evidence | `RECONCILED` |
| Nested state changed from `AUTHORITY_UNKNOWN` to another recognized state, assessment unchanged | Inconsistent evidence | `RECONCILED` |

**Independent result: two healthy controls passed; eight activated refusal expectations failed, in 0.56 seconds.** The failures are the finding, not a broken model/provider dependency. Per-attack records and actual reader responses are sealed as `READER_ATTACK_*.json`; JUnit/logs preserve failures. The actual writer's valid happy-path behavior is separately tested, not inferred from malformed records.

One initial invocation used an incorrect relative test path and collected no tests (pytest exit 4). It was corrected and is not counted as a product failure. The corrected run is `independent_reader_corrected`.

## Smallest correction required

Keep this assignment observational and frozen to the accepted parent/submission lineage. Preserve the current repaired capture and all healthy paths.

1. Validate the refusal identity's required session and settled cutoff, and their correspondence with the enclosing record's actual session/decision chronology. Use existing timestamp semantics and timezone normalization. Do not equate the scan-id clock with the settled one-minute cutoff: the supplied example has scan id `scan-20260819T143700` and settled market timestamp `2026-08-19T14:36:00+00:00`. Do not manufacture unavailable identity.
2. Validate that the nested refusal's Lifecycle status/state/reason and duplicated observed assessment fields agree with the same record's authoritative diagnostic assessment. Missing/malformed required assessment evidence stays incomplete, except the specifically supported and internally consistent assessment-unavailable refusal. Preserve valid permissive-assessment direction/binding refusals; `ACTIVE_DELIVERY` is not by itself contradictory for those gates.
3. Keep independently missing optional supporting evidence explicitly UNKNOWN/ABSENT; do not make unavailable historical/private data a new execution gate or require fabricated fields. Conversely, missing required refusal identity/cause must not be reported complete.
4. Extend permanent reader tests with these eight cases through the real report consumer. Keep healthy emitted records, legitimate producer and loop-binding refusals, no-assessment handling, mixed legacy journals and existing unknown-reason negatives. Add restoration controls demonstrating that each minimal check catches the broken relation. Avoid blanket unknown-to-pass mapping.
5. Re-run focused and complete supported isolated offline verification at the final corrected frozen commit, measure fingerprints under existing rules, and return one bounded correction package. No source, prompt, D3, protected high, CISD, risk, economics, candidate or order policy change is authorized by this finding.

No original historical journal was changed. Detecting inconsistency is not cryptographic proof of origin; do not claim this validator authenticates a maliciously coherently rewritten archive. That is outside this bounded repair.

## Verification and evidence limits

The received full-suite evidence independently reconciles 9,826 canonical unique collection/JUnit identities across 361 file-disjoint files: **9,243 passed, 583 skipped, zero failures/errors**. All four supplied shard JUnits match the merged JUnit. The 583 skip identities and messages equal the accepted Phase 3 run. These are authenticated supplied Linux results, **not an independently executed full suite**.

Six supplied mutation-result sets were inspected and each contains actual failing invariant tests, without collection errors. Their reported caught counts are 27, 11, 4, 14, 19 and 1 respectively; they remain supplied results, not owner-executed mutations.

Independent focused execution status is recorded separately in `supplied_focused.exit.json`, JUnit and `FINAL_TEST_SUMMARY.json` when complete. The eight independent reader failures above are additional cases not present in the submitted suite. Supplemental owner runs use Windows Python 3.14.5, isolated runtime roots, stripped environment, disarmed settings and denied sockets/DNS. They do not certify Mac/live operation or actual model judgment.

The 397-record earlier audit remains separate. This submission improves future refusal diagnosis and does not restore absent historical details or answer whether the three authority constraints cover Maurice's intended doctrine. No fresh cognition, paid calls, pricing research, provider/venue calls, merge, deployment, arming, orders or production source modifications occurred in this owner audit. The bounded correction return continues the existing telemetry assignment; any subsequent email delivery confirmation is recorded separately from this sealed audit.

## Completed owner focused results

Independent submitted focused file: **40 passed**, exit 0. Added real-reader controls: **2 healthy passed, 8 activated negative expectations failed**, proving the remaining validation gap. No source patch was applied and no full-suite owner rerun is claimed.

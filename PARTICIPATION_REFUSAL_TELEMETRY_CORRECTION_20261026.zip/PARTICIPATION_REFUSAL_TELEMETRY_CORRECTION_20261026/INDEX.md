# PARTICIPATION_REFUSAL_TELEMETRY_CORRECTION_20261026: index

| Path | Contents |
|---|---|
| `00_COMPLETION_REPORT.md` | Identity, defect, root cause, change, permanent tests, controls, suites, limitations |
| `01_SCHEMA_AND_READER_MAP.md` | Schema and reconciliation rules, including the new identity and assessment-consistency rules (also committed under `docs/recognition_validation/`) |
| `identity/` | `source_identity_{submission,final}.json`, `PINS_AND_CLOSURE_14c996c_ec8197e.json`, `PINS_AND_CLOSURE_7b5218a_ec8197e.json`, `LEDGER_VERIFY.json`, Codex's audit and bounded request |
| `source/` | Correction diff 14c996c..ec8197e, full diff 7b5218a..ec8197e, diff stats, commit text, git bundle (prerequisite 7b5218a) |
| `codex_reader_test/` | Codex's `test_independent_reader_integrity.py` (unchanged): at 14c996c 8 failed / 2 passed; at ec8197e 10 passed; per-attack report outputs |
| `submission_reproduction/` | The corrected permanent module run inside a clean 14c996c checkout: 25 failed, 9 passed (FAILED/PASSED lists, log, JUnit) |
| `owner_reproduction/` | Owner reproducer `test_offline_boundaries.py` at ec8197e: 2 failed (parent-defect assertions), 5 passed |
| `stable_comparison/` | ec8197e dumps vs the 7b5218a parent dumps, the dumper, `STABLE_COMPARISON.json` |
| `focused/` | Focused run (324 passed), log and JUnit |
| `mutants/` | Nine mutant diffs, logs and JUnit, both appliers, runner (never committed) |
| `full_suite/` | Collection, shard plan, four shard logs/JUnit/done markers, merged JUnit, `union.json`, `skip_accounting.json`, runner and tools |
| `MANIFEST_SHA256.txt` | SHA-256 of every file in this package |

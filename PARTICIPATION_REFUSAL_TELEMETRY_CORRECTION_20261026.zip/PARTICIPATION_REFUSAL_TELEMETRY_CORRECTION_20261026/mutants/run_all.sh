#!/bin/bash
S=<scratch>
D=$S/t2/mutants
run() { m=$1; echo "$m $($S/g5/run.sh $D/$m $D/$m.log python -m pytest -p no:cacheprovider -q -rf --junitxml=$D/$m.junit.xml tests/test_participation_refusal_telemetry.py tests/test_decision_accounting_stood_down.py tests/test_decision_accounting_held.py)"; }
run M7_NO_SESSION_RELATION & run M8_NO_CUTOFF_RELATION & run M9_NO_ASSESSMENT_CONSISTENCY & run M1_DROP_LIFECYCLE_FIELDS & wait
run M2_GENERIC_UNCLASSIFIED & run M3_STALE_OWNERSHIP & run M4_BLANKET_RECONCILE_PASS & run M5_BLANKET_UNKNOWN_REASON & wait
run M6_STALE_REFUSAL_HANDOFF; wait
echo ALLDONE

"""Restore-break ONE relationship check of the reader correction (throwaway worktree only)."""
import sys
from pathlib import Path
name, root = sys.argv[1], Path(sys.argv[2])
REC = root / "src/broker/candidate_decision_record.py"
MUTANTS = {
    # M7: the nested session relation (required, equal to the enclosing record's).
    "M7_NO_SESSION_RELATION": [
        ('    for key in ("scan_id", "contract", "session_id", "settled_cutoff"):',
         '    for key in ("scan_id", "contract", "settled_cutoff"):'),
        ('''    if (identity.get("scan_id") != record.get("scan_id") or identity.get("contract") != record.get("contract")
            or identity.get("session_id") != record.get("session_id")):''',
         '''    if identity.get("scan_id") != record.get("scan_id") or identity.get("contract") != record.get("contract"):''')],
    # M8: the settled-cutoff relation (required, a valid instant, equal to the record's settled timestamp).
    "M8_NO_CUTOFF_RELATION": [
        ('    for key in ("scan_id", "contract", "session_id", "settled_cutoff"):',
         '    for key in ("scan_id", "contract", "session_id"):'),
        ('''    if identity.get("settled_cutoff") and cutoff is None:
        problems.append("identity_settled_cutoff_invalid")
    if cutoff is not None and cutoff != _instant_or_none(record.get("timestamp_et")):
        problems.append("identity_settled_cutoff_disagrees_with_record")''', '')],
    # M9: the duplicated-field consistency with the record's own assessment.
    "M9_NO_ASSESSMENT_CONSISTENCY": [
        ('    problems.extend(_assessment_disagreements(record, block, observed))\n', '')],
}
text = REC.read_text()
for old, new in MUTANTS[name]:
    assert text.count(old) == 1, (name, old[:50])
    text = text.replace(old, new)
REC.write_text(text)
print("applied", name)

"""Audit the real report consumer using actual loop-emitted v2 records.

No model/market/permission input changes; only copies of diagnostic rows.
"""
import copy, importlib.util, json
from pathlib import Path
import pytest
import broker.candidate_decision_record as R
from ai_retrieval.retrieval_telemetry import session_root

HERE=Path(__file__).resolve().parent
ROOT=HERE/'repo'
spec=importlib.util.spec_from_file_location('owner_report',ROOT/'tools/topstepx_session_outcome_report.py')
REPORT=importlib.util.module_from_spec(spec);spec.loader.exec_module(REPORT)

def original(ecu):
    # Authenticated supplied output of actual disarmed loop, not a mock record.
    data=json.loads((HERE/'evidence/PARTICIPATION_REFUSAL_TELEMETRY_20261025/final_records'/f'LOOP_RECORDS_{ecu}.json').read_text())
    return next(r for r in data['records'] if r['final_rejection_reason']=='campaign_lifecycle_refused')

def consume(tmp_path,monkeypatch,row):
    monkeypatch.setenv('REPLAY_SESSIONS_DIR',str(tmp_path))
    root=Path(session_root(row['session_id']));root.mkdir(parents=True,exist_ok=True)
    (root/'candidate_decisions.jsonl').write_text(json.dumps(row)+'\n')
    return REPORT.decisions(row['session_id'])['reconciliation']

@pytest.mark.parametrize('ecu',['non_ecu','ecu'])
def test_untouched_loop_record_reconciles(tmp_path,monkeypatch,ecu):
    assert consume(tmp_path,monkeypatch,original(ecu))['status']=='RECONCILED'

MUTATIONS={
    'foreign_identity_session':lambda r:r['participation_refusal']['identity'].update(session_id='FOREIGN-SESSION'),
    'missing_settled_cutoff':lambda r:r['participation_refusal']['identity'].update(settled_cutoff=None),
    'conflicting_lifecycle_reason':lambda r:r['participation_refusal'].update(lifecycle_reason='opposite_to_the_same_record_assessment'),
    'conflicting_lifecycle_state':lambda r:r['participation_refusal'].update(lifecycle_state='DESTINATION_SUBSTANTIALLY_DELIVERED'),
}

@pytest.mark.parametrize('ecu',['non_ecu','ecu'])
@pytest.mark.parametrize('mutation',list(MUTATIONS))
def test_inconsistent_or_incomplete_evidence_must_not_report_complete(tmp_path,monkeypatch,ecu,mutation):
    row=copy.deepcopy(original(ecu))
    assert R.reconcile([row])['status']=='RECONCILED' # healthy control activated
    MUTATIONS[mutation](row)
    result=consume(tmp_path,monkeypatch,row)
    (HERE/f'READER_ATTACK_{mutation}_{ecu}.json').write_text(json.dumps({'mutation':mutation,'record':row,'actual_report_reconciliation':result},indent=2))
    assert result['status']=='CANDIDATE_DECISION_ACCOUNTING_FAILURE',result
